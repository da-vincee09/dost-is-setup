import {
  adjustmentService,
  beneficiaryService,
  calculateAge,
  collectionService,
  dashboardService,
  defermentService,
  documentService,
  getCooperatorView,
  getEnterpriseClassification,
  getBeneficiaryFinancials,
  getMunicipalityDistrict,
  getRefundMonthCount,
  getSchedule,
  getSeniorCitizenClassification,
  formatSetupPhaseRemarks,
  importService,
  isRefundApplicableToPhase,
  lookups,
  parseSetupPhaseRemarks,
  receiptService,
  reconciliationService,
  reportService,
  setupPhaseOptions,
  settingsService
} from "./services.js";
import {
  buttonLink,
  collectionPerformanceChart,
  dataTable,
  dashboardTableCard,
  emptyState,
  errorState,
  field,
  fileUpload,
  filterChips,
  formSection,
  icon,
  mobileRecordCard,
  pageHeader,
  referenceComparisonChart,
  referenceDonutCard,
  referenceKpiCard,
  referenceLineChart,
  reportPreview,
  searchInput,
  selectField,
  statusBadge,
  summaryCard,
  svgChartCard,
  textArea
} from "./components.js";
import {
  createToast,
  addMonths,
  dateAfter,
  debounce,
  downloadCsv,
  downloadJson,
  downloadPdf,
  downloadXlsx,
  escapeHtml,
  focusFirstError,
  formatCurrency,
  formatDate,
  percent,
  readForm,
  setFieldErrors,
  slug,
  todayIso,
  toNumber
} from "./utils.js";
import { repository } from "./repository.js";
import {
  getMunicipalityCoordinates,
  getMunicipalityDistrictName,
  ilocosSurBounds,
  municipalityMapBounds,
  municipalityMapPoints,
  noMunicipalityLabel,
  normalizeMunicipality
} from "./mapConfig.js";

const app = document.querySelector("#app");
const APP_NAME = "DOST IS SETUP PROJECTS";
const APP_SUBTITLE = "Cooperator, Services, and Refund Collection Monitoring";
const navItems = [
  { group: "Overview", label: "Dashboard", path: "/", iconName: "dashboard" },
  { group: "SETUP", label: "Cooperators", path: "/beneficiaries", iconName: "users" },
  { group: "Monitoring and Evaluation", label: "SETUP Refund", path: "/setup-refund", iconName: "dashboard" },
  { group: "Monitoring and Evaluation", label: "Status Report PIS", path: "/status-report-pis", iconName: "report" },
  { group: "Monitoring and Evaluation", label: "KPI", path: "/kpi", iconName: "check" },
  { group: "Transactions", label: "Collections", path: "/collections", iconName: "cash" },
  { group: "Transactions", label: "Official Receipts", path: "/receipts", iconName: "receipt" },
  { group: "Transactions", label: "Reconciliation", path: "/reconciliation", iconName: "reconcile" },
  { group: "Transactions", label: "Deferments", path: "/deferments", iconName: "calendar" },
  { group: "Transactions", label: "Account Adjustments", path: "/adjustments", iconName: "edit" },
  { group: "Records", label: "Documents", path: "/documents", iconName: "folder" },
  { group: "Records", label: "Reports", path: "/reports", iconName: "report" },
  { group: "Records", label: "Data Import", path: "/import", iconName: "upload" },
  { group: "Records", label: "Archived Records", path: "/archived", iconName: "archive" },
  { group: "System", label: "Settings", path: "/settings", iconName: "settings" }
];

const uiState = {
  sidebarCollapsed: false,
  importStep: 1,
  importPayload: null,
  escapeBound: false
};

const leafletAssets = {
  css: "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css",
  js: "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
};
let leafletLoadPromise = null;

window.__dirtyForm = false;

function normalizeRoutePath(path) {
  const hashPath = String(path || "").startsWith("#") ? String(path).slice(1) : path;
  const [pathPart, queryPart = ""] = String(hashPath || "/").split("?");
  const cleanPath = String(pathPart || "/").replace(/\/+$/, "") || "/";
  if (cleanPath === "/index.html" || cleanPath === "/dist" || cleanPath === "/dist/index.html") return "/";
  return `${cleanPath}${queryPart ? `?${queryPart}` : ""}`;
}

function currentRoutePath() {
  return normalizeRoutePath(location.hash?.startsWith("#/") ? location.hash.slice(1) : `${location.pathname}${location.search}`).split("?")[0];
}

function routeHref(path) {
  return `#${normalizeRoutePath(path)}`;
}

function routeMatcher(path) {
  const cleanPath = normalizeRoutePath(path).split("?")[0];
  const matchers = [
    [/^\/$/, () => ({ title: "Dashboard", render: renderDashboard, bind: bindDashboard })],
    [/^\/setup-refund$/, () => ({ title: "SETUP Refund", render: renderSetupRefundDashboard, bind: bindSetupRefundDashboard })],
    [/^\/status-report-pis$/, () => ({ title: "Status Report PIS", render: renderStatusReportPis, bind: bindStatusReportPis })],
    [/^\/kpi$/, () => ({ title: "KPI", render: renderKpiPage, bind: bindKpiPage })],
    [/^\/beneficiaries$/, () => ({ title: "Cooperators", render: renderBeneficiaries, bind: bindBeneficiaries })],
    [/^\/beneficiaries\/new$/, () => ({ title: "Add Cooperator", render: () => renderBeneficiaryForm(), bind: bindBeneficiaryForm })],
    [/^\/beneficiaries\/([^/]+)\/edit$/, (id) => ({ title: "Edit Cooperator", render: () => renderBeneficiaryForm(id), bind: () => bindBeneficiaryForm(id) })],
    [/^\/beneficiaries\/([^/]+)$/, (id) => ({ title: "Cooperator Profile", render: () => renderBeneficiaryDetail(id), bind: () => bindBeneficiaryDetail(id) })],
    [/^\/collections$/, () => ({ title: "Collections", render: renderCollections, bind: bindCollections })],
    [/^\/collections\/new$/, () => ({ title: "Record Payment", render: renderPaymentForm, bind: bindPaymentForm })],
    [/^\/collections\/([^/]+)$/, (id) => ({ title: "Payment Detail", render: () => renderPaymentDetail(id), bind: bindPaymentDetail })],
    [/^\/receipts$/, () => ({ title: "Official Receipts", render: renderReceipts, bind: bindReceipts })],
    [/^\/receipts\/new$/, () => ({ title: "Record Official Receipt", render: renderReceiptForm, bind: bindReceiptForm })],
    [/^\/reconciliation$/, () => ({ title: "Reconciliation", render: renderReconciliation, bind: bindReconciliation })],
    [/^\/deferments$/, () => ({ title: "Deferments", render: renderDeferments, bind: bindDeferments })],
    [/^\/deferments\/new$/, () => ({ title: "Add Deferment", render: renderDefermentForm, bind: bindDefermentForm })],
    [/^\/adjustments$/, () => ({ title: "Account Adjustments", render: renderAdjustments, bind: bindAdjustments })],
    [/^\/adjustments\/new$/, () => ({ title: "Create Adjustment", render: renderAdjustmentForm, bind: bindAdjustmentForm })],
    [/^\/documents$/, () => ({ title: "Documents", render: renderDocuments, bind: bindDocuments })],
    [/^\/reports$/, () => ({ title: "Reports", render: renderReports, bind: bindReports })],
    [/^\/import$/, () => ({ title: "Data Import", render: renderImport, bind: bindImport })],
    [/^\/archived$/, () => ({ title: "Archived Records", render: renderArchived, bind: bindArchived })],
    [/^\/settings$/, () => ({ title: "Settings", render: renderSettings, bind: bindSettings })]
  ];
  for (const [regex, factory] of matchers) {
    const match = cleanPath.match(regex);
    if (match) return factory(...match.slice(1));
  }
  return { title: "Page Not Found", render: renderNotFound, bind: () => {} };
}

function navigate(path) {
  if (window.__dirtyForm && !window.confirm("You have unsaved changes. Leave this page?")) return;
  window.__dirtyForm = false;
  location.hash = normalizeRoutePath(path);
  renderApp();
}

function navigationMarkup() {
  let currentGroup = "";
  return navItems
    .map((item) => {
      const currentPath = currentRoutePath();
      const active = currentPath === item.path || (item.path !== "/" && currentPath.startsWith(item.path));
      const groupLabel = item.group !== currentGroup ? `<p class="nav-group">${escapeHtml(item.group)}</p>` : "";
      currentGroup = item.group;
      return `${groupLabel}<a class="${active ? "active" : ""}" href="${routeHref(item.path)}" data-link>${icon(item.iconName)}<span>${escapeHtml(item.label)}</span></a>`;
    })
    .join("");
}

function sidebarMarkup() {
  return `
    <aside class="sidebar" aria-label="Primary navigation">
      <div class="brand-lockup">
        <span class="brand-mark">DOST</span>
        <div>
          <strong>${APP_NAME}</strong>
          <small>${APP_SUBTITLE}</small>
        </div>
      </div>
      <nav>
        ${navigationMarkup()}
      </nav>
      <button class="sidebar-toggle" type="button" data-action="toggle-sidebar">${icon("chevron")}<span>Collapse</span></button>
    </aside>
  `;
}

function mobileDrawerMarkup() {
  return `
    <div class="drawer-backdrop" data-action="close-drawer"></div>
    <aside class="mobile-drawer" aria-label="Mobile navigation">
      <div class="drawer-head">
        <strong>${APP_NAME}</strong>
        <button class="icon-btn" type="button" data-action="close-drawer" aria-label="Close navigation">${icon("close")}</button>
      </div>
      <nav>
        ${navigationMarkup()}
      </nav>
    </aside>
  `;
}

function getAttentionCount() {
  const state = repository.getSnapshot();
  const asOf = todayIso();
  const receiptPaymentIds = new Set(state.receipts.filter((receipt) => !receipt.archived).map((receipt) => receipt.paymentId));
  const missingReceipts = state.payments.filter((payment) => !payment.archived && !["Pending", "Returned", "Replaced", "Cancelled"].includes(payment.status) && !receiptPaymentIds.has(payment.id)).length;
  const pdcSoon = state.payments.filter((payment) => {
    if (payment.archived || payment.method !== "PDC" || !payment.checkDate) return false;
    if (["Returned", "Replaced", "Cancelled"].includes(payment.status)) return false;
    if (payment.paymentDate > asOf) return false;
    const days = Math.round((new Date(`${payment.checkDate}T00:00:00`) - new Date(`${asOf}T00:00:00`)) / 86400000);
    return days >= 0 && days <= 14;
  }).length;
  return missingReceipts + pdcSoon;
}

function renderShell(route) {
  const attentionCount = getAttentionCount();
  return `
    <div class="app-shell ${uiState.sidebarCollapsed ? "is-collapsed" : ""}">
      ${sidebarMarkup()}
      ${mobileDrawerMarkup()}
      <div class="app-main">
        <header class="topbar">
          <button class="icon-btn menu-button" type="button" data-action="open-drawer" aria-label="Open navigation">${icon("menu")}</button>
          <div class="topbar-title">
            <span>${APP_SUBTITLE}</span>
            <strong>${escapeHtml(route.title)}</strong>
          </div>
          <div class="topbar-actions">
            <span class="connection-state" data-online-state>${navigator.onLine ? "Online" : "Offline"}</span>
            <a class="alert-pill" href="/" data-link title="Records requiring attention">${icon("alert")}<span>${attentionCount}</span></a>
            ${buttonLink("/beneficiaries/new", "Add Cooperator", "plus", "primary")}
          </div>
        </header>
        <main id="main-content" tabindex="-1">${route.render()}</main>
      </div>
      <div class="toast-region" data-toast-region aria-live="polite"></div>
    </div>
  `;
}

function renderApp() {
  try {
    const route = routeMatcher(currentRoutePath());
    document.title = `${route.title} | ${APP_NAME}`;
    app.innerHTML = renderShell(route);
    bindShell();
    route.bind?.();
    document.querySelector("#main-content")?.focus({ preventScroll: true });
  } catch (error) {
    console.error("Module render failed:", error);
    document.title = `Module Error | ${APP_NAME}`;
    app.innerHTML = `
      <div class="app-shell ${uiState.sidebarCollapsed ? "is-collapsed" : ""}">
        ${sidebarMarkup()}
        ${mobileDrawerMarkup()}
        <div class="app-main">
          <header class="topbar">
            <button class="icon-btn menu-button" type="button" data-action="open-drawer" aria-label="Open navigation">${icon("menu")}</button>
            <div class="topbar-title">
              <span>${APP_SUBTITLE}</span>
              <strong>Module Error</strong>
            </div>
            <div class="topbar-actions">
              <span class="connection-state" data-online-state>${navigator.onLine ? "Online" : "Offline"}</span>
            </div>
          </header>
          <main id="main-content" tabindex="-1">${errorState("This module could not be displayed because one or more database records are incomplete or invalid. Check the browser console for the exact record error.")}</main>
        </div>
        <div class="toast-region" data-toast-region aria-live="polite"></div>
      </div>
    `;
    bindShell();
  }
}

function bindShell() {
  app.querySelectorAll("[data-action='toggle-sidebar']").forEach((button) => {
    button.addEventListener("click", () => {
      uiState.sidebarCollapsed = !uiState.sidebarCollapsed;
      app.querySelector(".app-shell")?.classList.toggle("is-collapsed", uiState.sidebarCollapsed);
    });
  });
  app.querySelectorAll("[data-action='open-drawer']").forEach((button) => {
    button.addEventListener("click", () => app.querySelector(".app-shell")?.classList.add("drawer-open"));
  });
  app.querySelectorAll("[data-action='close-drawer']").forEach((button) => {
    button.addEventListener("click", () => app.querySelector(".app-shell")?.classList.remove("drawer-open"));
  });
  app.querySelectorAll(".mobile-drawer [data-link]").forEach((link) => {
    link.addEventListener("click", () => app.querySelector(".app-shell")?.classList.remove("drawer-open"));
  });
  if (!uiState.escapeBound) {
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") app.querySelector(".app-shell")?.classList.remove("drawer-open");
    });
    uiState.escapeBound = true;
  }
}

function bindTableSorts(root = document) {
  root.querySelectorAll("[data-sort]").forEach((button) => {
    button.addEventListener("click", () => {
      const table = button.closest("table");
      const key = button.dataset.sort;
      const header = button.closest("th");
      const index = [...header.parentElement.children].indexOf(header);
      const rows = [...table.tBodies[0].rows];
      const direction = button.dataset.direction === "asc" ? "desc" : "asc";
      button.dataset.direction = direction;
      rows
        .sort((a, b) => {
          const left = a.cells[index].textContent.trim();
          const right = b.cells[index].textContent.trim();
          return direction === "asc" ? left.localeCompare(right, undefined, { numeric: true }) : right.localeCompare(left, undefined, { numeric: true });
        })
        .forEach((row) => table.tBodies[0].append(row));
    });
  });
}

function bindSearch(root = document) {
  const input = root.querySelector("[data-search]");
  if (!input) return;
  const apply = () => {
    const term = input.value.trim().toLowerCase();
    root.querySelectorAll("[data-record-row], [data-record-card]").forEach((node) => {
      const haystack = node.dataset.searchText?.toLowerCase() || node.textContent.toLowerCase();
      node.hidden = term && !haystack.includes(term);
    });
    const visibleCount = [...root.querySelectorAll("[data-record-row], [data-record-card]")].filter((node) => !node.hidden).length;
    root.querySelector("[data-visible-count]")?.replaceChildren(document.createTextNode(String(visibleCount)));
  };
  input.addEventListener("input", debounce(apply, 120));
  root.querySelector("[data-clear-search]")?.addEventListener("click", () => {
    input.value = "";
    input.focus();
    apply();
  });
}

function bindDirtyForm(form) {
  if (!form) return;
  window.__dirtyForm = false;
  form.addEventListener("input", () => {
    window.__dirtyForm = true;
  });
}

function getQuery() {
  const hashQuery = location.hash?.startsWith("#/") && location.hash.includes("?") ? location.hash.slice(location.hash.indexOf("?") + 1) : "";
  return Object.fromEntries(new URLSearchParams(hashQuery || location.search).entries());
}

function getQueryParams() {
  const hashQuery = location.hash?.startsWith("#/") && location.hash.includes("?") ? location.hash.slice(location.hash.indexOf("?") + 1) : "";
  return new URLSearchParams(hashQuery || location.search);
}

function setQuery(basePath, values) {
  const params = new URLSearchParams();
  Object.entries(values).forEach(([key, value]) => {
    if (value) params.set(key, value);
  });
  navigate(`${basePath}${params.toString() ? `?${params}` : ""}`);
}

function pagedRows(rows, basePath, pageSize = 100) {
  const query = getQueryParams();
  const totalRows = rows.length;
  const totalPages = Math.max(1, Math.ceil(totalRows / pageSize));
  const page = Math.min(Math.max(1, Number(query.get("page") || 1)), totalPages);
  const start = (page - 1) * pageSize;
  const end = Math.min(start + pageSize, totalRows);
  const pageRows = rows.slice(start, end);
  const pageHref = (nextPage) => {
    const params = getQueryParams();
    if (nextPage <= 1) params.delete("page");
    else params.set("page", String(nextPage));
    const search = params.toString();
    return `${basePath}${search ? `?${search}` : ""}`;
  };
  const controls =
    totalRows <= pageSize
      ? ""
      : `<nav class="table-pagination" aria-label="Table pages">
          <a class="btn btn-secondary ${page <= 1 ? "is-disabled" : ""}" href="${pageHref(page - 1)}" data-link>Previous</a>
          <span>Page ${page} of ${totalPages}</span>
          <a class="btn btn-secondary ${page >= totalPages ? "is-disabled" : ""}" href="${pageHref(page + 1)}" data-link>Next</a>
        </nav>`;
  return { rows: pageRows, start: totalRows ? start + 1 : 0, end, totalRows, controls };
}

function beneficiaryOptionList(selected = "") {
  return repository
    .getSnapshot()
    .beneficiaries.filter((item) => !item.archived)
    .map((item) => `<option value="${item.id}" ${item.id === selected ? "selected" : ""}>${escapeHtml(getCooperatorView(item).firmName)} - ${escapeHtml(getCooperatorView(item).cooperatorName)}</option>`)
    .join("");
}

function yearOptions(selected = "") {
  const years = [
    ...new Set(
      repository
        .getSnapshot()
        .beneficiaries.filter((item) => !item.archived)
        .flatMap((item) => {
          const cooperator = getCooperatorView(item);
          return [item.project.projectYear, cooperator.setup.yearAwarded, ...cooperator.setup.phases.map((phase) => phase.yearAwarded)].filter(Boolean);
        })
    )
  ].sort((a, b) => b - a);
  return years.map((year) => `<option value="${year}" ${String(year) === String(selected) ? "selected" : ""}>${year}</option>`).join("");
}

function setupStatusOptions(selected = "") {
  const options = [...new Set(["Pending", ...lookups.setupProjectStatuses, "Cancelled", "Returned"])];
  return options.map((item) => `<option value="${escapeHtml(item)}" ${item === selected ? "selected" : ""}>${escapeHtml(item)}</option>`).join("");
}

function setupPhaseSummary(phases = []) {
  if (!phases.length) return `<span class="muted">No SETUP phase</span>`;
  const visible = phases.slice(0, 3);
  const extra = phases.length - visible.length;
  return `<div class="phase-summary">${visible.map((phase) => `<span class="phase-chip"><b>${escapeHtml(phase.phase)}</b>${statusBadge(phase.status || "Pending")}</span>`).join("")}${extra > 0 ? `<span class="phase-more">+${extra} more</span>` : ""}</div>`;
}

function setupPhasePlainSummary(phases = []) {
  if (!phases.length) return "No SETUP phase";
  return escapeHtml(phases.map((phase) => `${phase.phase}: ${phase.status || "Pending"}`).join(", "));
}

function formatNumber(value) {
  return Number(value || 0).toLocaleString("en-PH");
}

function maxFor(rows, key) {
  return Math.max(...rows.map((row) => Number(row[key] || 0)), 0);
}

function metricCell(value, max, formatter = formatNumber) {
  const amount = Number(value || 0);
  const width = max > 0 ? Math.min(100, Math.max(amount > 0 ? 5 : 0, (amount / max) * 100)) : 0;
  return `
    <div class="dashboard-metric">
      <strong>${escapeHtml(formatter(amount))}</strong>
      <span class="metric-track" aria-hidden="true"><span style="width:${width.toFixed(1)}%"></span></span>
    </div>
  `;
}

function attentionMeta(meta) {
  if (typeof meta === "number") return formatCurrency(meta);
  const value = String(meta || "");
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return formatDate(value);
  return value;
}

function compactAttentionRows(attention) {
  const grouped = new Map();
  attention.forEach((item) => {
    const metaLabel = attentionMeta(item.meta);
    const key = `${item.type}|${item.text}|${metaLabel}`;
    const existing = grouped.get(key);
    if (existing) {
      existing.count += 1;
    } else {
      grouped.set(key, { ...item, metaLabel, count: 1 });
    }
  });
  return [...grouped.values()];
}

function addDaysIso(isoDate, count) {
  const date = new Date(`${isoDate}T00:00:00`);
  if (Number.isNaN(date.getTime())) return isoDate;
  date.setDate(date.getDate() + count);
  return date.toISOString().slice(0, 10);
}

function getUpcomingRefundRows(asOf = todayIso(), limit = 6) {
  const endDate = addDaysIso(asOf, 15);
  return beneficiaryService
    .list({ asOf })
    .flatMap((beneficiary) => {
      const cooperator = getCooperatorView(beneficiary, beneficiary.financials, asOf);
      const hasSetup = cooperator.services.some((service) => service.category === "SETUP");
      if (!hasSetup || beneficiary.archived) return [];
      return beneficiary.financials.schedule
        .filter((row) => row.remainingAmount > 0.01)
        .filter((row) => {
          const dueKey = row.gracePeriodDeadline || row.dueDate;
          return dueKey >= asOf && dueKey <= endDate;
        })
        .map((row) => ({
          id: beneficiary.id,
          firmName: cooperator.firmName,
          cooperatorName: cooperator.cooperatorName,
          refundMonth: row.refundMonth,
          deadline: row.gracePeriodDeadline || row.dueDate,
          amount: row.remainingAmount,
          status: row.status,
          searchText: `${cooperator.firmName} ${cooperator.cooperatorName} ${row.refundMonth} ${row.status}`
        }));
    })
    .sort((a, b) => a.deadline.localeCompare(b.deadline) || b.amount - a.amount)
    .slice(0, limit);
}

function referenceDueTable(rows) {
  return `
    <section class="reference-panel reference-due-panel">
      <div class="reference-panel-title reference-title-navy">Refunds Due In Next 15 Days</div>
      ${
        rows.length
          ? `<div class="reference-table-wrap">
              <table class="reference-table">
                <thead>
                  <tr><th>Name of Firm</th><th>Cooperator</th><th>Refund Month</th><th>Deadline</th><th>Amount</th><th>Status</th></tr>
                </thead>
                <tbody>
                  ${rows
                    .map(
                      (row) =>
                        `<tr><td><a href="/beneficiaries/${row.id}" data-link>${escapeHtml(row.firmName)}</a></td><td>${escapeHtml(row.cooperatorName)}</td><td>${escapeHtml(row.refundMonth)}</td><td>${formatDate(row.deadline)}</td><td>${formatCurrency(row.amount)}</td><td>${statusBadge(row.status)}</td></tr>`
                    )
                    .join("")}
                </tbody>
              </table>
            </div>`
          : `<div class="dashboard-empty">No refund obligations are due in the next 15 days.</div>`
      }
    </section>
  `;
}

function referenceSourceGraphCard({ title, description, columns, rows, empty = "No source data available." }) {
  return `
    <section class="reference-source-panel">
      <header class="reference-source-head">
        <h2>${escapeHtml(title)}</h2>
        <p>${escapeHtml(description)}</p>
      </header>
      ${
        rows.length
          ? `<div class="reference-source-table-wrap">
              <table class="reference-source-table">
                <thead>
                  <tr>${columns.map((column) => `<th class="${column.align === "right" ? "is-right" : ""}">${escapeHtml(column.label)}</th>`).join("")}</tr>
                </thead>
                <tbody>
                  ${rows
                    .map(
                      (row) =>
                        `<tr>${columns
                          .map((column) => `<td class="${column.align === "right" ? "is-right" : ""} ${column.isLabel ? "is-label" : ""}">${column.render(row)}</td>`)
                          .join("")}</tr>`
                    )
                    .join("")}
                </tbody>
              </table>
            </div>`
          : `<div class="dashboard-empty">${escapeHtml(empty)}</div>`
      }
    </section>
  `;
}

function referenceSourceGraphs(summary) {
  const monthlyRows = [...summary.charts.monthlyCollection];
  const setupFundRows = [...(summary.charts.setupFundByYear || [])].sort((a, b) => Number(b.label) - Number(a.label));
  const monthlyMax = maxFor(monthlyRows, "value");
  const setupFundMax = maxFor(setupFundRows, "fund");
  const firmMax = maxFor(setupFundRows, "firms");

  return `
    <section class="reference-source-grid" aria-label="Workbook source data graphs">
      ${referenceSourceGraphCard({
        title: "Monthly Collection Trend",
        description: "Recent payment activity.",
        rows: monthlyRows,
        columns: [
          { label: "Month", isLabel: true, render: (row) => escapeHtml(row.label) },
          { label: "Collected", align: "right", render: (row) => metricCell(row.value, monthlyMax, formatCurrency) }
        ]
      })}
      ${referenceSourceGraphCard({
        title: "Setup Fund",
        description: "SETUP fund and number of firms grouped by project year.",
        rows: setupFundRows,
        columns: [
          { label: "Year", isLabel: true, render: (row) => escapeHtml(row.label) },
          { label: "Setup Fund", align: "right", render: (row) => metricCell(row.fund, setupFundMax, formatCurrency) },
          { label: "Firms", align: "right", render: (row) => metricCell(row.firms, firmMax, formatNumber) }
        ]
      })}
    </section>
  `;
}

function yearContext(year) {
  return year ? `Selected year: ${year}` : "All available project years";
}

function dashboardTabs(activeTab = "collection") {
  return `
    <nav class="dashboard-tabs" aria-label="Dashboard sections">
      <a class="${activeTab === "collection" ? "active" : ""}" href="${routeHref("/")}" data-link>Collection Dashboard</a>
      <a class="${activeTab === "analytics" ? "active" : ""}" href="${routeHref("/?tab=analytics")}" data-link>Demographics & Analytics</a>
    </nav>
  `;
}

function analyticsRows(filters = {}) {
  return beneficiaryService
    .list({ includeArchived: true })
    .map((beneficiary) => {
      const cooperator = getCooperatorView(beneficiary, beneficiary.financials);
      const rawDistrict = cooperator.district || getMunicipalityDistrict(cooperator.municipality) || "";
      const district = String(rawDistrict).toLowerCase().includes("1") || String(rawDistrict).toLowerCase().includes("first")
        ? "First District"
        : String(rawDistrict).toLowerCase().includes("2") || String(rawDistrict).toLowerCase().includes("second")
          ? "Second District"
          : "No District";
      const sex = normalizeSex(cooperator.sex);
      const pwd = cooperator.pwd === "Yes";
      const ip = cooperator.indigenousPeople === "Yes";
      const activeFirm = !beneficiary.archived && !["Archived", "Terminated", "Withdrawn"].includes(beneficiary.status);
      return {
        id: beneficiary.id,
        firmName: cooperator.firmName,
        cooperatorName: cooperator.cooperatorName,
        municipality: cooperator.municipality || "Not classified",
        district,
        businessType: normalizeBusinessType(cooperator.businessType),
        businessSector: normalizeDisplayCategory(cooperator.businessSector, "Not classified"),
        classification: normalizeBusinessClassification(cooperator.enterpriseClassification),
        sex,
        age: Number(cooperator.age || 0),
        senior: Number(cooperator.age || 0) >= 60,
        pwd,
        ip,
        activeFirm,
        lat: Number(beneficiary.coordinates?.lat || beneficiary.location?.lat || beneficiary.latitude || 0),
        lng: Number(beneficiary.coordinates?.lng || beneficiary.location?.lng || beneficiary.longitude || 0)
      };
    })
    .filter((row) => {
      if (filters.district && row.district !== filters.district) return false;
      if (filters.businessSector && row.businessSector !== filters.businessSector) return false;
      if (filters.sex && row.sex !== filters.sex) return false;
      if (filters.pwd && (filters.pwd === "Yes") !== row.pwd) return false;
      if (filters.ip && (filters.ip === "Yes") !== row.ip) return false;
      return true;
    });
}

function normalizeDisplayCategory(value = "", fallback = "Not classified") {
  const text = String(value || "").trim().replace(/\s+/g, " ");
  if (!text || /^(n\/a|na|none|null|undefined|not provided|not classified|not yet classified)$/i.test(text)) return fallback;
  return text
    .toLowerCase()
    .split(" ")
    .map((part) => (part.length <= 3 && part === part.toUpperCase() ? part : part.charAt(0).toUpperCase() + part.slice(1)))
    .join(" ");
}

function normalizeSex(value = "") {
  const text = String(value || "").trim().toLowerCase();
  if (text === "m" || text === "male") return "Male";
  if (text === "f" || text === "female") return "Female";
  return "Unknown/Unspecified";
}

function normalizeBusinessType(value = "") {
  const text = String(value || "").trim().replace(/\s+/g, " ").toLowerCase();
  if (!text || /^(n\/a|na|none|null|undefined|not provided|not classified)$/i.test(text)) return "Not classified";
  if (text.includes("sole")) return "Sole Proprietorship";
  if (text.includes("coop")) return "Cooperative";
  if (text.includes("corp")) return "Corporation";
  if (text.includes("partner")) return "Partnership";
  return normalizeDisplayCategory(text);
}

function normalizeBusinessClassification(value = "") {
  const text = String(value || "").trim().replace(/\s+/g, " ").toLowerCase();
  if (text.includes("micro")) return "Micro";
  if (text.includes("small")) return "Small";
  if (text.includes("medium")) return "Medium";
  return "Other/Not classified";
}

function analyticsPercent(value, total) {
  return total > 0 ? `${((Number(value || 0) / total) * 100).toFixed(1)}%` : "0.0%";
}

function countBy(rows, key) {
  return [...rows.reduce((map, row) => map.set(row[key], (map.get(row[key]) || 0) + 1), new Map()).entries()]
    .map(([label, value]) => ({ label, value, percent: analyticsPercent(value, rows.length) }))
    .sort((a, b) => b.value - a.value || a.label.localeCompare(b.label));
}

function countByLabels(rows, labels, predicate) {
  return labels.map((label) => {
    const value = rows.filter((row) => predicate(row, label)).length;
    return { label, value, percent: analyticsPercent(value, rows.length) };
  });
}

function analyticsAgeRows(rows) {
  const buckets = [
    { label: "Below 18", test: (age) => age > 0 && age < 18 },
    { label: "18-30", test: (age) => age >= 18 && age <= 30 },
    { label: "31-45", test: (age) => age >= 31 && age <= 45 },
    { label: "46-59", test: (age) => age >= 46 && age <= 59 },
    { label: "60+", test: (age) => age >= 60 }
  ];
  return buckets.map((bucket) => {
    const value = rows.filter((row) => bucket.test(row.age)).length;
    return { label: bucket.label, value, percent: analyticsPercent(value, rows.length) };
  });
}

function analyticsDistrictRows(rows) {
  const districts = [...new Set(rows.map((row) => row.district))].sort();
  return districts.map((district) => {
    const districtRows = rows.filter((row) => row.district === district);
    return {
      label: district,
      cooperators: districtRows.length,
      firms: new Set(districtRows.map((row) => row.firmName)).size
    };
  });
}

function analyticsCard(label, value, context, iconName = "info") {
  return `<article class="analytics-card">${icon(iconName)}<span>${escapeHtml(label)}</span><strong>${escapeHtml(String(value))}</strong><small>${escapeHtml(context || "")}</small></article>`;
}

function analyticsSummaryDonutCard({ title, rows, total, iconName = "info", empty = "No data available." }) {
  const visibleRows = rows.filter((row) => Number(row.value || 0) > 0);
  let offset = 0;
  const circles = visibleRows
    .map((row, index) => {
      const share = Number(row.value || 0) / Math.max(1, total);
      const dash = `${share * 100} ${100 - share * 100}`;
      const circle = `<circle class="analytics-arc analytics-arc-${index % 5}" cx="22" cy="22" r="16" pathLength="100" stroke-dasharray="${dash}" stroke-dashoffset="${-offset}"></circle>`;
      offset += share * 100;
      return circle;
    })
    .join("");
  return `
    <article class="analytics-card analytics-summary-card analytics-summary-donut-card">
      ${icon(iconName)}
      <span>${escapeHtml(title)}</span>
      ${
        total && visibleRows.length
          ? `<div class="analytics-summary-donut">
              <svg viewBox="0 0 44 44" role="img" aria-label="${escapeHtml(rows.map((row) => `${row.label}: ${row.value} (${row.percent})`).join("; "))}">
                <title>${escapeHtml(rows.map((row) => `${row.label}: ${row.value} (${row.percent})`).join("; "))}</title>
                <circle class="analytics-track" cx="22" cy="22" r="16"></circle>
                ${circles}
                <circle class="analytics-hole" cx="22" cy="22" r="10"></circle>
              </svg>
              <strong>${escapeHtml(formatNumber(total))}</strong>
            </div>
            <div class="analytics-summary-list">
              ${rows.map((row, index) => `<p><i class="analytics-dot analytics-arc-dot-${index % 5}"></i><span>${escapeHtml(row.label)}</span><b>${escapeHtml(formatNumber(row.value))}</b><em>${escapeHtml(row.percent)}</em></p>`).join("")}
            </div>`
          : `<small>${escapeHtml(empty)}</small>`
      }
    </article>
  `;
}

function analyticsSummaryListCard({ title, rows, iconName = "info", limit = 4, empty = "No data available." }) {
  const visibleRows = rows.slice(0, limit);
  return `
    <article class="analytics-card analytics-summary-card analytics-summary-list-card">
      ${icon(iconName)}
      <span>${escapeHtml(title)}</span>
      ${
        visibleRows.length
          ? `<div class="analytics-summary-list">
              ${visibleRows.map((row, index) => `<p><i class="analytics-dot analytics-arc-dot-${index % 5}"></i><span>${escapeHtml(row.label)}</span><b>${escapeHtml(formatNumber(row.value))}</b><em>${escapeHtml(row.percent || "")}</em></p>`).join("")}
            </div>`
          : `<small>${escapeHtml(empty)}</small>`
      }
    </article>
  `;
}

function analyticsDoughnutCard({ title, rows, empty = "No demographic data available." }) {
  const total = rows.reduce((sum, row) => sum + Number(row.value || 0), 0);
  let offset = 0;
  const circles = total
    ? rows
        .map((row, index) => {
          const share = Number(row.value || 0) / total;
          const dash = `${share * 100} ${100 - share * 100}`;
          const circle = `<circle class="analytics-arc analytics-arc-${index % 5}" cx="22" cy="22" r="16" pathLength="100" stroke-dasharray="${dash}" stroke-dashoffset="${-offset}"></circle>`;
          offset += share * 100;
          return circle;
        })
        .join("")
    : "";
  return `
    <article class="analytics-panel analytics-chart-panel">
      <h3>${escapeHtml(title)}</h3>
      ${total ? `<div class="analytics-doughnut"><svg viewBox="0 0 44 44"><circle class="analytics-track" cx="22" cy="22" r="16"></circle>${circles}<circle class="analytics-hole" cx="22" cy="22" r="10"></circle></svg><strong>${total}</strong></div>` : `<div class="dashboard-empty">${escapeHtml(empty)}</div>`}
      <div class="analytics-legend">${rows.map((row) => `<span><b></b>${escapeHtml(row.label)} <strong>${formatNumber(row.value)}</strong> <em>${escapeHtml(row.percent)}</em></span>`).join("")}</div>
    </article>
  `;
}

function analyticsBarCard({ title, rows, mode = "vertical", valueKey = "value", secondaryKey = "" }) {
  const max = Math.max(1, ...rows.map((row) => Math.max(Number(row[valueKey] || 0), Number(secondaryKey ? row[secondaryKey] || 0 : 0))));
  const body = rows.length
    ? rows
        .map((row) => {
          const primary = Number(row[valueKey] || 0);
          const secondary = Number(secondaryKey ? row[secondaryKey] || 0 : 0);
          return `
            <div class="analytics-bar-row ${mode === "vertical" ? "is-vertical" : ""}">
              <span>${escapeHtml(row.label)}</span>
              <div class="analytics-bar-track">
                <i style="--bar:${(primary / max) * 100}%"></i>
                ${secondaryKey ? `<i class="secondary" style="--bar:${(secondary / max) * 100}%"></i>` : ""}
              </div>
              <strong>${formatNumber(primary)}${secondaryKey ? ` / ${formatNumber(secondary)}` : ""}</strong>
              ${row.percent ? `<em>${escapeHtml(row.percent)}</em>` : ""}
            </div>
          `;
        })
        .join("")
    : `<div class="dashboard-empty">No chart data available.</div>`;
  return `<article class="analytics-panel analytics-bar-panel"><h3>${escapeHtml(title)}</h3>${body}</article>`;
}

function getMunicipalityIntensity(count, allCounts) {
  if (!count) return "none";
  const positiveCounts = [...new Set(allCounts.map((value) => Number(value || 0)).filter((value) => value > 0))].sort((a, b) => a - b);
  if (positiveCounts.length <= 1) return "low";
  const lowCutoff = positiveCounts[Math.floor((positiveCounts.length - 1) / 3)];
  const highCutoff = positiveCounts[Math.ceil(((positiveCounts.length - 1) * 2) / 3)];
  if (count >= highCutoff) return "high";
  if (count > lowCutoff) return "medium";
  return "low";
}

function groupFirmsByMunicipality(rows) {
  const groups = new Map(
    municipalityMapPoints.map((item) => [
      item.name,
      {
        label: item.name,
        district: item.district,
        value: 0,
        rows: [],
        coordinates: item.coordinates
      }
    ])
  );
  rows.forEach((row) => {
    const municipality = normalizeMunicipality(row.municipality);
    if (!groups.has(municipality)) {
      groups.set(municipality, {
        label: municipality,
        district: municipality === noMunicipalityLabel ? "No District" : getMunicipalityDistrictName(municipality),
        value: 0,
        rows: [],
        coordinates: getMunicipalityCoordinates(municipality)
      });
    }
    const group = groups.get(municipality);
    // Analytics rows are one row per cooperator/firm, so this maps firm concentration without double-counting setup phases.
    group.value += 1;
    group.rows.push(row);
  });
  return [...groups.values()].sort((a, b) => {
    if (a.label === noMunicipalityLabel) return 1;
    if (b.label === noMunicipalityLabel) return -1;
    return b.value - a.value || a.label.localeCompare(b.label);
  });
}

function analyticsMap(rows, filters) {
  const baseQuery = {
    tab: "analytics",
    district: filters.district || "",
    businessSector: filters.businessSector || "",
    sex: filters.sex || "",
    pwd: filters.pwd || "",
    ip: filters.ip || ""
  };
  const distribution = groupFirmsByMunicipality(rows);
  const total = rows.length;
  const mappedCounts = distribution.filter((group) => group.coordinates).map((group) => group.value);
  const selectedMunicipality = distribution.some((group) => group.label === filters.mapFocus) ? filters.mapFocus : "";
  const linkFor = (municipality) => routeHref(`/?${new URLSearchParams({ ...baseQuery, mapFocus: municipality }).toString()}`);
  const mapGroups = distribution
    .filter((group) => group.coordinates)
    .map((group) => {
      const intensity = getMunicipalityIntensity(group.value, mappedCounts);
      return {
        label: group.label,
        district: group.district,
        value: group.value,
        percent: analyticsPercent(group.value, total),
        intensity,
        coordinates: group.coordinates,
        selected: selectedMunicipality === group.label,
        link: linkFor(group.label)
      };
    });
  const mapPayload = encodeURIComponent(JSON.stringify({ groups: mapGroups, bounds: ilocosSurBounds, fitPoints: municipalityMapBounds, selected: selectedMunicipality }));
  const municipalityChips = distribution
    .filter((group) => group.value > 0 || group.label === noMunicipalityLabel || selectedMunicipality === group.label)
    .map((group) => {
      const activeClass = selectedMunicipality === group.label ? " is-selected" : "";
      const level = group.label === noMunicipalityLabel ? "none" : getMunicipalityIntensity(group.value, mappedCounts);
      return `<a href="${linkFor(group.label)}" data-link class="analytics-district-chip heat-${level}${activeClass}"><span>${escapeHtml(group.label)}</span><strong>${formatNumber(group.value)}</strong><em>${escapeHtml(analyticsPercent(group.value, total))}</em></a>`;
    })
    .join("");
  const selectedGroup = selectedMunicipality ? distribution.find((group) => group.label === selectedMunicipality) : null;
  const firmRows = selectedGroup?.rows || [];
  const firmList = selectedMunicipality
    ? firmRows.length
      ? `<div class="analytics-firm-list">${firmRows
          .slice(0, 40)
          .map((row) => `<p><b>${escapeHtml(row.firmName || "Unnamed firm")}</b><span>${escapeHtml(row.cooperatorName || "No cooperator")} · ${escapeHtml(row.municipality)} · ${escapeHtml(row.businessType)} · ${escapeHtml(row.classification)}</span></p>`)
          .join("")}</div>`
      : `<div class="dashboard-empty">No firms match ${escapeHtml(selectedMunicipality)} under the current filters.</div>`
    : `<div class="dashboard-empty">Select a municipality to view firms.</div>`;
  return `
    <article class="analytics-panel analytics-map-panel">
      <div class="analytics-panel-head">
        <div><h3>SETUP Cooperators Distribution Map</h3><p>Pan and zoom the map. Heatmap shows firm concentration by municipality.</p></div>
      </div>
      <div class="analytics-map-canvas" data-leaflet-map data-map-payload="${escapeHtml(mapPayload)}">
        <div class="dashboard-empty analytics-map-loading">Loading municipality map...</div>
        <div class="analytics-map-legend"><strong>Firm Concentration</strong><span><i class="heat-low"></i>Low</span><span><i class="heat-medium"></i>Medium</span><span><i class="heat-high"></i>High</span></div>
      </div>
      <p class="analytics-map-note">Using validated municipality center points; no municipality boundary GeoJSON is bundled with this project.</p>
      <div class="analytics-district-summary analytics-municipality-summary">${municipalityChips || `<div class="dashboard-empty">No municipality data available.</div>`}</div>
      <div class="analytics-map-popup">
        <strong>Firms in Selected Municipality${selectedMunicipality ? `: ${escapeHtml(selectedMunicipality)}` : ""}</strong>
        <small>${selectedMunicipality ? `${formatNumber(firmRows.length)} of ${formatNumber(total)} filtered cooperators` : "Current filters are respected."}</small>
        ${firmList}
      </div>
    </article>
  `;
}

function getAnalyticsDashboard(filters = {}) {
  const rows = analyticsRows(filters);
  const sexRows = countByLabels(rows, ["Male", "Female", "Unknown/Unspecified"], (row, label) => row.sex === label);
  const seniorRows = [
    { label: "Senior", value: rows.filter((row) => row.senior).length },
    { label: "Non-Senior", value: rows.filter((row) => !row.senior).length }
  ].map((row) => ({ ...row, percent: analyticsPercent(row.value, rows.length) }));
  const pwdRows = [
    { label: "PWD", value: rows.filter((row) => row.pwd).length },
    { label: "Non-PWD", value: rows.filter((row) => !row.pwd).length }
  ].map((row) => ({ ...row, percent: analyticsPercent(row.value, rows.length) }));
  const ipRows = [
    { label: "IP", value: rows.filter((row) => row.ip).length },
    { label: "Non-IP", value: rows.filter((row) => !row.ip).length }
  ].map((row) => ({ ...row, percent: analyticsPercent(row.value, rows.length) }));
  const priorityRows = [
    { label: "Senior Citizens", value: seniorRows[0].value },
    { label: "PWD", value: pwdRows[0].value },
    { label: "IP", value: ipRows[0].value }
  ].map((row) => ({ ...row, percent: analyticsPercent(row.value, rows.length) }));
  const businessTypeRows = countBy(rows, "businessType");
  const businessSectorRows = countBy(rows, "businessSector");
  const classificationRows = countByLabels(rows, ["Micro", "Small", "Medium", "Other/Not classified"], (row, label) => row.classification === label);
  const districtSummaryRows = countByLabels(rows, ["First District", "Second District", "No District"], (row, label) => row.district === label);
  const topBusinessTypeRows = businessTypeRows.filter((row) => row.label !== "Not classified");
  const topBusinessTypes = (topBusinessTypeRows.length ? topBusinessTypeRows : businessTypeRows).slice(0, 3);
  return {
    rows,
    sexRows,
    ageRows: analyticsAgeRows(rows),
    seniorRows,
    pwdRows,
    ipRows,
    priorityRows,
    businessTypeRows,
    businessSectorRows,
    classificationRows,
    districtSummaryRows,
    topBusinessTypes,
    districtRows: analyticsDistrictRows(rows),
    summary: {
      total: rows.length,
      male: sexRows[0].value,
      female: sexRows[1].value,
      seniors: seniorRows[0].value,
      pwd: pwdRows[0].value,
      ip: ipRows[0].value,
      activeFirms: rows.filter((row) => row.activeFirm).length,
      districts: new Set(rows.map((row) => row.district)).size,
      topBusinessType: topBusinessTypes[0]?.label || "No data",
      topClassification: classificationRows.find((row) => row.value > 0)?.label || "No data"
    }
  };
}

function renderAnalyticsDashboard() {
  const query = getQuery();
  const filters = {
    tab: "analytics",
    district: query.district || "",
    businessSector: query.businessSector || "",
    sex: query.sex || "",
    pwd: query.pwd || "",
    ip: query.ip || "",
    mapFocus: query.mapFocus || ""
  };
  const analytics = getAnalyticsDashboard(filters);
  const summaryCards = [
    analyticsCard("Total Cooperators", analytics.summary.total, "Matching current filters", "users"),
    analyticsSummaryListCard({ title: "Gender Distribution", rows: analytics.sexRows, iconName: "users", limit: 3, empty: "No gender data available." }),
    analyticsSummaryListCard({ title: "Priority Groups", rows: analytics.priorityRows, iconName: "check", limit: 3, empty: "No priority group data available." }),
    analyticsSummaryListCard({ title: "District Distribution", rows: analytics.districtSummaryRows, iconName: "dashboard", limit: 3, empty: "No district data available." }),
    analyticsSummaryListCard({ title: "Type of Business", rows: analytics.topBusinessTypes, iconName: "folder", limit: 3, empty: "No business type data available." }),
    analyticsSummaryListCard({ title: "Enterprise Classification", rows: analytics.classificationRows, iconName: "report", limit: 4, empty: "No classification data available." })
  ];
  const districts = [...new Set(analyticsRows({}).map((row) => row.district))].sort();
  const sectors = [...new Set(analyticsRows({}).map((row) => row.businessSector))].sort();
  return `
    <section class="analytics-dashboard" aria-label="Demographics and analytics dashboard">
      <div class="analytics-toolbar">
        <label>District <select data-analytics-filter="district"><option value="">All districts</option>${districts.map((item) => `<option value="${escapeHtml(item)}" ${item === filters.district ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
        <label>Business Sector <select data-analytics-filter="businessSector"><option value="">All sectors</option>${sectors.map((item) => `<option value="${escapeHtml(item)}" ${item === filters.businessSector ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
        <label>Sex <select data-analytics-filter="sex"><option value="">All</option>${["Male", "Female", "Not specified"].map((item) => `<option value="${escapeHtml(item)}" ${item === filters.sex ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
        <label>PWD Status <select data-analytics-filter="pwd"><option value="">All</option>${["Yes", "No"].map((item) => `<option value="${item}" ${item === filters.pwd ? "selected" : ""}>${item}</option>`).join("")}</select></label>
        <label>IP Status <select data-analytics-filter="ip"><option value="">All</option>${["Yes", "No"].map((item) => `<option value="${item}" ${item === filters.ip ? "selected" : ""}>${item}</option>`).join("")}</select></label>
        <button class="btn btn-ghost" type="button" data-action="reset-analytics">Reset</button>
        <button class="btn btn-secondary" type="button" data-action="export-analytics-pdf">${icon("download")}<span>Export PDF</span></button>
        <button class="btn btn-secondary" type="button" data-action="export-analytics-excel">${icon("download")}<span>Export Excel</span></button>
        <button class="btn btn-secondary" type="button" data-action="print-page">${icon("print")}<span>Print Dashboard</span></button>
      </div>
      <section class="analytics-summary-grid analytics-summary-grid-balanced">${summaryCards.join("")}</section>
      <section class="analytics-chart-grid">
        ${analyticsDoughnutCard({ title: "Gender Distribution", rows: analytics.sexRows })}
        ${analyticsBarCard({ title: "Age Distribution", rows: analytics.ageRows, mode: "vertical" })}
        ${analyticsDoughnutCard({ title: "Senior Citizen Distribution", rows: analytics.seniorRows })}
        ${analyticsDoughnutCard({ title: "PWD Distribution", rows: analytics.pwdRows })}
        ${analyticsDoughnutCard({ title: "IP Distribution", rows: analytics.ipRows })}
        ${analyticsBarCard({ title: "Type of Business", rows: analytics.businessTypeRows, mode: "horizontal" })}
        ${analyticsBarCard({ title: "Business Sector Distribution", rows: analytics.businessSectorRows, mode: "horizontal" })}
        ${analyticsBarCard({ title: "Enterprise Classification", rows: analytics.classificationRows, mode: "horizontal" })}
        ${analyticsBarCard({ title: "Firm/District Distribution", rows: analytics.districtRows, valueKey: "cooperators", secondaryKey: "firms" })}
      </section>
      ${analyticsMap(analytics.rows, filters)}
    </section>
  `;
}

function renderDashboard() {
  const filters = getQuery();
  const activeTab = filters.tab === "analytics" ? "analytics" : "collection";
  const asOf = filters.asOf || todayIso();
  const year = filters.year || "";
  const overview = dashboardService.getSystemOverview({ ...filters, asOf });
  const setupSummary = dashboardService.getSetupRefundDashboard({ year, asOf });
  const sourceSummary = dashboardService.getSummary({ asOf });
  const overdueTotal = setupSummary.delinquentPayors.reduce((sum, item) => sum + Number(item.totalOverdueArrears || 0), 0);
  const collectionRate = setupSummary.monthlyTarget > 0 ? percent(setupSummary.monthlyCollection, setupSummary.monthlyTarget) : 0;
  const dueRows = getUpcomingRefundRows(asOf);
  const yearChoices = Array.from(
    new Set([year, ...repository.getSnapshot().beneficiaries.map((item) => String(item.project?.projectYear || "")).filter(Boolean)])
  ).sort((a, b) => Number(b) - Number(a));
  const kpis = [
    {
      label: "Total SETUP Cooperators",
      value: String(setupSummary.totalSetupCooperators || setupSummary.totalSetupCustomers),
      context: "From the SETUP refund source records",
      tone: "green",
      iconName: "users",
      route: "/beneficiaries"
    },
    {
      label: "Active SETUP Refund",
      value: String(setupSummary.activeSetupRefundCount),
      context: `Outstanding ${formatCurrency(setupSummary.activeSetupOutstanding)}`,
      tone: "navy",
      iconName: "cash",
      route: "/setup-refund?projectStatus=Ongoing"
    },
    {
      label: "Monthly Collection",
      value: formatCurrency(setupSummary.monthlyCollection),
      context: `${collectionRate.toFixed(1)}% of cutoff target as of ${formatDate(asOf)}`,
      tone: "green",
      iconName: "check",
      route: "/collections"
    },
    {
      label: "Overdue Arrears",
      value: formatCurrency(overdueTotal),
      context: `${setupSummary.delinquentPayors.length} delinquent account(s)`,
      tone: "navy",
      iconName: "alert",
      route: "/setup-refund"
    }
  ];
  return `
    <section class="reference-dashboard" aria-label="DOST IS SETUP dashboard">
      <div class="reference-dashboard-decor" aria-hidden="true"></div>
      <header class="reference-dashboard-head">
        <div>
          <h1>DOST IS SETUP PROJECTS</h1>
          <p>Refund collection dashboard based on the Ilocos Sur SETUP repayment workbook and current system records.</p>
        </div>
        <div class="reference-dashboard-actions">
          ${
            activeTab === "collection"
              ? `<label>Year <select data-dashboard-filter="year"><option value="" ${year ? "" : "selected"}>All years</option>${yearChoices.map((item) => `<option value="${escapeHtml(item)}" ${String(item) === String(year) ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
                 <label>As of <input type="date" data-dashboard-filter="asOf" value="${escapeHtml(asOf)}" /></label>`
              : ""
          }
          <button class="btn btn-secondary" type="button" data-action="refresh-dashboard">${icon("refresh")}<span>Refresh</span></button>
        </div>
      </header>
      ${dashboardTabs(activeTab)}
      ${
        activeTab === "analytics"
          ? renderAnalyticsDashboard()
          : `
            <section class="reference-kpi-grid">${kpis.map((item) => referenceKpiCard(item)).join("")}</section>
            <section class="reference-main-grid">
              ${referenceComparisonChart({
                title: "Target vs Collection",
                description: `Cutoff-period target compared with actual collection. ${yearContext(year)}.`,
                rows: setupSummary.monthlyPerformance
              })}
              ${referenceLineChart({
                title: "Refund Collection Trend",
                description: `Collection rate by cutoff period. ${yearContext(year)}.`,
                rows: setupSummary.monthlyPerformance,
                valueKey: "rate",
                format: "percent",
                legend: "Collection Rate",
                axisY: "Collection Rate"
              })}
            </section>
            <section class="reference-lower-grid">
              ${referenceDueTable(dueRows)}
              ${referenceDonutCard({
                title: "Services Availed",
                data: overview.charts.byServiceCategory,
                footer: overview.charts.byServiceCategory[0] ? `Highest: ${overview.charts.byServiceCategory[0].label}` : ""
              })}
              ${referenceDonutCard({
                title: "SETUP Status Overview",
                data: overview.charts.bySetupStatus,
                showValues: true
              })}
            </section>
            ${referenceSourceGraphs({ charts: { ...sourceSummary.charts, setupFundByYear: setupSummary.charts.setupFundByYear } })}
            <footer class="reference-dashboard-foot">
              <span>Last updated ${new Date().toLocaleString("en-PH", { dateStyle: "medium", timeStyle: "short" })}</span>
              <button class="btn btn-ghost" type="button" data-action="reset-dashboard">Reset filters</button>
              ${buttonLink("/setup-refund", "Open Detailed SETUP Dashboard", "dashboard", "secondary")}
            </footer>
          `
      }
    </section>
  `;
}

function bindDashboard() {
  document.querySelectorAll("[data-dashboard-filter]").forEach((control) => {
    control.addEventListener("change", () => {
      const filters = {};
      document.querySelectorAll("[data-dashboard-filter]").forEach((item) => {
        filters[item.dataset.dashboardFilter] = item.value;
      });
      setQuery("/", filters);
    });
  });
  document.querySelector("[data-action='reset-dashboard']")?.addEventListener("click", () => navigate("/"));
  document.querySelector("[data-action='refresh-dashboard']")?.addEventListener("click", async () => {
    try {
      await repository.reload();
      createToast("Dashboard refreshed from Supabase.");
      renderApp();
    } catch (error) {
      console.error(error);
      createToast("Could not refresh Supabase data.", "danger");
    }
  });
  document.querySelectorAll("[data-analytics-filter]").forEach((control) => {
    control.addEventListener("change", () => {
      const filters = { tab: "analytics" };
      document.querySelectorAll("[data-analytics-filter]").forEach((item) => {
        filters[item.dataset.analyticsFilter] = item.value;
      });
      setQuery("/", filters);
    });
  });
  document.querySelector("[data-action='reset-analytics']")?.addEventListener("click", () => navigate("/?tab=analytics"));
  bindAnalyticsMunicipalityMap();
  document.querySelector("[data-action='print-page']")?.addEventListener("click", () => window.print());
  document.querySelector("[data-action='export-analytics-excel']")?.addEventListener("click", () => {
    const analytics = getAnalyticsDashboard({ ...getQuery(), tab: "analytics" });
    downloadXlsx(
      `dost-demographics-analytics-${todayIso()}.xlsx`,
      "Analytics",
      analytics.rows.map((row) => ({
        "Firm Name": row.firmName,
        "Cooperator Name": row.cooperatorName,
        Sex: row.sex,
        Age: row.age || "",
        "Senior Citizen": row.senior ? "Yes" : "No",
        PWD: row.pwd ? "Yes" : "No",
        IP: row.ip ? "Yes" : "No",
        "Business Type": row.businessType,
        "Business Sector": row.businessSector,
        Municipality: row.municipality,
        District: row.district,
        "Active Firm": row.activeFirm ? "Yes" : "No"
      }))
    );
    createToast("Demographics analytics exported to Excel.");
  });
  document.querySelector("[data-action='export-analytics-pdf']")?.addEventListener("click", () => {
    const analytics = getAnalyticsDashboard({ ...getQuery(), tab: "analytics" });
    downloadPdf(
      `dost-demographics-analytics-${todayIso()}.pdf`,
      "DOST IS SETUP Demographics & Analytics",
      analytics.rows.map((row) => ({
        Firm: row.firmName,
        Cooperator: row.cooperatorName,
        Sex: row.sex,
        Age: row.age || "",
        District: row.district,
        Sector: row.businessSector
      }))
    );
    createToast("Demographics analytics PDF exported.");
  });
}

function loadLeaflet() {
  if (window.L) return Promise.resolve(window.L);
  if (leafletLoadPromise) return leafletLoadPromise;
  leafletLoadPromise = new Promise((resolve, reject) => {
    if (!document.querySelector(`link[href="${leafletAssets.css}"]`)) {
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = leafletAssets.css;
      document.head.append(link);
    }
    const existing = document.querySelector(`script[src="${leafletAssets.js}"]`);
    if (existing) {
      existing.addEventListener("load", () => resolve(window.L), { once: true });
      existing.addEventListener("error", reject, { once: true });
      return;
    }
    const script = document.createElement("script");
    script.src = leafletAssets.js;
    script.onload = () => resolve(window.L);
    script.onerror = reject;
    document.head.append(script);
  });
  return leafletLoadPromise;
}

function bindAnalyticsMunicipalityMap() {
  const container = document.querySelector("[data-leaflet-map]");
  if (!container) return;
  let payload = { groups: [], bounds: ilocosSurBounds, selected: "" };
  try {
    payload = JSON.parse(decodeURIComponent(container.dataset.mapPayload || ""));
  } catch (error) {
    console.warn("Unable to parse municipality map payload.", error);
  }
  loadLeaflet()
    .then((L) => {
      container.innerHTML = `<div class="analytics-leaflet-map" data-leaflet-canvas></div>${container.querySelector(".analytics-map-legend")?.outerHTML || ""}`;
      const mapNode = container.querySelector("[data-leaflet-canvas]");
      const map = L.map(mapNode, { scrollWheelZoom: false, zoomControl: true, attributionControl: true });
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 18,
        attribution: "&copy; OpenStreetMap contributors"
      }).addTo(map);
      const bounds = L.latLngBounds(payload.bounds || payload.fitPoints || ilocosSurBounds);
      map.fitBounds(bounds, { padding: [34, 34] });
      const colors = { low: "#2563eb", medium: "#f59e0b", high: "#b91c1c", none: "#cbd5e1" };
      const max = Math.max(1, ...payload.groups.map((group) => Number(group.value || 0)));
      payload.groups.forEach((group) => {
        const value = Number(group.value || 0);
        const radius = value ? Math.min(10, Math.max(6, 6 + (value / max) * 4)) : 3.5;
        const intensityLabel = group.intensity === "none" ? "No Data" : group.intensity.charAt(0).toUpperCase() + group.intensity.slice(1);
        const marker = L.circleMarker(group.coordinates, {
          radius,
          color: group.selected ? "#0f2f66" : "#ffffff",
          weight: group.selected ? 4 : 2,
          fillColor: colors[group.intensity] || colors.none,
          fillOpacity: value ? 0.88 : 0.5
        }).addTo(map);
        marker.bindTooltip(`<b>${escapeHtml(group.label)}</b><br>Firms: ${formatNumber(value)}<br>Share: ${escapeHtml(group.percent)}<br>Intensity: ${escapeHtml(intensityLabel)}`, { sticky: true });
        marker.bindPopup(`<b>${escapeHtml(group.label)}</b><br>Firms: ${formatNumber(value)}<br>Share: ${escapeHtml(group.percent)}<br>Intensity: ${escapeHtml(intensityLabel)}<br>${escapeHtml(group.district)}`);
        marker.on("mouseover", () => marker.setStyle({ weight: 4, color: "#0f2f66" }));
        marker.on("mouseout", () => marker.setStyle({ weight: group.selected ? 4 : 2, color: group.selected ? "#0f2f66" : "#ffffff" }));
        marker.on("click", () => navigate(group.link.replace(/^#/, "")));
      });
      if (payload.selected) {
        const selected = payload.groups.find((group) => group.selected);
        if (selected) map.setView(selected.coordinates, Math.max(map.getZoom(), 11), { animate: false });
      }
      setTimeout(() => map.invalidateSize(), 80);
    })
    .catch(() => {
      const list = payload.groups.length
        ? payload.groups.map((group) => `<p><b>${escapeHtml(group.label)}</b><span>${formatNumber(group.value)} firms · ${escapeHtml(group.percent)} · ${escapeHtml(group.intensity)}</span></p>`).join("")
        : `<div class="dashboard-empty">No municipality coordinates available for the current filters.</div>`;
      container.innerHTML = `<div class="analytics-map-fallback"><strong>Map unavailable</strong><span>Leaflet or OpenStreetMap tiles could not load. Municipality counts remain available below.</span>${list}</div>${container.querySelector(".analytics-map-legend")?.outerHTML || ""}`;
    });
}

function renderSetupRefundDashboard() {
  const query = getQuery();
  const filters = {
    year: query.year || "",
    asOf: query.asOf || todayIso(),
    municipality: query.municipality || "",
    district: query.district || "",
    businessSector: query.businessSector || "",
    officer: query.officer || "",
    phase: query.phase || "",
    cooperatorId: query.cooperatorId || "",
    projectStatus: query.projectStatus || ""
  };
  const summary = dashboardService.getSetupRefundDashboard(filters);
  const cards = [
    ["Total SETUP Cooperators", summary.totalSetupCooperators || summary.totalSetupCustomers, "All non-archived cooperators with SETUP", "users", ""],
    ["Active SETUP Refund", summary.activeSetupRefundCount, `Outstanding ${formatCurrency(summary.activeSetupOutstanding)}`, "cash", ""],
    ["Monthly Target Refund for Collection", formatCurrency(summary.monthlyTarget), `Cutoff ${formatDate(summary.selectedPeriod?.start)} to ${formatDate(summary.selectedPeriod?.end)}`, "calendar", ""],
    ["Monthly Collection as of Today", formatCurrency(summary.monthlyCollection), `Valid collections through ${formatDate(filters.asOf)}`, "check", ""]
  ];
  const delinquentRows = summary.delinquentPayors;
  return `
    ${pageHeader({
      title: "SETUP Refund",
      eyebrow: "Monitoring and Evaluation",
      description: "Collection target, valid monthly collection, refund performance percentage, and active overdue SETUP accounts.",
      actions: `${buttonLink("/collections/new", "Record Payment", "cash", "primary")}<button class="btn btn-secondary" type="button" data-action="print-page">${icon("print")}<span>Print</span></button>`
    })}
    <section class="control-panel setup-filter-panel">
      <label>Year <select data-setup-filter="year"><option value="" ${filters.year ? "" : "selected"}>All years</option>${Array.from(new Set([filters.year, ...repository.getSnapshot().beneficiaries.map((item) => String(item.project?.projectYear || "")).filter(Boolean)])).sort((a, b) => Number(b) - Number(a)).map((year) => `<option value="${year}" ${String(year) === String(filters.year) ? "selected" : ""}>${year}</option>`).join("")}</select></label>
      <label>As of Date <input type="date" data-setup-filter="asOf" value="${escapeHtml(filters.asOf)}" /></label>
      <label>Cooperator <select data-setup-filter="cooperatorId"><option value="">All</option>${beneficiaryService.list().map((item) => ({ id: item.id, name: getCooperatorView(item).firmName })).sort((a, b) => a.name.localeCompare(b.name)).map((item) => `<option value="${escapeHtml(item.id)}" ${item.id === filters.cooperatorId ? "selected" : ""}>${escapeHtml(item.name)}</option>`).join("")}</select></label>
      <label>Municipality <select data-setup-filter="municipality"><option value="">All</option>${lookups.municipalities.map((item) => `<option value="${escapeHtml(item)}" ${item === filters.municipality ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <label>District <select data-setup-filter="district"><option value="">All</option>${lookups.districts.map((item) => `<option value="${escapeHtml(item)}" ${item === filters.district ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <label>Business Sector <select data-setup-filter="businessSector"><option value="">All</option>${lookups.businessSectors.map((item) => `<option value="${escapeHtml(item)}" ${item === filters.businessSector ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <label>Assigned Project Officer <select data-setup-filter="officer"><option value="">All</option>${summary.filters.officers.map((item) => `<option value="${escapeHtml(item)}" ${item === filters.officer ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <label>SETUP Phase <select data-setup-filter="phase"><option value="">All</option>${summary.filters.phases.map((item) => `<option value="${escapeHtml(item)}" ${item === filters.phase ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <label>Project Status <select data-setup-filter="projectStatus"><option value="">All</option>${lookups.setupProjectStatuses.map((item) => `<option value="${escapeHtml(item)}" ${item === filters.projectStatus ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <button class="btn btn-ghost" type="button" data-action="reset-setup-dashboard">Reset filters</button>
      <span class="last-updated">Last updated ${escapeHtml(summary.lastUpdated)}</span>
      ${filterChips(Object.fromEntries(Object.entries(filters).filter(([key, value]) => value && !(key === "year" && value === todayIso().slice(0, 4)) && !(key === "asOf" && value === todayIso()))))}
    </section>
    <section class="summary-grid setup-kpis">${cards.map(([label, value, context, iconName]) => summaryCard({ label, value: String(value), context, iconName })).join("")}</section>
    ${collectionPerformanceChart(summary.monthlyPerformance)}
    <details class="panel underlying-data">
      <summary>Show underlying monthly values</summary>
      ${dashboardTableCard({
        title: "Monthly Values",
        description: "Values used for Monthly SETUP Refund Performance.",
        rows: summary.monthlyPerformance,
        columns: [
          { key: "label", label: "Month", render: (row) => escapeHtml(row.label) },
          { key: "target", label: "Target Refund", align: "right", render: (row) => formatCurrency(row.target) },
          { key: "actual", label: "Collected Refund", align: "right", render: (row) => formatCurrency(row.actual) },
          { key: "rate", label: "Refund Performance", align: "right", render: (row) => (row.noTarget ? "0.0%" : `${Number(row.rate || 0).toFixed(1)}%`) }
        ]
      })}
    </details>
    ${dashboardTableCard({
      title: "List of Delinquent Payors",
      description: "Only unpaid or partially unpaid obligations whose grace period has already ended are counted.",
      rows: delinquentRows,
      columns: [
        { key: "firmName", label: "Name of Firm", render: (row) => `<strong class="dashboard-row-label">${escapeHtml(row.firmName)}</strong>` },
        { key: "totalOverdueArrears", label: "Total Overdue Arrears", align: "right", render: (row) => formatCurrency(row.totalOverdueArrears) },
        { key: "delayedMonths", label: "Delayed Since", render: (row) => `${row.delayedMonths} ${row.delayedMonths === 1 ? "month" : "months"}` },
        { key: "actions", label: "Action", render: (row) => `<a class="btn btn-secondary" href="/beneficiaries/${row.id}" data-link>View Account</a>` }
      ],
      emptyMessage: "No active SETUP accounts are currently overdue.",
      className: "delinquent-panel"
    })}
    <section class="dashboard-grid supporting-charts">
      ${svgChartCard({ title: "SETUP Accounts by Business Sector", data: summary.charts.byBusinessSector })}
      ${svgChartCard({ title: "SETUP Accounts by District", data: summary.charts.byDistrict })}
      ${svgChartCard({ title: "SETUP Project Status Overview", data: summary.charts.byProjectStatus })}
    </section>
  `;
}

function bindSetupRefundDashboard() {
  document.querySelectorAll("[data-setup-filter]").forEach((control) => {
    control.addEventListener("change", () => {
      const filters = {};
      document.querySelectorAll("[data-setup-filter]").forEach((item) => {
        filters[item.dataset.setupFilter] = item.value;
      });
      setQuery("/setup-refund", filters);
    });
  });
  document.querySelector("[data-action='reset-setup-dashboard']")?.addEventListener("click", () => navigate("/setup-refund"));
  document.querySelector("[data-action='print-page']")?.addEventListener("click", () => window.print());
}

function statusReportFilters(query = {}) {
  const officerOptions = [...new Set(beneficiaryService.list().map((item) => getCooperatorView(item).setup.assignedProjectOfficer).filter(Boolean))].sort();
  const cooperatorOptions = beneficiaryService.list().map((item) => ({ id: item.id, name: getCooperatorView(item).firmName })).sort((a, b) => a.name.localeCompare(b.name));
  return `
    <section class="control-panel report-filters">
      <label>As-of date <input type="date" data-pis-filter="asOf" value="${escapeHtml(query.asOf || todayIso())}" /></label>
      <label>Cooperator <select data-pis-filter="cooperatorId"><option value="">All</option>${cooperatorOptions.map((item) => `<option value="${escapeHtml(item.id)}" ${item.id === query.cooperatorId ? "selected" : ""}>${escapeHtml(item.name)}</option>`).join("")}</select></label>
      <label>Project year <select data-pis-filter="year"><option value="">All</option>${yearOptions(query.year)}</select></label>
      <label>Municipality <select data-pis-filter="municipality"><option value="">All</option>${lookups.municipalities.map((item) => `<option ${item === query.municipality ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <label>District <select data-pis-filter="district"><option value="">All</option>${lookups.districts.map((item) => `<option ${item === query.district ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <label>Business sector <select data-pis-filter="businessSector"><option value="">All</option>${lookups.businessSectors.map((item) => `<option ${item === query.businessSector ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <label>Assigned Project Officer <select data-pis-filter="officer"><option value="">All</option>${officerOptions.map((item) => `<option ${item === query.officer ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <label>Project status <select data-pis-filter="projectStatus"><option value="">All</option>${lookups.setupProjectStatuses.map((item) => `<option ${item === query.projectStatus ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <button class="btn btn-ghost" type="button" data-action="reset-pis-report">Reset filters</button>
    </section>
  `;
}

function renderStatusReportPis() {
  const query = getQuery();
  const type = "SETUP Project Report";
  const rows = reportService.getPreview(type, query);
  return `
    ${pageHeader({ title: "Status Report PIS", eyebrow: "Monitoring and Evaluation", description: "SETUP project status report sourced from current cooperator and project records.", actions: "" })}
    ${statusReportFilters(query)}
    <section class="action-row">
      <button class="btn btn-secondary" type="button" data-action="print-page">${icon("print")} Print</button>
      <button class="btn btn-secondary" type="button" data-action="export-pis-csv">${icon("download")} Export CSV</button>
      <button class="btn btn-secondary" type="button" data-action="export-pis-xlsx">Export Excel</button>
      <button class="btn btn-secondary" type="button" data-action="export-pis-pdf">Export PDF</button>
    </section>
    ${reportPreview("Status Report PIS", query, rows)}
  `;
}

function bindStatusReportPis() {
  document.querySelectorAll("[data-pis-filter]").forEach((control) => {
    control.addEventListener("change", () => {
      const filters = {};
      document.querySelectorAll("[data-pis-filter]").forEach((item) => {
        filters[item.dataset.pisFilter] = item.value;
      });
      setQuery("/status-report-pis", filters);
    });
  });
  document.querySelector("[data-action='reset-pis-report']")?.addEventListener("click", () => navigate("/status-report-pis"));
  document.querySelector("[data-action='print-page']")?.addEventListener("click", () => window.print());
  document.querySelector("[data-action='export-pis-csv']")?.addEventListener("click", () => {
    const rows = reportService.getPreview("SETUP Project Report", getQuery());
    const columns = Object.keys(rows[0] || {});
    downloadCsv("status-report-pis.csv", [columns, ...rows.map((row) => columns.map((key) => row[key]))]);
  });
  document.querySelector("[data-action='export-pis-xlsx']")?.addEventListener("click", () => {
    downloadXlsx("status-report-pis.xlsx", "Status Report PIS", reportService.getPreview("SETUP Project Report", getQuery()));
  });
  document.querySelector("[data-action='export-pis-pdf']")?.addEventListener("click", () => {
    downloadPdf("status-report-pis.pdf", "Status Report PIS", reportService.getPreview("SETUP Project Report", getQuery()));
  });
}

function renderKpiPage() {
  const query = getQuery();
  const asOf = query.asOf || todayIso();
  const summary = dashboardService.getSummary({ ...query, asOf });
  const setupSummary = dashboardService.getSetupRefundDashboard({ ...query, asOf });
  const overdueTotal = setupSummary.delinquentPayors.reduce((sum, item) => sum + Number(item.totalOverdueArrears || 0), 0);
  const performance = setupSummary.monthlyTarget > 0 ? percent(setupSummary.monthlyCollection, setupSummary.monthlyTarget) : 0;
  const rows = [
    { label: "SETUP Refund Performance", value: `${performance.toFixed(1)}%`, context: `${formatCurrency(setupSummary.monthlyCollection)} collected / ${formatCurrency(setupSummary.monthlyTarget)} target`, iconName: "check" },
    { label: "Overall Collection Rate", value: `${summary.collectionRate.toFixed(1)}%`, context: "Collected versus repayable", iconName: "dashboard" },
    { label: "Active SETUP Refund", value: String(setupSummary.activeSetupRefundCount), context: `Outstanding ${formatCurrency(setupSummary.activeSetupOutstanding)}`, iconName: "cash" },
    { label: "Overdue Arrears", value: formatCurrency(overdueTotal), context: `${setupSummary.delinquentPayors.length} delinquent account(s)`, iconName: "alert" },
    { label: "Fully Paid Accounts", value: String(summary.fullyPaidAccounts), context: "Completed repayment", iconName: "check" },
    { label: "Past Due", value: formatCurrency(summary.pastDue), context: "Accounts needing follow-up", iconName: "alert" }
  ];
  return `
    ${pageHeader({ title: "KPI", eyebrow: "Monitoring and Evaluation", description: "Key performance indicators calculated from current SETUP refund and collection records.", actions: `<button class="btn btn-secondary" type="button" data-action="print-page">${icon("print")}<span>Print</span></button>` })}
    <section class="control-panel">
      <label>As-of date <input type="date" data-kpi-filter="asOf" value="${escapeHtml(asOf)}" /></label>
      <label>Cooperator <select data-kpi-filter="cooperatorId"><option value="">All</option>${beneficiaryService.list().map((item) => ({ id: item.id, name: getCooperatorView(item).firmName })).sort((a, b) => a.name.localeCompare(b.name)).map((item) => `<option value="${escapeHtml(item.id)}" ${item.id === query.cooperatorId ? "selected" : ""}>${escapeHtml(item.name)}</option>`).join("")}</select></label>
      <button class="btn btn-ghost" type="button" data-action="reset-kpi">Reset filters</button>
    </section>
    <section class="summary-grid setup-kpis">${rows.map((item) => summaryCard(item)).join("")}</section>
    ${collectionPerformanceChart(setupSummary.monthlyPerformance)}
  `;
}

function bindKpiPage() {
  document.querySelectorAll("[data-kpi-filter]").forEach((control) => {
    control.addEventListener("change", () => {
      const filters = {};
      document.querySelectorAll("[data-kpi-filter]").forEach((item) => {
        filters[item.dataset.kpiFilter] = item.value;
      });
      setQuery("/kpi", filters);
    });
  });
  document.querySelector("[data-action='reset-kpi']")?.addEventListener("click", () => navigate("/kpi"));
  document.querySelector("[data-action='print-page']")?.addEventListener("click", () => window.print());
}

function renderBeneficiaries() {
  const filters = getQuery();
  const cooperatorFilterKeys = [
    "year",
    "municipality",
    "district",
    "businessType",
    "businessSector",
    "enterpriseClassification",
    "service",
    "setupStatus",
    "officer",
    "delinquency"
  ];
  const visibleFilters = Object.fromEntries(cooperatorFilterKeys.map((key) => [key, filters[key]]).filter(([, value]) => value));
  let records = beneficiaryService.list().map((item) => {
    const cooperator = getCooperatorView(item, item.financials);
    return {
      ...item,
      cooperatorView: cooperator,
      setupStatus: cooperator.setup.calculatedStatus,
      delayedState: item.financials.pastDue > 0 ? "Overdue" : item.financials.schedule.some((row) => row.status === "Within Grace Period") ? "Within Grace Period" : "Current"
    };
  });
  if (filters.year) records = records.filter((item) => String(item.cooperatorView.setup.yearAwarded) === String(filters.year) || item.cooperatorView.setup.phases.some((phase) => String(phase.yearAwarded) === String(filters.year)));
  if (filters.municipality) records = records.filter((item) => item.cooperatorView.municipality === filters.municipality);
  if (filters.district) records = records.filter((item) => item.cooperatorView.district === filters.district);
  if (filters.businessType) records = records.filter((item) => item.cooperatorView.businessType === filters.businessType);
  if (filters.businessSector) records = records.filter((item) => item.cooperatorView.businessSector === filters.businessSector);
  if (filters.enterpriseClassification) records = records.filter((item) => item.cooperatorView.enterpriseClassification === filters.enterpriseClassification);
  if (filters.service) records = records.filter((item) => item.cooperatorView.services.some((service) => service.category === filters.service));
  if (filters.setupStatus) records = records.filter((item) => item.setupStatus === filters.setupStatus || item.cooperatorView.setup.phases.some((phase) => phase.status === filters.setupStatus));
  if (filters.officer) records = records.filter((item) => item.cooperatorView.setup.assignedProjectOfficer === filters.officer || item.cooperatorView.setup.phases.some((phase) => phase.officer === filters.officer));
  if (filters.delinquency) records = records.filter((item) => item.delayedState === filters.delinquency);
  const officerOptions = [
    ...new Set(
      beneficiaryService
        .list()
        .flatMap((item) => {
          const cooperator = getCooperatorView(item);
          return [cooperator.setup.assignedProjectOfficer, ...cooperator.setup.phases.map((phase) => phase.officer)].filter(Boolean);
        })
    )
  ].sort();
  const rows = records.map((item) => ({
    ...item,
    searchText: [
      item.cooperatorView.firmName,
      item.cooperatorView.cooperatorName,
      item.cooperatorView.municipality,
      item.cooperatorView.district,
      item.cooperatorView.businessType,
      item.cooperatorView.businessSector,
      item.cooperatorView.setup.projectTitle,
      item.cooperatorView.setup.assignedProjectOfficer,
      ...item.cooperatorView.setup.phases.flatMap((phase) => [phase.phase, phase.status, phase.projectTitle, phase.officer]),
      item.setupStatus,
      item.delayedState
    ].join(" ")
  }));
  const columns = [
    { key: "firm", label: "Name of Firm", sortable: true, render: (row) => `<a href="/beneficiaries/${row.id}" data-link>${escapeHtml(row.cooperatorView.firmName)}</a>` },
    { key: "cooperator", label: "Name of Cooperator", sortable: true, render: (row) => escapeHtml(row.cooperatorView.cooperatorName) },
    { key: "municipality", label: "Municipality", sortable: true, render: (row) => escapeHtml(row.cooperatorView.municipality || "Not provided") },
    { key: "district", label: "District", sortable: true, render: (row) => escapeHtml(row.cooperatorView.district || "Not classified") },
    { key: "businessType", label: "Type of Business", sortable: true, render: (row) => escapeHtml(row.cooperatorView.businessType || "Not provided") },
    { key: "businessSector", label: "Business Sector", sortable: true, render: (row) => escapeHtml(row.cooperatorView.businessSector || "Not classified") },
    { key: "enterprise", label: "Enterprise Classification", sortable: true, render: (row) => escapeHtml(row.cooperatorView.enterpriseClassification) },
    { key: "setupStatus", label: "SETUP Project Status", sortable: true, render: (row) => statusBadge(row.setupStatus) },
    { key: "setupPhases", label: "SETUP Phases", sortable: true, render: (row) => setupPhaseSummary(row.cooperatorView.setup.phases) },
    {
      key: "actions",
      label: "Actions",
      render: (row) => `<div class="row-actions"><a href="/beneficiaries/${row.id}" data-link>View</a><a href="/beneficiaries/${row.id}/edit" data-link>Edit</a><button type="button" data-action="archive-beneficiary" data-id="${row.id}">Archive</button><button type="button" data-action="delete-record" data-type="beneficiaries" data-id="${row.id}">Delete</button></div>`
    }
  ];
  return `
    ${pageHeader({
      title: "Cooperators",
      eyebrow: "SETUP",
      description: "Maintain firm, cooperator, business, services, SETUP project, and refund information.",
      actions: `${buttonLink("/beneficiaries/new", "Add Cooperator", "plus", "primary")}<button class="btn btn-secondary" type="button" data-action="export-beneficiaries">${icon("download")}<span>Export View</span></button><button class="btn btn-secondary" type="button" data-action="print-page">${icon("print")}<span>Print View</span></button>`
    })}
    <section class="list-toolbar">
      ${searchInput("Search firm, cooperator, municipality, district, business, project, or officer")}
      <details class="filter-details">
        <summary>${icon("filter")} Filters</summary>
        <div class="filter-grid">
          <label>Year Awarded <select data-list-filter="year"><option value="">All</option>${yearOptions(filters.year)}</select></label>
          <label>Municipality <select data-list-filter="municipality"><option value="">All</option>${lookups.municipalities.map((item) => `<option ${item === filters.municipality ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
          <label>District <select data-list-filter="district"><option value="">All</option>${lookups.districts.map((item) => `<option ${item === filters.district ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
          <label>Type of Business <select data-list-filter="businessType"><option value="">All</option>${lookups.businessTypes.map((item) => `<option ${item === filters.businessType ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
          <label>Business Sector <select data-list-filter="businessSector"><option value="">All</option>${lookups.businessSectors.map((item) => `<option ${item === filters.businessSector ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
          <label>Enterprise Classification <select data-list-filter="enterpriseClassification"><option value="">All</option>${["Micro Enterprise", "Small Enterprise", "Medium Enterprise", "Not yet classified"].map((item) => `<option ${item === filters.enterpriseClassification ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
          <label>Service Availed <select data-list-filter="service"><option value="">All</option>${lookups.serviceCategories.map((item) => `<option ${item === filters.service ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
          <label>SETUP Project Status <select data-list-filter="setupStatus"><option value="">All</option>${setupStatusOptions(filters.setupStatus)}</select></label>
          <label>Assigned Project Officer <select data-list-filter="officer"><option value="">All</option>${officerOptions.map((item) => `<option ${item === filters.officer ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
          <label>Delinquency State <select data-list-filter="delinquency"><option value="">All</option>${["Current", "Within Grace Period", "Overdue"].map((item) => `<option ${item === filters.delinquency ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
          <button class="btn btn-ghost" type="button" data-action="reset-beneficiary-filters">Reset filters</button>
        </div>
      </details>
      <details class="column-details">
        <summary>Columns</summary>
        <div class="column-toggles">${columns
          .filter((column) => column.key !== "firm" && column.key !== "actions")
          .map((column) => `<label><input type="checkbox" checked data-column-toggle="${column.key}" /> ${escapeHtml(column.label)}</label>`)
          .join("")}</div>
      </details>
      ${filterChips(visibleFilters)}
      <p class="result-count"><strong data-visible-count>${records.length}</strong> records shown</p>
    </section>
    ${dataTable({ columns, rows, emptyMessage: "No cooperators match the selected filters.", className: "beneficiary-table cooperator-table" })}
    <section class="mobile-record-list">
      ${
        rows.length
          ? rows
              .map((row) =>
                mobileRecordCard({
                  title: row.cooperatorView.firmName,
                  subtitle: `${row.cooperatorView.cooperatorName} / ${row.cooperatorView.municipality || "Not provided"}`,
                  status: row.setupStatus,
                  searchText: row.searchText,
                  meta: [
                    { label: "Location", value: escapeHtml(`${row.cooperatorView.municipality || "Not provided"} / ${row.cooperatorView.district || "Not classified"}`) },
                    { label: "Classification", value: escapeHtml(row.cooperatorView.enterpriseClassification) },
                    { label: "SETUP Phases", value: setupPhasePlainSummary(row.cooperatorView.setup.phases) },
                    { label: "Delinquency", value: escapeHtml(row.delayedState) }
                  ],
                  actions: `<a class="btn btn-secondary" href="/beneficiaries/${row.id}" data-link>View Account</a><button class="btn btn-ghost" type="button" data-action="archive-beneficiary" data-id="${row.id}">Archive</button><button class="btn btn-ghost" type="button" data-action="delete-record" data-type="beneficiaries" data-id="${row.id}">Delete</button>`
                })
              )
              .join("")
          : ""
      }
    </section>
  `;
}

function bindBeneficiaries() {
  bindSearch(document);
  bindTableSorts(document);
  document.querySelectorAll("[data-list-filter]").forEach((control) => {
    control.addEventListener("change", () => {
      const filters = {};
      document.querySelectorAll("[data-list-filter]").forEach((item) => {
        filters[item.dataset.listFilter] = item.value;
      });
      setQuery("/beneficiaries", filters);
    });
  });
  document.querySelector("[data-action='reset-beneficiary-filters']")?.addEventListener("click", () => navigate("/beneficiaries"));
  document.querySelector("[data-action='print-page']")?.addEventListener("click", () => window.print());
  document.querySelector("[data-action='export-beneficiaries']")?.addEventListener("click", () => {
    const rows = beneficiaryService.list().map((item) => [
      getCooperatorView(item).firmName,
      getCooperatorView(item).cooperatorName,
      getCooperatorView(item).municipality,
      getCooperatorView(item).district,
      getCooperatorView(item).businessType,
      getCooperatorView(item).businessSector,
      getCooperatorView(item).enterpriseClassification,
      getCooperatorView(item).setup.calculatedStatus,
      getCooperatorView(item).setup.phases.map((phase) => `${phase.phase}: ${phase.status || "Pending"}`).join("; "),
      item.financials.totalPaid
    ]);
    downloadCsv("cooperators-filtered-view.csv", [["Name of Firm", "Name of Cooperator", "Municipality", "District", "Type of Business", "Business Sector", "Enterprise Classification", "SETUP Project Status", "SETUP Phases", "Paid"], ...rows]);
  });
  document.querySelectorAll("[data-action='archive-beneficiary']").forEach((button) => {
    button.addEventListener("click", () => {
      if (window.confirm("Archive this cooperator record? It can be restored later.")) {
        beneficiaryService.archive(button.dataset.id);
        createToast("Cooperator archived.");
        renderApp();
      }
    });
  });
  bindDeleteActions();
  document.querySelectorAll("[data-column-toggle]").forEach((input) => {
    input.addEventListener("change", () => {
      document.querySelectorAll(`[data-col="${input.dataset.columnToggle}"]`).forEach((cell) => {
        cell.hidden = !input.checked;
      });
    });
  });
}

function beneficiaryFormValues(record) {
  const cooperator = record ? getCooperatorView(record) : null;
  if (!record || !cooperator) {
    return {
      services: [{ category: "", subtype: "", dateAvailed: "", remarks: "" }],
      setupProjects: [],
      isPwd: "",
      isIndigenousPeople: "",
      projectStatus: "Ongoing"
    };
  }
  const phaseLabels = setupPhaseOptions();
  const setupServices = cooperator.services.filter((service) => service.category === "SETUP");
  const setupProjects = setupServices.length
    ? setupServices.map((service, index) => {
        const phase = parseSetupPhaseRemarks(service.remarks);
        return {
          id: service.id || "",
          subtype: service.subtype || phaseLabels[index] || "Phase I",
          status: phase.status || (index === 0 ? cooperator.setup.manualStatus || cooperator.setup.calculatedStatus || "Ongoing" : "Pending"),
          projectTitle: phase.projectTitle || (index === 0 ? cooperator.setup.projectTitle : ""),
          yearAwarded: phase.yearAwarded || (index === 0 ? cooperator.setup.yearAwarded : ""),
          officer: phase.officer || (index === 0 ? cooperator.setup.assignedProjectOfficer : ""),
          fundAssistance: phase.fundAssistance || (index === 0 ? cooperator.setup.financial.fundAssistance : ""),
          releaseDate: phase.releaseDate || service.dateAvailed || (index === 0 ? record.financial.releaseDate : ""),
          notes: phase.notes || ""
        };
      })
    : [];
  const services = [
    ...cooperator.services.filter((service) => service.category !== "SETUP"),
    ...(setupServices.length ? [{ category: "SETUP", subtype: "", dateAvailed: "", remarks: "" }] : [])
  ];
  return {
    firmName: cooperator.firmName,
    cooperatorName: cooperator.cooperatorName,
    sex: cooperator.sex,
    birthDate: cooperator.birthDate,
    isPwd: cooperator.pwd,
    isIndigenousPeople: cooperator.indigenousPeople,
    completeAddress: cooperator.completeAddress,
    municipality: cooperator.municipality,
    district: cooperator.district,
    contactNumber: cooperator.contactNumber,
    email: cooperator.email,
    notes: record.notes,
    businessType: cooperator.businessType,
    businessSector: cooperator.businessSector,
    assetLand: cooperator.assets.land || "",
    assetBuilding: cooperator.assets.building || "",
    assetEquipment: cooperator.assets.equipment || "",
    assetRevolvingCapital: cooperator.assets.revolvingCapital || "",
    services,
    setupProjects,
    projectTitle: cooperator.setup.projectTitle,
    yearAwarded: cooperator.setup.yearAwarded,
    officer: cooperator.setup.assignedProjectOfficer,
    projectStatus: cooperator.setup.manualStatus || cooperator.setup.calculatedStatus || "Ongoing",
    fundAssistance: cooperator.setup.financial.fundAssistance || "",
    releaseDate: record.financial.releaseDate,
    refundStart: cooperator.setup.financial.refundStart,
    refundEnd: cooperator.setup.financial.refundEnd,
    numberOfMonths: cooperator.setup.financial.numberOfMonths,
    monthlyRefund: cooperator.setup.financial.monthlyRefund || "",
    technologyTransferFee: record.financial.technologyTransferFee,
    optionToBuyAmount: record.financial.optionToBuyAmount,
    otherFees: record.financial.otherFees,
    initialRemarks: record.financial.remarks,
    status: record.status,
    spin: cooperator.legacy.spin,
      sourceOfFund: cooperator.legacy.sourceOfFund
  };
}

function radioGroup({ legend, name, options, value = "", required = false }) {
  return `
    <fieldset class="segmented-field">
      <legend>${escapeHtml(legend)}${required ? '<b aria-label="required">*</b>' : ""}</legend>
      <div>
        ${options.map((option) => `<label><input type="radio" name="${escapeHtml(name)}" value="${escapeHtml(option)}" ${option === value ? "checked" : ""} ${required ? "required" : ""} /><span>${escapeHtml(option)}</span></label>`).join("")}
      </div>
      <em class="field-error" data-error-for="${escapeHtml(name)}"></em>
    </fieldset>
  `;
}

function serviceCard(service = {}, index = 0) {
  const isSetup = service.category === "SETUP";
  const subtypeOptions = isSetup ? [] : lookups.serviceSubtypes[service.category] || [];
  return `
    <article class="service-card" data-service-card data-service-id="${escapeHtml(service.id || "")}">
      <div class="service-card-head">
        <strong>Service ${index + 1}</strong>
        <button class="btn btn-ghost" type="button" data-action="remove-service">Remove Service</button>
      </div>
      <div class="form-grid">
        <label class="field"><span>Service category</span><select data-service-category><option value="">Select</option>${lookups.serviceCategories.map((item) => `<option value="${escapeHtml(item)}" ${item === service.category ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
        <div class="${isSetup ? "calculation-callout" : "is-hidden"}" data-setup-service-note>SETUP project details are encoded below in Additional SETUP Information.</div>
        <div class="${isSetup ? "is-hidden" : "form-grid span-2"}" data-service-detail-fields>
          <label class="field ${subtypeOptions.length ? "" : "is-hidden"}" data-subtype-field><span>Subtype</span><select data-service-subtype><option value="">Select subtype</option>${subtypeOptions.map((item) => `<option value="${escapeHtml(item)}" ${item === service.subtype ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
          <label class="field"><span>Date Availed</span><input type="date" data-service-date value="${escapeHtml(service.dateAvailed || "")}" /></label>
          <label class="field span-2" data-service-remarks-field><span>Remarks</span><textarea data-service-remarks>${escapeHtml(service.remarks || "")}</textarea></label>
        </div>
      </div>
    </article>
  `;
}

function servicesMarkup(services = []) {
  return services.map((service, index) => serviceCard(service, index)).join("");
}

function setupProjectCard(project = {}, index = 0) {
  const phase = setupPhaseOptions()[index] || `Phase ${index + 1}`;
  return `
    <article class="service-card setup-project-card" data-setup-project-card data-service-id="${escapeHtml(project.id || "")}">
      <div class="service-card-head">
        <strong data-setup-phase-label>${escapeHtml(phase)}</strong>
        <button class="btn btn-ghost" type="button" data-action="remove-setup-project">Remove Project</button>
      </div>
      <div class="setup-phase-fields">
        <label class="field"><span>Project Status</span><select data-setup-phase-status><option value="">Select status</option>${setupStatusOptions(project.status || (index === 0 ? "Ongoing" : "Pending"))}</select></label>
        <label class="field"><span>Project / Setup Details</span><input data-setup-phase-title value="${escapeHtml(project.projectTitle || "")}" placeholder="Specific phase project title" /></label>
        <label class="field"><span>Year Awarded</span><input type="number" min="1900" data-setup-phase-year value="${escapeHtml(project.yearAwarded || new Date().getFullYear())}" /></label>
        <label class="field"><span>Assigned Officer</span><input data-setup-phase-officer value="${escapeHtml(project.officer || "")}" /></label>
        <label class="field"><span>Release Date</span><input type="date" data-setup-phase-release value="${escapeHtml(project.releaseDate || "")}" /></label>
        <label class="field"><span>SETUP Fund / Amount</span><input type="number" min="0" step="0.01" data-setup-phase-fund value="${escapeHtml(project.fundAssistance || "")}" /></label>
        <label class="field span-2"><span>Project Remarks</span><textarea data-setup-phase-notes>${escapeHtml(project.notes || "")}</textarea></label>
      </div>
    </article>
  `;
}

function setupProjectsMarkup(projects = []) {
  const records = projects.length ? projects : [{ status: "Ongoing" }];
  return records.map((project, index) => setupProjectCard(project, index)).join("");
}

function readBeneficiaryForm(form) {
  const data = readForm(form);
  const nonSetupServices = [...form.querySelectorAll("[data-service-card]")].map((card) => {
    const category = card.querySelector("[data-service-category]")?.value || "";
    return {
      id: card.dataset.serviceId || "",
      category,
      subtype: card.querySelector("[data-service-subtype]")?.value || "",
      dateAvailed: card.querySelector("[data-service-date]")?.value || "",
      remarks: card.querySelector("[data-service-remarks]")?.value.trim() || ""
    };
  }).filter((service) => service.category && service.category !== "SETUP");
  const hasSetup = Boolean(form.querySelector("[data-setup-project-card]"));
  const setupProjects = hasSetup
    ? [...form.querySelectorAll("[data-setup-project-card]")].map((card, index) => {
        const releaseDate = card.querySelector("[data-setup-phase-release]")?.value || "";
        const phase = setupPhaseOptions()[index] || `Phase ${index + 1}`;
        const project = {
          status: card.querySelector("[data-setup-phase-status]")?.value || "",
          projectTitle: card.querySelector("[data-setup-phase-title]")?.value.trim() || "",
          yearAwarded: card.querySelector("[data-setup-phase-year]")?.value || "",
          officer: card.querySelector("[data-setup-phase-officer]")?.value.trim() || "",
          fundAssistance: card.querySelector("[data-setup-phase-fund]")?.value || "",
          releaseDate,
          notes: card.querySelector("[data-setup-phase-notes]")?.value.trim() || ""
        };
        return {
          id: card.dataset.serviceId || "",
          category: "SETUP",
          subtype: phase,
          dateAvailed: releaseDate,
          remarks: formatSetupPhaseRemarks(project)
        };
      })
    : [];
  if (hasSetup && !setupProjects.length) {
    setupProjects.push({
      category: "SETUP",
      subtype: "Phase I",
      dateAvailed: data.releaseDate || "",
      remarks: formatSetupPhaseRemarks({
        status: data.projectStatus || "Ongoing",
        projectTitle: data.projectTitle || "",
        yearAwarded: data.yearAwarded || "",
        officer: data.officer || "",
        fundAssistance: data.fundAssistance || "",
        releaseDate: data.releaseDate || "",
        notes: ""
      })
    });
  }
  data.services = [...nonSetupServices, ...setupProjects];
  const firstProject = setupProjects[0] ? parseSetupPhaseRemarks(setupProjects[0].remarks) : null;
  if (firstProject) {
    data.projectTitle = data.projectTitle || firstProject.projectTitle || "";
    data.yearAwarded = data.yearAwarded || firstProject.yearAwarded || "";
    data.officer = data.officer || firstProject.officer || "";
    data.projectStatus = data.projectStatus || firstProject.status || "";
    data.fundAssistance = data.fundAssistance || firstProject.fundAssistance || "";
    data.releaseDate = data.releaseDate || firstProject.releaseDate || setupProjects[0].dateAvailed || "";
  }
  data.numberOfMonths = form.querySelector("[name='numberOfMonths']")?.value || "";
  return data;
}

function setupSection(values, hasSetup) {
  const scheduledTotal = toNumber(values.monthlyRefund) * Number(values.numberOfMonths || 0);
  const difference = toNumber(values.fundAssistance) - scheduledTotal;
  return `
    <section class="form-section setup-section" data-setup-section>
      <div class="form-section-heading">
        <h2>Additional SETUP Information</h2>
        <p>Add SETUP project phases here. Phase labels are assigned automatically by the system.</p>
      </div>
      <div class="form-grid">
        ${field({ label: "Project Title", name: "projectTitle", value: values.projectTitle, required: hasSetup })}
        ${field({ label: "Year of Award", name: "yearAwarded", value: values.yearAwarded || new Date().getFullYear(), type: "number", min: "1900", required: hasSetup })}
        ${field({ label: "Assigned Project Officer", name: "officer", value: values.officer, required: hasSetup })}
        <label class="field"><span>Project Status${hasSetup ? '<b aria-label="required">*</b>' : ""}</span><select name="projectStatus" ${hasSetup ? "required" : ""}><option value="">Select</option>${setupStatusOptions(values.projectStatus || "Ongoing")}</select><em class="field-error" data-error-for="projectStatus"></em></label>
        <div class="calculation-callout span-2" data-status-source>Current status source: ${escapeHtml(values.projectStatus === "Terminated" ? "Manually assigned" : "Automatically calculated")}</div>
        <section class="subform span-2 setup-project-editor">
          <div class="panel-head">
            <div>
              <h3>SETUP Projects / Phases</h3>
              <p>Project phases are labeled automatically by the system.</p>
            </div>
            <button class="btn btn-secondary" type="button" data-action="add-setup-project">${icon("plus")} Add Project</button>
          </div>
          <div class="service-editor" data-setup-projects-list>${setupProjectsMarkup(values.setupProjects || [])}</div>
        </section>
        <section class="subform span-2">
          <div class="panel-head"><div><h3>Phase I Refund / RTS Portion</h3><p>Refund schedule, collection, and RTS fields apply to Phase I only. Additional SETUP phases are saved separately and do not inherit these values.</p></div></div>
          <div class="form-grid">
            ${field({ label: "SETUP Fund Assistance", name: "fundAssistance", value: values.fundAssistance, type: "number", min: "0", step: "0.01", required: hasSetup })}
            ${field({ label: "Monthly Refund Based on MOA", name: "monthlyRefund", value: values.monthlyRefund, type: "number", min: "0", step: "0.01", required: hasSetup })}
            ${field({ label: "Monthly Refund Start", name: "refundStart", value: values.refundStart, type: "date", required: hasSetup })}
            ${field({ label: "Monthly Refund End", name: "refundEnd", value: values.refundEnd, type: "date", required: hasSetup })}
            <label class="field"><span>Number of Months of Refund</span><input name="numberOfMonths" readonly value="${escapeHtml(values.numberOfMonths || "")}" /><small>Calculated from start and end dates.</small><em class="field-error" data-error-for="numberOfMonths"></em></label>
            <div class="financial-preview" data-financial-preview>
              <strong>Financial preview</strong>
              <span>SETUP Fund Assistance: ${formatCurrency(values.fundAssistance)}</span>
              <span>Expected Monthly Refund: ${formatCurrency(values.monthlyRefund)}</span>
              <span>Number of Refund Months: ${escapeHtml(values.numberOfMonths || "0")}</span>
              <span>Estimated Total Scheduled Refund: ${formatCurrency(scheduledTotal)}</span>
              <span>Difference / final installment remainder: ${formatCurrency(difference)}</span>
            </div>
          </div>
        </section>
      </div>
    </section>
  `;
}

function renderBeneficiaryForm(id = "") {
  const existing = id ? beneficiaryService.get(id) : null;
  if (id && !existing) return errorState("Cooperator record was not found.");
  const values = beneficiaryFormValues(existing);
  const hasSetup = !id || values.services.some((service) => service.category === "SETUP") || Boolean(values.setupProjects?.length);
  const assetTotal = getEnterpriseClassification({
    land: values.assetLand,
    building: values.assetBuilding,
    equipment: values.assetEquipment,
    revolvingCapital: values.assetRevolvingCapital
  });
  return `
    ${pageHeader({
      title: id ? "Edit Cooperator" : "Add Cooperator",
      eyebrow: "SETUP / Cooperators",
      description: "Encode firm, cooperator, services availed, and SETUP refund information. Legacy project-number and fund-source fields are preserved in existing records but are not required here.",
      actions: id ? buttonLink(`/beneficiaries/${id}`, "View Profile", "users", "secondary") : buttonLink("/beneficiaries", "Back to List", "chevron", "secondary")
    })}
    <form class="record-form" data-beneficiary-form novalidate>
      <div class="error-summary" data-error-summary hidden></div>
      ${formSection(
        "A. Firm and Cooperator Information",
        "Demographic classifications update from the birthday and selected Yes/No controls.",
        field({ label: "Name of Firm", name: "firmName", value: values.firmName, required: true }) +
          field({ label: "Name of Cooperator", name: "cooperatorName", value: values.cooperatorName, required: true }) +
          radioGroup({ legend: "Sex", name: "sex", options: ["Female", "Male"], value: values.sex, required: true }) +
          field({ label: "Birthday", name: "birthDate", value: values.birthDate, type: "date", max: todayIso(), required: true, help: "Used to calculate age and senior citizen classification." }) +
          `<label class="field"><span>Age</span><input readonly data-age-output value="${escapeHtml(calculateAge(values.birthDate) || "Not yet calculated")}" /></label>` +
          `<label class="field"><span>Senior Citizen Classification</span><input readonly data-senior-output value="${escapeHtml(getSeniorCitizenClassification(values.birthDate))}" /></label>` +
          radioGroup({ legend: "PWD", name: "isPwd", options: lookups.yesNoOptions, value: values.isPwd, required: true }) +
          radioGroup({ legend: "Indigenous People", name: "isIndigenousPeople", options: lookups.yesNoOptions, value: values.isIndigenousPeople, required: true }) +
          field({ label: "Contact Number", name: "contactNumber", value: values.contactNumber, type: "tel", required: true, placeholder: "09XXXXXXXXX or +63XXXXXXXXXX", help: "Numbers, spaces, +, and dashes are accepted." }) +
          field({ label: "Email Address", name: "email", value: values.email, type: "email", required: true, placeholder: "name@example.com" }) +
          textArea({ label: "Notes or remarks", name: "notes", value: values.notes, className: "span-2" })
      )}
      ${formSection(
        "B. Address Information",
        "District is derived from the validated Ilocos Sur municipality list.",
        textArea({ label: "Complete Address", name: "completeAddress", value: values.completeAddress, required: true, className: "span-2" }) +
          selectField({ label: "Municipality", name: "municipality", options: lookups.municipalities, value: values.municipality, required: true, className: "address-field" }) +
          `<label class="field address-field"><span>District</span><input name="district" readonly value="${escapeHtml(values.district || getMunicipalityDistrict(values.municipality) || "Not classified")}" /><em class="field-error" data-error-for="district"></em></label>`
      )}
      ${formSection(
        "C. Business Information",
        "Business profile fields support filtering, charts, and reports. Enterprise classification is computed from declared assets in Section D.",
        selectField({ label: "Type of Business", name: "businessType", options: lookups.businessTypes, value: values.businessType, required: true }) +
          selectField({ label: "Business Sector", name: "businessSector", options: lookups.businessSectors, value: values.businessSector, required: true }) +
          `<label class="field span-2"><span>Enterprise Classification</span><input readonly data-enterprise-classification-input value="${escapeHtml(assetTotal)}" /><small>Automatically calculated from declared assets: Micro, Small, Medium, or Not yet classified.</small></label>`
      )}
      <section class="form-section">
        <div class="form-section-heading"><h2>D. Declared Assets</h2><p>All asset amounts must be entered in Philippine pesos (PHP). Enterprise classification is calculated from these declared asset amounts.</p></div>
        <div class="form-grid">
          <div class="peso-note span-2"><strong>Currency:</strong> Philippine Peso (PHP / ₱). Enter numeric peso amounts only.</div>
          ${field({ label: "Land Value (PHP / ₱)", name: "assetLand", value: values.assetLand, type: "number", min: "0", step: "0.01", placeholder: "₱ 0.00", help: "Peso value." })}
          ${field({ label: "Building Value (PHP / ₱)", name: "assetBuilding", value: values.assetBuilding, type: "number", min: "0", step: "0.01", placeholder: "₱ 0.00", help: "Peso value." })}
          ${field({ label: "Equipment Value (PHP / ₱)", name: "assetEquipment", value: values.assetEquipment, type: "number", min: "0", step: "0.01", placeholder: "₱ 0.00", help: "Peso value." })}
          ${field({ label: "Revolving Capital (PHP / ₱)", name: "assetRevolvingCapital", value: values.assetRevolvingCapital, type: "number", min: "0", step: "0.01", placeholder: "₱ 0.00", help: "Peso value." })}
          <div class="calculation-callout span-2" aria-live="polite">
            <strong>Total Declared Assets: <span data-asset-total>${formatCurrency(0)}</span></strong>
            <span>Enterprise Classification: <b data-enterprise-classification>${escapeHtml(assetTotal)}</b></span>
          </div>
        </div>
      </section>
      <section class="form-section">
        <div class="form-section-heading"><h2>Services Availed</h2><p>Add SETUP, trainings/seminars, TACS, or laboratory test services. Subtypes appear only when required.</p></div>
        <div class="service-editor">
          <em class="field-error" data-error-for="services"></em>
          <div data-services-list>${servicesMarkup(values.services)}</div>
          <button class="btn btn-secondary" type="button" data-action="add-service">${icon("plus")} Add Service</button>
        </div>
      </section>
      ${setupSection(values, hasSetup)}
      ${existing?.project?.spin || existing?.project?.sourceOfFund ? `<details class="legacy-info"><summary>Legacy Information</summary><dl><div><dt>Legacy Project Number</dt><dd>${escapeHtml(existing.project.spin || "Not provided")}</dd></div><div><dt>Legacy Fund Source</dt><dd>${escapeHtml(existing.project.sourceOfFund || "Not provided")}</dd></div></dl></details>` : ""}
      <div class="sticky-actions">
        <a class="btn btn-ghost" href="${id ? `/beneficiaries/${id}` : "/beneficiaries"}" data-link>Cancel</a>
        <button class="btn btn-secondary" type="submit" name="intent" value="list">Save</button>
        <button class="btn btn-primary" type="submit" name="intent" value="view">Save and View</button>
      </div>
    </form>
  `;
}

function bindBeneficiaryForm(id = "") {
  const form = document.querySelector("[data-beneficiary-form]");
  if (!form) return;
  bindDirtyForm(form);
  const serviceList = form.querySelector("[data-services-list]");
  const setupProjectList = form.querySelector("[data-setup-projects-list]");
  const updateAge = () => {
    form.querySelector("[data-age-output]").value = calculateAge(form.elements.birthDate.value) || "Not yet calculated";
    form.querySelector("[data-senior-output]").value = getSeniorCitizenClassification(form.elements.birthDate.value);
  };
  const updateDistrict = () => {
    form.elements.district.value = getMunicipalityDistrict(form.elements.municipality.value) || "Not classified";
  };
  const updateAssets = () => {
    const assets = {
      land: form.elements.assetLand.value,
      building: form.elements.assetBuilding.value,
      equipment: form.elements.assetEquipment.value,
      revolvingCapital: form.elements.assetRevolvingCapital.value
    };
    const total = Object.values(assets).reduce((sum, value) => sum + toNumber(value), 0);
    const classification = getEnterpriseClassification(assets);
    form.querySelector("[data-asset-total]").textContent = formatCurrency(total);
    form.querySelector("[data-enterprise-classification]").textContent = classification;
    if (form.querySelector("[data-enterprise-classification-input]")) form.querySelector("[data-enterprise-classification-input]").value = classification;
  };
  const updateSubtypeField = (card) => {
    const category = card.querySelector("[data-service-category]").value;
    const fieldNode = card.querySelector("[data-subtype-field]");
    const select = card.querySelector("[data-service-subtype]");
    const detailFields = card.querySelector("[data-service-detail-fields]");
    const setupNote = card.querySelector("[data-setup-service-note]");
    const remarksField = card.querySelector("[data-service-remarks-field]");
    const label = fieldNode?.querySelector("span");
    const isSetup = category === "SETUP";
    const currentValue = select?.value || "";
    const options = isSetup ? [] : lookups.serviceSubtypes[category] || [];
    fieldNode?.classList.toggle("is-hidden", !options.length);
    if (label) label.textContent = "Subtype";
    if (select) select.innerHTML = `<option value="">Select subtype</option>${options.map((item) => `<option value="${escapeHtml(item)}" ${item === currentValue ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}`;
    detailFields?.classList.toggle("is-hidden", isSetup);
    setupNote?.classList.toggle("is-hidden", !isSetup);
    remarksField?.classList.toggle("is-hidden", isSetup);
  };
  const updateSetupSection = () => {
    const hasSetup = Boolean(form.querySelector("[data-setup-project-card]"));
    const setup = form.querySelector("[data-setup-section]");
    setup?.classList.remove("is-hidden");
    if (hasSetup && setupProjectList && !setupProjectList.querySelector("[data-setup-project-card]")) {
      setupProjectList.insertAdjacentHTML("beforeend", setupProjectCard({ status: form.elements.projectStatus?.value || "Ongoing" }, 0));
      bindSetupProjectCard(setupProjectList.querySelector("[data-setup-project-card]:last-child"));
      renumberSetupProjects();
    }
    setup?.querySelectorAll("input, select, textarea").forEach((control) => {
      if (["projectTitle", "yearAwarded", "officer", "projectStatus", "fundAssistance", "monthlyRefund", "refundStart", "refundEnd"].includes(control.name)) {
        control.required = hasSetup;
      }
    });
  };
  const updateFinancialPreview = () => {
    const start = form.elements.refundStart?.value || "";
    const end = form.elements.refundEnd?.value || "";
    const months = getRefundMonthCount(start, end);
    if (form.elements.numberOfMonths) form.elements.numberOfMonths.value = months || "";
    const fund = toNumber(form.elements.fundAssistance?.value);
    const monthly = toNumber(form.elements.monthlyRefund?.value);
    const total = monthly * months;
    const difference = fund - total;
    const preview = form.querySelector("[data-financial-preview]");
    if (preview) {
      preview.innerHTML = `<strong>Financial preview</strong><span>SETUP Fund Assistance: ${formatCurrency(fund)}</span><span>Expected Monthly Refund: ${formatCurrency(monthly)}</span><span>Number of Refund Months: ${months || 0}</span><span>Estimated Total Scheduled Refund: ${formatCurrency(total)}</span><span>Difference / final installment remainder: ${formatCurrency(difference)}</span>${Math.abs(difference) > Math.max(1, monthly) ? `<em class="warning-text">The scheduled total differs from the fund assistance. The final installment may need adjustment.</em>` : ""}`;
    }
  };
  const bindServiceCard = (card) => {
    card.querySelector("[data-service-category]")?.addEventListener("change", () => {
      updateSubtypeField(card);
      updateSetupSection();
    });
    card.querySelector("[data-action='remove-service']")?.addEventListener("click", () => {
      const hasInfo = ["[data-service-category]", "[data-service-subtype]", "[data-service-date]", "[data-service-remarks]", "[data-setup-phase-status]", "[data-setup-phase-title]", "[data-setup-phase-notes]"].some((selector) => card.querySelector(selector)?.value);
      if (hasInfo && !window.confirm("Remove this service entry and its information?")) return;
      card.remove();
      if (!serviceList.querySelector("[data-service-card]")) {
        serviceList.insertAdjacentHTML("beforeend", serviceCard({}, 0));
        bindServiceCard(serviceList.querySelector("[data-service-card]:last-child"));
      }
      updateSetupSection();
    });
  };
  const renumberSetupProjects = () => {
    const phaseLabels = setupPhaseOptions();
    const cards = [...form.querySelectorAll("[data-setup-project-card]")];
    cards.forEach((card, index) => {
      const label = phaseLabels[index] || `Phase ${index + 1}`;
      card.querySelector("[data-setup-phase-label]")?.replaceChildren(document.createTextNode(label));
      const removeButton = card.querySelector("[data-action='remove-setup-project']");
      if (removeButton) removeButton.disabled = cards.length <= 1;
    });
    const addButton = form.querySelector("[data-action='add-setup-project']");
    if (addButton) addButton.disabled = cards.length >= phaseLabels.length;
  };
  const bindSetupProjectCard = (card) => {
    card.querySelector("[data-action='remove-setup-project']")?.addEventListener("click", () => {
      const cards = form.querySelectorAll("[data-setup-project-card]");
      if (cards.length <= 1) return;
      const hasInfo = ["[data-setup-phase-status]", "[data-setup-phase-title]", "[data-setup-phase-year]", "[data-setup-phase-officer]", "[data-setup-phase-release]", "[data-setup-phase-fund]", "[data-setup-phase-notes]"].some((selector) => card.querySelector(selector)?.value);
      if (hasInfo && !window.confirm("Remove this SETUP project phase?")) return;
      card.remove();
      renumberSetupProjects();
    });
  };
  serviceList.querySelectorAll("[data-service-card]").forEach(bindServiceCard);
  setupProjectList?.querySelectorAll("[data-setup-project-card]").forEach(bindSetupProjectCard);
  renumberSetupProjects();
  form.querySelector("[data-action='add-setup-project']")?.addEventListener("click", () => {
    const count = setupProjectList?.querySelectorAll("[data-setup-project-card]").length || 0;
    const phaseLabels = setupPhaseOptions();
    if (!setupProjectList || count >= phaseLabels.length) return;
    setupProjectList.insertAdjacentHTML("beforeend", setupProjectCard({ status: count === 0 ? "Ongoing" : "Pending" }, count));
    bindSetupProjectCard(setupProjectList.querySelector("[data-setup-project-card]:last-child"));
    renumberSetupProjects();
  });
  form.querySelector("[data-action='add-service']")?.addEventListener("click", () => {
    serviceList.insertAdjacentHTML("beforeend", serviceCard({}, serviceList.querySelectorAll("[data-service-card]").length));
    bindServiceCard(serviceList.querySelector("[data-service-card]:last-child"));
    updateSetupSection();
  });
  form.elements.birthDate?.addEventListener("change", updateAge);
  form.elements.municipality?.addEventListener("change", updateDistrict);
  ["assetLand", "assetBuilding", "assetEquipment", "assetRevolvingCapital"].forEach((name) => form.elements[name]?.addEventListener("input", updateAssets));
  ["fundAssistance", "monthlyRefund", "refundStart", "refundEnd"].forEach((name) => form.elements[name]?.addEventListener("input", updateFinancialPreview));
  form.elements.projectStatus?.addEventListener("change", () => {
    if (form.elements.projectStatus.value === "Terminated") {
      const confirmed = window.confirm("This project will be excluded from Active SETUP Refund and SETUP Refund Performance calculations. Existing payment history and unpaid balance will remain visible.");
      if (!confirmed) form.elements.projectStatus.value = "Ongoing";
    }
    form.querySelector("[data-status-source]").textContent = `Current status source: ${form.elements.projectStatus.value === "Terminated" ? "Manually assigned" : "Automatically calculated"}`;
  });
  updateAge();
  updateDistrict();
  updateAssets();
  updateSetupSection();
  updateFinancialPreview();
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const data = readBeneficiaryForm(form);
    const errors = beneficiaryService.validate(data, id);
    setFieldErrors(form, errors);
    if (Object.keys(errors).length) {
      focusFirstError(form);
      return;
    }
    const submitter = event.submitter;
    if (submitter) submitter.disabled = true;
    try {
      const record = await beneficiaryService.saveFromForm(data, id);
      window.__dirtyForm = false;
      createToast(`${record.firmName || "Cooperator"} ${id ? "changes saved" : "added successfully"}.`);
      navigate(submitter?.value === "view" ? `/beneficiaries/${record.id}` : "/beneficiaries");
    } catch (error) {
      if (submitter) submitter.disabled = false;
      createToast(`Cooperator was not saved: ${error.message || "Database write failed."}`, "danger");
    }
  });
}

function renderBeneficiaryDetail(id) {
  const beneficiary = beneficiaryService.getWithFinancials(id);
  if (!beneficiary) return errorState("Cooperator record was not found.");
  const cooperator = getCooperatorView(beneficiary, beneficiary.financials);
  const schedule = beneficiary.financials.schedule;
  const payments = collectionService.list().filter((item) => item.beneficiaryId === id);
  const receipts = receiptService.list().filter((item) => item.beneficiaryId === id);
  const deferments = defermentService.list().filter((item) => item.beneficiaryId === id);
  const adjustments = adjustmentService.list().filter((item) => item.beneficiaryId === id);
  const documents = documentService.list().filter((item) => item.beneficiaryId === id);
  const displayServices = [
    ...cooperator.services.filter((service) => service.category !== "SETUP"),
    ...(cooperator.hasSetup ? [{ category: "SETUP", subtype: "", dateAvailed: "", remarks: "SETUP project phases are shown in the SETUP Phases tab." }] : [])
  ];
  const tabs = [
    "Overview",
    "Services Availed",
    ...(cooperator.hasSetup ? ["SETUP Phases", "Refund Schedule"] : []),
    "Collections",
    "Official Receipts",
    "Deferments",
    "Adjustments",
    "Documents",
    "History"
  ];
  return `
    <section class="profile-header">
      <div>
        <p class="breadcrumb">SETUP / Cooperator Profile</p>
        <h1>${escapeHtml(cooperator.firmName)}</h1>
        <p>${escapeHtml(cooperator.cooperatorName)} / ${escapeHtml(cooperator.municipality || "Not provided")} / ${escapeHtml(cooperator.district || "Not classified")}</p>
        ${cooperator.hasSetup ? statusBadge(cooperator.setup.calculatedStatus) : statusBadge("Under Review")}
      </div>
      <div class="page-actions">
        ${buttonLink(`/beneficiaries/${id}/edit`, "Edit", "edit", "secondary")}
        ${buttonLink(`/collections/new?beneficiary=${id}`, "Record Payment", "cash", "primary")}
        <button class="btn btn-secondary" type="button" data-action="print-page">${icon("print")}<span>Print Cooperator Account Statement</span></button>
      </div>
    </section>
    <nav class="tabs" aria-label="Cooperator sections">${tabs.map((tab, index) => `<button type="button" class="${index === 0 ? "active" : ""}" data-tab="${slug(tab)}">${escapeHtml(tab)}</button>`).join("")}</nav>
    <section class="tab-panel active" data-panel="overview">
      <div class="detail-grid">
        ${detailPanel("Firm Information", [
          ["Name of Firm", cooperator.firmName],
          ["Complete Address", cooperator.completeAddress || "Not provided"],
          ["Municipality", cooperator.municipality || "Not provided"],
          ["District", cooperator.district || "Not classified"],
          ["Type of Business", cooperator.businessType || "Not provided"],
          ["Business Sector", cooperator.businessSector || "Not classified"]
        ])}
        ${detailPanel("Cooperator Information", [
          ["Name of Cooperator", cooperator.cooperatorName],
          ["Sex", cooperator.sex || "Not provided"],
          ["Birthday", formatDate(cooperator.birthDate)],
          ["Age", cooperator.age === "" ? "Not yet calculated" : cooperator.age],
          ["Senior Citizen Classification", cooperator.seniorCitizenClassification],
          ["PWD", cooperator.pwd || "Not provided"],
          ["Indigenous People", cooperator.indigenousPeople || "Not provided"],
          ["Contact", cooperator.contactNumber || "Not provided"],
          ["Email", cooperator.email || "Not provided"]
        ])}
        ${detailPanel("Declared Assets", [
          ["Land", formatCurrency(cooperator.assets.land)],
          ["Building", formatCurrency(cooperator.assets.building)],
          ["Equipment", formatCurrency(cooperator.assets.equipment)],
          ["Revolving Capital", formatCurrency(cooperator.assets.revolvingCapital)],
          ["Total Declared Assets", formatCurrency(cooperator.assets.total)],
          ["Enterprise Classification", cooperator.enterpriseClassification]
        ])}
        ${detailPanel(
          "Calculated Values",
          [
            ["Total Repayable", formatCurrency(beneficiary.financials.totalRepayable)],
            ["Total Paid", formatCurrency(beneficiary.financials.totalPaid)],
            ["Outstanding Balance", formatCurrency(beneficiary.financials.outstandingBalance)],
            ["Amount Due", formatCurrency(beneficiary.financials.amountDue)],
            ["Past Due", formatCurrency(beneficiary.financials.pastDue)],
            ["Advance Payment", formatCurrency(beneficiary.financials.advancePayment)],
            ["Refund Percentage", `${beneficiary.financials.refundPercentage.toFixed(1)}%`],
            ["Adjusted Due Date", formatDate(beneficiary.financials.adjustedDueDate)],
            ["Latest Payment", beneficiary.financials.latestPayment ? formatDate(beneficiary.financials.latestPayment.paymentDate) : "None"],
            ["Latest Receipt", beneficiary.financials.latestReceipt ? beneficiary.financials.latestReceipt.orNumber : "None"]
          ],
          true
        )}
      </div>
      ${activityTimeline(id)}
    </section>
    <section class="tab-panel" data-panel="services-availed">
      <section class="service-timeline">
        ${displayServices.length
          ? displayServices.map((service) => `<article class="service-card"><strong>${escapeHtml(service.category)}</strong><span>${escapeHtml(service.subtype || "No subtype required")}</span><time>${formatDate(service.dateAvailed)}</time><p>${escapeHtml(service.remarks || (service.legacy ? "Legacy SETUP refund project record." : "No remarks."))}</p></article>`).join("")
          : emptyState("No services recorded", "No services availed have been added for this cooperator.")}
      </section>
    </section>
    ${cooperator.hasSetup ? `<section class="tab-panel" data-panel="setup-phases">
      <div class="detail-grid">
        ${detailPanel("Phase I SETUP Refund / RTS", [
          ["Project Title", cooperator.setup.projectTitle || "Not provided"],
          ["Year of Award", cooperator.setup.yearAwarded || "Not provided"],
          ["Assigned Project Officer", cooperator.setup.assignedProjectOfficer || "Not provided"],
          ["Project Status", cooperator.setup.calculatedStatus],
          ["Status Basis", cooperator.setup.statusSource],
          ["SETUP Fund Assistance", formatCurrency(cooperator.setup.financial.fundAssistance)],
          ["Monthly Refund", formatCurrency(cooperator.setup.financial.monthlyRefund)],
          ["Refund Start", formatDate(cooperator.setup.financial.refundStart)],
          ["Refund End", formatDate(cooperator.setup.financial.refundEnd)],
          ["Number of Months", cooperator.setup.financial.numberOfMonths],
          ["Total Collected", formatCurrency(beneficiary.financials.totalPaid)],
          ["SETUP Refund Performance", `${beneficiary.financials.collectionRate.toFixed(1)}%`],
          ["Additional Phases", "Separate records; Phase II and above do not inherit Phase I refund/RTS data."]
        ])}
      </div>
      ${renderSetupPhaseTable(cooperator.setup.phases)}
      ${(cooperator.legacy.spin || cooperator.legacy.sourceOfFund) ? `<details class="legacy-info"><summary>Legacy Information</summary><dl><div><dt>Legacy Project Number</dt><dd>${escapeHtml(cooperator.legacy.spin || "Not provided")}</dd></div><div><dt>Legacy Fund Source</dt><dd>${escapeHtml(cooperator.legacy.sourceOfFund || "Not provided")}</dd></div></dl></details>` : ""}
    </section>` : ""}
    ${cooperator.hasSetup ? `<section class="tab-panel" data-panel="refund-schedule"><div class="calculation-callout">Refund schedule and RTS/collection flow apply to Phase I only. Additional SETUP phases do not inherit this schedule.</div>${renderSchedule(schedule, id)}</section>` : ""}
    <section class="tab-panel" data-panel="collections">${renderSimplePaymentTable(payments)}</section>
    <section class="tab-panel" data-panel="official-receipts">${renderSimpleReceiptTable(receipts)}</section>
    <section class="tab-panel" data-panel="deferments">${renderSimpleDefermentTable(deferments)}</section>
    <section class="tab-panel" data-panel="adjustments">${renderSimpleAdjustmentTable(adjustments)}</section>
    <section class="tab-panel" data-panel="documents">${renderSimpleDocumentTable(documents)}</section>
    <section class="tab-panel" data-panel="history">${activityTimeline(id, true)}</section>
  `;
}

function detailPanel(title, rows, calculated = false) {
  return `<section class="panel detail-panel ${calculated ? "read-only-panel" : ""}"><div class="panel-head"><h2>${escapeHtml(title)}</h2>${calculated ? `<span title="Calculated from current database records.">${icon("info")} Calculated values</span>` : ""}</div><dl>${rows
    .map(([label, value]) => `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`)
    .join("")}</dl></section>`;
}

function renderSetupPhaseTable(phases = []) {
  if (!phases.length) return emptyState("No SETUP phases", "No SETUP phase records are linked to this cooperator.");
  return `
    <section class="panel setup-phase-panel">
      <div class="panel-head">
        <h2>SETUP Phase Records</h2>
        <p>Each phase is stored as a separate SETUP service for this firm.</p>
      </div>
      <div class="setup-phase-table-wrap">
        <table class="setup-phase-table">
          <thead>
            <tr>
              <th>Phase</th>
              <th>Status</th>
              <th>Project / Details</th>
              <th>Year</th>
              <th>Officer</th>
              <th>Release Date</th>
              <th>Fund / Amount</th>
              <th>Refund / RTS</th>
              <th>Remarks</th>
            </tr>
          </thead>
          <tbody>
            ${phases
              .map(
                (phase) => `
                  <tr>
                    <td><strong>${escapeHtml(phase.phase || "SETUP")}</strong></td>
                    <td>${statusBadge(phase.status || "Pending")}</td>
                    <td>${escapeHtml(phase.projectTitle || "Not provided")}</td>
                    <td>${escapeHtml(phase.yearAwarded || "Not provided")}</td>
                    <td>${escapeHtml(phase.officer || "Not provided")}</td>
                    <td>${formatDate(phase.releaseDate)}</td>
                    <td>${formatCurrency(phase.fundAssistance)}</td>
                    <td>${escapeHtml(isRefundApplicableToPhase(phase.phase) ? "Applies to Phase I" : "Not copied / separate data")}</td>
                    <td>${escapeHtml(phase.notes || "No remarks.")}</td>
                  </tr>
                `
              )
              .join("")}
          </tbody>
        </table>
      </div>
    </section>
  `;
}

function activityTimeline(beneficiaryId, full = false) {
  const events = getActivityEvents(beneficiaryId).slice(0, full ? 100 : 5);
  return `<section class="panel timeline-panel"><div class="panel-head"><h2>Activity Timeline</h2><p>System actions and related record dates for this cooperator.</p></div>${
    events.length
      ? `<ol class="timeline">${events.map((event) => `<li><span></span><strong>${escapeHtml(event.action)}</strong><time>${formatDate(event.date)}</time></li>`).join("")}</ol>`
      : emptyState("No activity yet", "No saved activity, collection, receipt, deferment, adjustment, or document record exists for this cooperator.")
  }</section>`;
}

function eventDate(value) {
  return String(value || "").slice(0, 10);
}

function getActivityEvents(beneficiaryId) {
  const state = repository.getSnapshot();
  const beneficiary = repository.get("beneficiaries", beneficiaryId);
  const events = [];
  const addEvent = (action, date, tieBreaker = "") => {
    const normalizedDate = eventDate(date);
    if (!action || !normalizedDate) return;
    events.push({ action, date: normalizedDate, tieBreaker });
  };

  addEvent("Cooperator created", beneficiary?.createdAt, beneficiary?.id);
  if (beneficiary?.updatedAt && eventDate(beneficiary.updatedAt) !== eventDate(beneficiary.createdAt)) {
    addEvent("Cooperator updated", beneficiary.updatedAt, beneficiary.id);
  }

  state.activity
    .filter((item) => item.beneficiaryId === beneficiaryId)
    .forEach((item) => addEvent(item.action, item.timestamp, item.id));
  state.payments
    .filter((item) => item.beneficiaryId === beneficiaryId && !item.archived)
    .forEach((item) => addEvent(`Payment recorded${item.referenceNumber ? ` (${item.referenceNumber})` : ""}`, item.dateReceived || item.paymentDate, item.id));
  state.receipts
    .filter((item) => item.beneficiaryId === beneficiaryId && !item.archived)
    .forEach((item) => addEvent(`Official receipt added${item.orNumber ? ` (${item.orNumber})` : ""}`, item.orDate, item.id));
  state.deferments
    .filter((item) => item.beneficiaryId === beneficiaryId && !item.archived)
    .forEach((item) => addEvent(`Deferment ${item.status || "recorded"}`, item.approvalDate || item.requestDate || item.startDate, item.id));
  state.adjustments
    .filter((item) => item.beneficiaryId === beneficiaryId && !item.archived)
    .forEach((item) => addEvent(`Adjustment created${item.type ? ` (${item.type})` : ""}`, item.effectiveDate, item.id));
  state.documents
    .filter((item) => item.beneficiaryId === beneficiaryId && !item.archived)
    .forEach((item) => addEvent(`Document added${item.category ? ` (${item.category})` : ""}`, item.documentDate, item.id));

  const deduped = new Map();
  events.forEach((event) => {
    const key = `${event.action}|${event.date}|${event.tieBreaker}`;
    if (!deduped.has(key)) deduped.set(key, event);
  });
  return [...deduped.values()].sort((a, b) => b.date.localeCompare(a.date) || b.tieBreaker.localeCompare(a.tieBreaker));
}

function renderSchedule(schedule, beneficiaryId) {
  const paid = schedule.filter((item) => item.status === "Paid").length;
  const columns = [
    { key: "month", label: "Refund Month", sortable: true, render: (row) => escapeHtml(row.refundMonth) },
    { key: "expected", label: "Expected Amount", sortable: true, render: (row) => formatCurrency(row.expectedAmount) },
    { key: "paid", label: "Amount Paid", sortable: true, render: (row) => formatCurrency(row.amountPaid) },
    { key: "remaining", label: "Remaining Amount", sortable: true, render: (row) => formatCurrency(row.remainingAmount) },
    { key: "grace", label: "Grace Period Deadline", render: (row) => formatDate(row.gracePeriodDeadline) },
    { key: "paymentDate", label: "Payment Date", render: (row) => formatDate(row.paymentDate) },
    { key: "or", label: "Official Receipt", render: (row) => escapeHtml(row.orNumber || "Pending") },
    { key: "status", label: "Status", render: (row) => statusBadge(row.status) },
    { key: "actions", label: "Actions", render: () => `<a href="/collections/new?beneficiary=${beneficiaryId}" data-link>Record payment</a>` }
  ];
  return `
    <section class="panel progress-panel">
      <div class="panel-head"><h2>Refund Schedule</h2><p>${paid} of ${schedule.length} monthly obligations paid. Grace period runs through the 15th day of the following month.</p></div>
      <div class="progress-meter"><span style="width:${(paid / Math.max(schedule.length, 1)) * 100}%"></span></div>
      <div class="action-row"><button class="btn btn-secondary" type="button" data-action="print-page">${icon("print")} Print refund schedule</button><button class="btn btn-secondary" type="button" data-action="export-schedule">${icon("download")} Export schedule</button><a class="btn btn-primary" href="/collections/new?beneficiary=${beneficiaryId}" data-link>${icon("cash")} Record payment</a></div>
    </section>
    ${dataTable({ columns, rows: schedule.map((item) => ({ ...item, searchText: `${item.installmentNumber} ${item.status} ${item.orNumber}` })) })}
    <section class="mobile-record-list">${schedule
      .map((item) =>
        mobileRecordCard({
          title: item.refundMonth,
          subtitle: `Grace period until ${formatDate(item.gracePeriodDeadline)}`,
          status: item.status,
          meta: [
            { label: "Expected", value: formatCurrency(item.expectedAmount) },
            { label: "Paid", value: formatCurrency(item.amountPaid) },
            { label: "Remaining", value: formatCurrency(item.remainingAmount) },
            { label: "OR", value: escapeHtml(item.orNumber || "Pending") }
          ],
          actions: `<details><summary>Payment details</summary><p>${escapeHtml(item.remarks || "No extra remarks.")}</p></details>`
        })
      )
      .join("")}</section>
  `;
}

function renderSimplePaymentTable(payments) {
  return dataTable({
    rows: payments.map((payment) => ({ ...payment, searchText: `${payment.referenceNumber} ${payment.method} ${payment.status}` })),
    emptyMessage: "No payment records are associated with this cooperator.",
    columns: [
      { key: "date", label: "Payment Date", render: (row) => formatDate(row.paymentDate) },
      { key: "amount", label: "Amount", render: (row) => formatCurrency(row.amount) },
      { key: "method", label: "Method", render: (row) => escapeHtml(row.method) },
      { key: "reference", label: "Reference", render: (row) => `<code>${escapeHtml(row.referenceNumber)}</code>` },
      { key: "status", label: "Status", render: (row) => statusBadge(row.status) },
      { key: "actions", label: "Actions", render: (row) => `<a href="/collections/${row.id}" data-link>View</a><button type="button" data-action="delete-record" data-type="payments" data-id="${row.id}">Delete</button>` }
    ]
  });
}

function renderSimpleReceiptTable(receipts) {
  return dataTable({
    rows: receipts.map((receipt) => ({ ...receipt, searchText: `${receipt.orNumber} ${receipt.remarks}` })),
    emptyMessage: "No official receipt records are associated with this cooperator.",
    columns: [
      { key: "or", label: "OR Number", render: (row) => `<code>${escapeHtml(row.orNumber)}</code>` },
      { key: "date", label: "OR Date", render: (row) => formatDate(row.orDate) },
      { key: "amount", label: "OR Amount", render: (row) => formatCurrency(row.amount) },
      { key: "remarks", label: "Remarks", render: (row) => escapeHtml(row.remarks) },
      { key: "actions", label: "Actions", render: (row) => `<button type="button" data-action="delete-record" data-type="receipts" data-id="${row.id}">Delete</button>` }
    ]
  });
}

function renderSimpleDefermentTable(records) {
  return dataTable({
    rows: records.map((item) => ({ ...item, searchText: `${item.reason} ${item.status}` })),
    emptyMessage: "No deferments are associated with this cooperator.",
    columns: [
      { key: "request", label: "Request Date", render: (row) => formatDate(row.requestDate) },
      { key: "range", label: "Deferment Period", render: (row) => `${formatDate(row.startDate)} - ${formatDate(row.endDate)}` },
      { key: "months", label: "Deferred Months", render: (row) => row.months },
      { key: "status", label: "Status", render: (row) => statusBadge(row.status) },
      { key: "actions", label: "Actions", render: (row) => `<button type="button" data-action="delete-record" data-type="deferments" data-id="${row.id}">Delete</button>` }
    ]
  });
}

function renderSimpleAdjustmentTable(records) {
  return dataTable({
    rows: records.map((item) => ({ ...item, searchText: `${item.type} ${item.reason}` })),
    emptyMessage: "No adjustments are associated with this cooperator.",
    columns: [
      { key: "type", label: "Type", render: (row) => escapeHtml(row.type) },
      { key: "date", label: "Effective Date", render: (row) => formatDate(row.effectiveDate) },
      { key: "amount", label: "Amount", render: (row) => formatCurrency(row.amount) },
      { key: "reason", label: "Reason", render: (row) => escapeHtml(row.reason) },
      { key: "actions", label: "Actions", render: (row) => `<button type="button" data-action="delete-record" data-type="adjustments" data-id="${row.id}">Delete</button>` }
    ]
  });
}

function renderSimpleDocumentTable(records) {
  return dataTable({
    rows: records.map((item) => ({ ...item, searchText: `${item.category} ${item.fileName}` })),
    emptyMessage: "No documents are associated with this cooperator.",
    columns: [
      { key: "category", label: "Category", render: (row) => escapeHtml(row.category) },
      { key: "date", label: "Document Date", render: (row) => formatDate(row.documentDate) },
      { key: "file", label: "File", render: (row) => escapeHtml(row.fileName) },
      { key: "actions", label: "Actions", render: (row) => `<button type="button">Preview</button><button type="button">Download</button><button type="button" data-action="delete-record" data-type="documents" data-id="${row.id}">Delete</button>` }
    ]
  });
}

function bindBeneficiaryDetail(id) {
  document.querySelectorAll("[data-tab]").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll("[data-tab]").forEach((item) => item.classList.toggle("active", item === tab));
      document.querySelectorAll("[data-panel]").forEach((panel) => panel.classList.toggle("active", panel.dataset.panel === tab.dataset.tab));
    });
  });
  document.querySelectorAll("[data-action='print-page']").forEach((button) => button.addEventListener("click", () => window.print()));
  document.querySelector("[data-action='export-schedule']")?.addEventListener("click", () => {
    const rows = getSchedule(id).map((item) => [item.refundMonth, item.expectedAmount, item.amountPaid, item.remainingAmount, item.gracePeriodDeadline, item.paymentDate, item.orNumber, item.status]);
    downloadCsv("individual-refund-schedule.csv", [["Refund Month", "Expected", "Paid", "Remaining", "Grace Period Deadline", "Payment Date", "Official Receipt", "Status"], ...rows]);
  });
  bindTableSorts(document);
  bindDeleteActions();
}

function renderCollections() {
  const payments = collectionService.list();
  const receiptPaymentIds = new Set(repository.getSnapshot().receipts.filter((receipt) => !receipt.archived).map((receipt) => receipt.paymentId));
  const rows = payments.map((item) => ({ ...item, searchText: `${item.beneficiary?.firmName} ${item.projectTitle} ${item.referenceNumber} ${item.status}` }));
  const page = pagedRows(rows, "/collections");
  return `
    ${pageHeader({
      title: "Collections",
      eyebrow: "Internal / Payment Recording",
      description: "Record collections, checks, PDCs, PMOs, deposits, and other payments.",
      actions: buttonLink("/collections/new", "Record Payment", "cash", "primary")
    })}
    <section class="list-toolbar">${searchInput("Search visible payments")}<p class="result-count"><strong data-visible-count>${page.rows.length}</strong> shown, ${page.start}-${page.end} of ${page.totalRows} payments</p></section>
    ${dataTable({
      rows: page.rows,
      columns: [
        { key: "beneficiary", label: "Cooperator", sortable: true, render: (row) => escapeHtml(row.beneficiary ? getCooperatorView(row.beneficiary).firmName : "") },
        { key: "project", label: "Project", render: (row) => escapeHtml(row.projectTitle) },
        { key: "date", label: "Payment Date", sortable: true, render: (row) => formatDate(row.paymentDate) },
        { key: "amount", label: "Amount", sortable: true, render: (row) => formatCurrency(row.amount) },
        { key: "method", label: "Payment Method", render: (row) => escapeHtml(row.method) },
        { key: "reference", label: "Reference Number", render: (row) => `<code>${escapeHtml(row.referenceNumber)}</code>` },
        { key: "checkDate", label: "Check Date", render: (row) => formatDate(row.checkDate) },
        { key: "received", label: "Date Received", render: (row) => formatDate(row.dateReceived) },
        { key: "deposited", label: "Date Deposited", render: (row) => formatDate(row.dateDeposited) },
        { key: "status", label: "Status", render: (row) => statusBadge(row.status) },
        { key: "or", label: "OR Status", render: (row) => statusBadge(receiptPaymentIds.has(row.id) ? "Matched" : "Missing OR") },
        { key: "actions", label: "Actions", render: (row) => `<a href="/collections/${row.id}" data-link>View</a><button type="button" data-action="delete-record" data-type="payments" data-id="${row.id}">Delete</button>` }
      ]
    })}
    ${page.controls}
  `;
}

function bindCollections() {
  bindSearch(document);
  bindTableSorts(document);
  bindDeleteActions();
}

function renderPaymentForm() {
  const selected = new URLSearchParams(location.search).get("beneficiary") || "";
  return `
    ${pageHeader({
      title: "Record Payment",
      eyebrow: "Internal / Collections",
      description: "Allocate one payment across one or more unpaid installments, then review before saving.",
      actions: buttonLink("/collections", "Back to Collections", "chevron", "secondary")
    })}
    <form class="record-form" data-payment-form novalidate>
      <div class="error-summary" data-error-summary hidden></div>
      <section class="form-section">
        <div class="form-section-heading"><h2>Payment Details</h2><p>Reference numbers remain text values.</p></div>
        <div class="form-grid">
          <label class="field"><span>Cooperator*</span><select name="beneficiaryId" required><option value="">Select cooperator</option>${beneficiaryOptionList(selected)}</select><em class="field-error" data-error-for="beneficiaryId"></em></label>
          <label class="field"><span>Project</span><input name="projectTitle" readonly value="" data-selected-project /></label>
          ${field({ label: "Payment date", name: "paymentDate", type: "date", value: todayIso(), required: true })}
          ${field({ label: "Amount", name: "amount", type: "number", min: "0.01", step: "0.01", required: true })}
          ${selectField({ label: "Payment method", name: "method", options: lookups.paymentMethods, required: true })}
          ${field({ label: "Check, PDC, PMO, or reference number", name: "referenceNumber", help: "Stored as a string." })}
          ${field({ label: "Check date", name: "checkDate", type: "date" })}
          ${field({ label: "Bank", name: "bank" })}
          ${field({ label: "Date received", name: "dateReceived", type: "date", value: todayIso() })}
          ${field({ label: "Date deposited", name: "dateDeposited", type: "date" })}
          ${selectField({ label: "Payment status", name: "status", options: lookups.paymentStatuses, value: "Received" })}
          ${fileUpload({ label: "Payment attachment" })}
          ${textArea({ label: "Remarks", name: "remarks", className: "span-2" })}
        </div>
      </section>
      <section class="panel allocation-panel">
        <div class="panel-head"><div><h2>Installment Allocation</h2><p data-balance-summary>Select a cooperator to show current balance and unpaid installments.</p></div></div>
        <div data-allocation-table>${selected ? renderAllocationInputs(selected) : emptyState("No cooperator selected", "Choose a cooperator to allocate the payment.")}</div>
        <div class="allocation-summary" data-allocation-summary></div>
      </section>
      <section class="panel review-panel" data-payment-review hidden></section>
      <div class="sticky-actions">
        <a class="btn btn-ghost" href="/collections" data-link>Cancel</a>
        <button class="btn btn-secondary" type="button" data-action="review-payment">Review Payment</button>
        <button class="btn btn-primary" type="submit" disabled data-confirm-payment>Confirm and Save</button>
      </div>
    </form>
  `;
}

function renderAllocationInputs(beneficiaryId) {
  const schedule = getSchedule(beneficiaryId).filter((item) => item.remainingAmount > 0).slice(0, 8);
  if (!schedule.length) return emptyState("No unpaid installments", "This account has no unpaid installments in the schedule preview.");
  return `
    <div class="table-wrap">
      <table class="data-table allocation-table">
        <thead><tr><th>Installment</th><th>Due Date</th><th>Remaining</th><th>Allocate Amount</th></tr></thead>
        <tbody>${schedule
          .map((item) => `<tr><td>${item.installmentNumber}</td><td>${formatDate(item.dueDate)}</td><td>${formatCurrency(item.remainingAmount)}</td><td><input type="number" min="0" step="0.01" data-allocation-input data-installment="${item.installmentNumber}" value="0" /></td></tr>`)
          .join("")}</tbody>
      </table>
    </div>
  `;
}

function updatePaymentAllocationSummary(form) {
  const amount = toNumber(form.elements.amount.value);
  const allocated = [...form.querySelectorAll("[data-allocation-input]")].reduce((sum, input) => sum + toNumber(input.value), 0);
  const beneficiaryId = form.elements.beneficiaryId.value;
  const financials = beneficiaryId ? getBeneficiaryFinancials(beneficiaryId) : null;
  const warning =
    amount && allocated !== amount
      ? `<p class="warning-text">Allocated amount (${formatCurrency(allocated)}) does not equal payment amount (${formatCurrency(amount)}).</p>`
      : "";
  const exceeds = financials && amount > financials.outstandingBalance ? `<p class="warning-text">Payment exceeds remaining balance (${formatCurrency(financials.outstandingBalance)}).</p>` : "";
  form.querySelector("[data-allocation-summary]").innerHTML = `<strong>Allocated ${formatCurrency(allocated)}</strong>${warning}${exceeds}`;
}

function bindPaymentForm() {
  const form = document.querySelector("[data-payment-form]");
  if (!form) return;
  bindDirtyForm(form);
  const updateBeneficiary = () => {
    const beneficiary = beneficiaryService.getWithFinancials(form.elements.beneficiaryId.value);
    form.querySelector("[data-selected-project]").value = beneficiary?.project.title || "";
    form.querySelector("[data-balance-summary]").textContent = beneficiary
      ? `Current balance ${formatCurrency(beneficiary.financials.outstandingBalance)} / amount due ${formatCurrency(beneficiary.financials.amountDue)}`
      : "Select a cooperator to show current balance and unpaid installments.";
    form.querySelector("[data-allocation-table]").innerHTML = beneficiary ? renderAllocationInputs(beneficiary.id) : emptyState("No cooperator selected", "Choose a cooperator to allocate the payment.");
    bindAllocationInputs();
  };
  const bindAllocationInputs = () => {
    form.querySelectorAll("[data-allocation-input], [name='amount']").forEach((input) => input.addEventListener("input", () => updatePaymentAllocationSummary(form)));
    updatePaymentAllocationSummary(form);
  };
  form.elements.beneficiaryId.addEventListener("change", updateBeneficiary);
  updateBeneficiary();
  document.querySelector("[data-action='review-payment']").addEventListener("click", () => {
    const data = readForm(form);
    const allocations = getPaymentAllocations(form);
    const errors = collectionService.validate(data, allocations);
    setFieldErrors(form, errors);
    if (Object.keys(errors).length) {
      focusFirstError(form);
      return;
    }
    const review = form.querySelector("[data-payment-review]");
    review.hidden = false;
    review.innerHTML = `<div class="panel-head"><h2>Review Payment</h2><p>Confirm details before saving.</p></div><dl><div><dt>Amount</dt><dd>${formatCurrency(data.amount)}</dd></div><div><dt>Reference</dt><dd>${escapeHtml(data.referenceNumber || "None")}</dd></div><div><dt>Allocations</dt><dd>${allocations.length} installment(s)</dd></div></dl>`;
    form.querySelector("[data-confirm-payment]").disabled = false;
  });
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const data = readForm(form);
    if (["Returned", "Cancelled"].includes(data.status) && !window.confirm(`Record this payment as ${data.status}?`)) return;
    const allocations = getPaymentAllocations(form);
    const errors = collectionService.validate(data, allocations);
    setFieldErrors(form, errors);
    if (Object.keys(errors).length) {
      focusFirstError(form);
      return;
    }
    collectionService.create(data, allocations);
    window.__dirtyForm = false;
    createToast("Payment recorded.");
    navigate("/collections");
  });
}

function getPaymentAllocations(form) {
  const beneficiaryId = form.elements.beneficiaryId.value;
  return [...form.querySelectorAll("[data-allocation-input]")]
    .map((input) => ({
      beneficiaryId,
      installmentNumber: Number(input.dataset.installment),
      amount: toNumber(input.value)
    }))
    .filter((item) => item.amount > 0);
}

function renderPaymentDetail(id) {
  const payment = collectionService.get(id);
  if (!payment) return errorState("Payment record was not found.");
  return `
    ${pageHeader({ title: "Payment Detail", eyebrow: "Internal / Collections", actions: `${buttonLink("/collections", "Back", "chevron", "secondary")}<button class="btn btn-ghost" type="button" data-action="delete-record" data-type="payments" data-id="${payment.id}">Delete</button>` })}
    <section class="panel detail-panel"><dl>
      <div><dt>Cooperator</dt><dd>${escapeHtml(payment.beneficiary ? getCooperatorView(payment.beneficiary).firmName : "")}</dd></div>
      <div><dt>Payment Date</dt><dd>${formatDate(payment.paymentDate)}</dd></div>
      <div><dt>Amount</dt><dd>${formatCurrency(payment.amount)}</dd></div>
      <div><dt>Method</dt><dd>${escapeHtml(payment.method)}</dd></div>
      <div><dt>Reference Number</dt><dd><code>${escapeHtml(payment.referenceNumber)}</code></dd></div>
      <div><dt>Status</dt><dd>${statusBadge(payment.status)}</dd></div>
    </dl></section>
  `;
}

function bindPaymentDetail() {
  bindDeleteActions("/collections");
}

function renderReceipts() {
  const receipts = receiptService.list();
  const rows = receipts.map((item) => ({ ...item, searchText: `${item.orNumber} ${item.beneficiary?.firmName} ${item.payment?.referenceNumber}` }));
  const page = pagedRows(rows, "/receipts");
  return `
    ${pageHeader({ title: "Official Receipts", eyebrow: "Internal / Receipts", description: "Track OR records and warnings before reconciliation.", actions: buttonLink("/receipts/new", "Add Official Receipt", "receipt", "primary") })}
    <section class="list-toolbar">${searchInput("Search visible receipts")}<p class="result-count"><strong data-visible-count>${page.rows.length}</strong> shown, ${page.start}-${page.end} of ${page.totalRows} receipts</p></section>
    ${dataTable({
      rows: page.rows,
      columns: [
        { key: "or", label: "OR Number", render: (row) => `<code>${escapeHtml(row.orNumber)}</code>` },
        { key: "date", label: "OR Date", render: (row) => formatDate(row.orDate) },
        { key: "beneficiary", label: "Cooperator", render: (row) => escapeHtml(row.beneficiary ? getCooperatorView(row.beneficiary).firmName : "") },
        { key: "payment", label: "Related Payment", render: (row) => `<code>${escapeHtml(row.payment?.referenceNumber || "Missing")}</code>` },
        { key: "paymentAmount", label: "Payment Amount", render: (row) => formatCurrency(row.payment?.amount || 0) },
        { key: "orAmount", label: "OR Amount", render: (row) => formatCurrency(row.amount) },
        { key: "difference", label: "Difference", render: (row) => formatCurrency(row.amount - (row.payment?.amount || 0)) },
        { key: "status", label: "Reconciliation Status", render: (row) => statusBadge(Math.abs(row.amount - (row.payment?.amount || 0)) > 0.01 ? "Amount Mismatch" : "Matched") },
        { key: "actions", label: "Actions", render: (row) => `<button type="button">View</button><button type="button" data-action="delete-record" data-type="receipts" data-id="${row.id}">Delete</button>` }
      ]
    })}
    ${page.controls}
  `;
}

function bindReceipts() {
  bindSearch(document);
  bindDeleteActions();
}

function renderReceiptForm() {
  return `
    ${pageHeader({ title: "Record Official Receipt", eyebrow: "Internal / Receipts", description: "Validate OR number, date, amount, and related payment.", actions: buttonLink("/receipts", "Back to Receipts", "chevron", "secondary") })}
    <form class="record-form" data-receipt-form novalidate>
      <div class="error-summary" data-error-summary hidden></div>
      ${formSection(
        "Official Receipt Details",
        "Warnings compare OR details against the selected saved payment.",
        `<label class="field"><span>Cooperator*</span><select name="beneficiaryId" required><option value="">Select cooperator</option>${beneficiaryOptionList()}</select><em class="field-error" data-error-for="beneficiaryId"></em></label>
        <label class="field"><span>Related payment*</span><select name="paymentId" required><option value="">Select payment</option></select><em class="field-error" data-error-for="paymentId"></em></label>` +
          field({ label: "Official receipt number", name: "orNumber", required: true, help: "Stored as a string." }) +
          field({ label: "Official receipt date", name: "orDate", type: "date", value: todayIso(), required: true }) +
          field({ label: "Official receipt amount", name: "amount", type: "number", step: "0.01", min: "0.01", required: true }) +
          field({ label: "Penalty amount", name: "penaltyAmount", type: "number", step: "0.01", min: "0", value: 0 }) +
          fileUpload({ label: "OR attachment", name: "attachmentName" }) +
          textArea({ label: "Remarks", name: "remarks", className: "span-2" })
      )}
      <section class="panel warning-panel" data-receipt-warnings hidden></section>
      <div class="sticky-actions"><a class="btn btn-ghost" href="/receipts" data-link>Cancel</a><button class="btn btn-primary" type="submit">Save Receipt</button></div>
    </form>
  `;
}

function bindReceiptForm() {
  const form = document.querySelector("[data-receipt-form]");
  bindDirtyForm(form);
  const updatePayments = () => {
    const payments = collectionService
      .list()
      .filter((item) => item.beneficiaryId === form.elements.beneficiaryId.value && !["Pending", "Returned", "Replaced", "Cancelled"].includes(item.status));
    form.elements.paymentId.innerHTML = `<option value="">Select payment</option>${payments.map((item) => `<option value="${item.id}">${escapeHtml(item.referenceNumber)} - ${formatCurrency(item.amount)}</option>`).join("")}`;
  };
  const updateWarnings = () => {
    const data = readForm(form);
    const payment = collectionService.get(data.paymentId);
    const warnings = [];
    if (receiptService.list({ includeArchived: true }).some((item) => item.orNumber === data.orNumber)) warnings.push("Duplicate OR number.");
    if (payment && toNumber(data.amount) && Math.abs(payment.amount - toNumber(data.amount)) > 0.01) warnings.push("OR amount differs from payment amount.");
    if (payment && data.orDate && data.orDate < payment.paymentDate) warnings.push("OR date is earlier than payment date.");
    const panel = form.querySelector("[data-receipt-warnings]");
    panel.hidden = warnings.length === 0;
    panel.innerHTML = warnings.length ? `<div class="panel-head"><h2>Frontend Warnings</h2></div><ul>${warnings.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>` : "";
  };
  form.elements.beneficiaryId.addEventListener("change", () => {
    updatePayments();
    updateWarnings();
  });
  form.addEventListener("input", updateWarnings);
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const data = readForm(form);
    const errors = receiptService.validate(data);
    setFieldErrors(form, errors);
    if (Object.keys(errors).length) {
      focusFirstError(form);
      return;
    }
    receiptService.create(data);
    window.__dirtyForm = false;
    createToast("Official receipt saved.");
    navigate("/receipts");
  });
}

function renderReconciliation() {
  const records = reconciliationService.list();
  const counts = Object.fromEntries(lookups.reconciliationStatuses.map((status) => [status, records.filter((item) => item.status === status).length]));
  const rows = records.map((item) => ({ ...item, searchText: `${item.beneficiary?.firmName} ${item.payment.referenceNumber} ${item.receipt?.orNumber || ""} ${item.status}` }));
  const page = pagedRows(rows, "/reconciliation");
  return `
    ${pageHeader({ title: "Reconciliation", eyebrow: "Internal / Review Workspace", description: "Compare payment records against official receipts.", actions: buttonLink("/receipts/new", "Link Receipt", "receipt", "primary") })}
    <section class="summary-grid compact">${lookups.reconciliationStatuses.map((status) => summaryCard({ label: status, value: String(counts[status] || 0), context: "Payment/OR records", iconName: status === "Matched" ? "check" : "alert" })).join("")}</section>
    <section class="list-toolbar">${searchInput("Search visible reconciliation rows")}<label>Status <select data-recon-status><option value="">All</option>${lookups.reconciliationStatuses.map((item) => `<option>${escapeHtml(item)}</option>`).join("")}</select></label><p class="result-count"><strong data-visible-count>${page.rows.length}</strong> shown, ${page.start}-${page.end} of ${page.totalRows} rows</p></section>
    ${dataTable({
      rows: page.rows,
      columns: [
        { key: "beneficiary", label: "Cooperator", render: (row) => escapeHtml(row.beneficiary ? getCooperatorView(row.beneficiary).firmName : "") },
        { key: "reference", label: "Payment Reference", render: (row) => `<code>${escapeHtml(row.payment.referenceNumber)}</code>` },
        { key: "paymentDate", label: "Payment Date", render: (row) => formatDate(row.payment.paymentDate) },
        { key: "paymentAmount", label: "Payment Amount", render: (row) => formatCurrency(row.payment.amount) },
        { key: "or", label: "OR Number", render: (row) => `<code>${escapeHtml(row.receipt?.orNumber || "Missing")}</code>` },
        { key: "orDate", label: "OR Date", render: (row) => formatDate(row.receipt?.orDate) },
        { key: "orAmount", label: "OR Amount", render: (row) => formatCurrency(row.receipt?.amount || 0) },
        { key: "difference", label: "Difference", render: (row) => `<span class="${row.difference ? "amount-warning" : ""}">${formatCurrency(row.difference)}</span>` },
        { key: "status", label: "Reconciliation Status", render: (row) => statusBadge(row.status) },
        { key: "actions", label: "Actions", render: (row) => `<button type="button" data-action="compare-record" data-id="${row.payment.id}">Compare</button><button type="button" data-action="mark-reviewed">Mark reviewed</button>` }
      ]
    })}
    ${page.controls}
    <aside class="comparison-drawer" data-comparison-drawer aria-label="Side-by-side comparison"></aside>
  `;
}

function bindReconciliation() {
  bindSearch(document);
  document.querySelector("[data-recon-status]")?.addEventListener("change", (event) => {
    const status = event.target.value.toLowerCase();
    document.querySelectorAll("[data-record-row]").forEach((row) => {
      row.hidden = status && !row.textContent.toLowerCase().includes(status);
    });
  });
  document.querySelectorAll("[data-action='compare-record']").forEach((button) => {
    button.addEventListener("click", () => {
      const item = reconciliationService.list().find((record) => record.payment.id === button.dataset.id);
      const drawer = document.querySelector("[data-comparison-drawer]");
      drawer.classList.add("open");
      drawer.innerHTML = `<div class="drawer-head"><strong>Payment vs OR</strong><button class="icon-btn" type="button" data-close-comparison>${icon("close")}</button></div><div class="compare-grid"><section><h3>Payment</h3><p>${escapeHtml(item.beneficiary?.firmName || "")}</p><strong>${formatCurrency(item.payment.amount)}</strong><code>${escapeHtml(item.payment.referenceNumber)}</code><span>${formatDate(item.payment.paymentDate)}</span></section><section><h3>Official Receipt</h3><p>${escapeHtml(item.receipt?.orNumber || "Missing OR")}</p><strong>${formatCurrency(item.receipt?.amount || 0)}</strong><span>${formatDate(item.receipt?.orDate)}</span>${statusBadge(item.status)}</section></div>`;
      drawer.querySelector("[data-close-comparison]").addEventListener("click", () => drawer.classList.remove("open"));
    });
  });
  document.querySelectorAll("[data-action='mark-reviewed']").forEach((button) => button.addEventListener("click", () => createToast("Marked as reviewed in the frontend workspace.")));
}

function renderDeferments() {
  const records = defermentService.list();
  return `
    ${pageHeader({ title: "Deferments", eyebrow: "Internal / Deferment Records", description: "Record external deferment approvals and preview schedule effects.", actions: buttonLink("/deferments/new", "Add Deferment", "calendar", "primary") })}
    <section class="list-toolbar">${searchInput("Search cooperator, reason, or status")}</section>
    ${renderSimpleDefermentTable(records)}
    <section class="mobile-record-list">${records.map((item) => mobileRecordCard({ title: item.beneficiary?.firmName || "", subtitle: item.reason, status: item.status, meta: [{ label: "Period", value: `${formatDate(item.startDate)} - ${formatDate(item.endDate)}` }, { label: "Months", value: item.months }], actions: `<button class="btn btn-ghost" type="button" data-action="delete-record" data-type="deferments" data-id="${item.id}">Delete</button>` })).join("")}</section>
  `;
}

function bindDeferments() {
  bindSearch(document);
  bindDeleteActions();
}

function renderDefermentForm() {
  const selected = new URLSearchParams(location.search).get("beneficiary") || "";
  return `
    ${pageHeader({ title: "Add Deferment", eyebrow: "Internal / Deferments", description: "No in-system approval workflow; record only externally completed status.", actions: buttonLink("/deferments", "Back", "chevron", "secondary") })}
    <form class="record-form" data-deferment-form novalidate>
      <div class="error-summary" data-error-summary hidden></div>
      ${formSection(
        "Deferment Record",
        "Approved deferments demonstrate adjusted due dates and affected installments.",
        `<label class="field"><span>Cooperator*</span><select name="beneficiaryId" required><option value="">Select cooperator</option>${beneficiaryOptionList(selected)}</select><em class="field-error" data-error-for="beneficiaryId"></em></label>` +
          field({ label: "Request date", name: "requestDate", type: "date", value: todayIso(), required: true }) +
          field({ label: "Deferment start date", name: "startDate", type: "date", required: true }) +
          field({ label: "Deferment end date", name: "endDate", type: "date", required: true }) +
          field({ label: "Deferred months", name: "months", type: "number", min: "1", required: true }) +
          textArea({ label: "Reason", name: "reason", required: true, className: "span-2" }) +
          field({ label: "Approval date", name: "approvalDate", type: "date" }) +
          field({ label: "Approved by", name: "approvedBy" }) +
          selectField({ label: "Recorded status", name: "status", options: lookups.defermentStatuses, value: "Approved Externally" }) +
          fileUpload({ label: "Supporting document" }) +
          textArea({ label: "Remarks", name: "remarks", className: "span-2" })
      )}
      <section class="panel effect-preview" data-deferment-preview>${emptyState("No preview yet", "Select a cooperator and dates to preview schedule effects.")}</section>
      <div class="sticky-actions"><a class="btn btn-ghost" href="/deferments" data-link>Cancel</a><button class="btn btn-primary" type="submit">Save Deferment</button></div>
    </form>
  `;
}

function bindDefermentForm() {
  const form = document.querySelector("[data-deferment-form]");
  bindDirtyForm(form);
  const preview = () => {
    const beneficiary = beneficiaryService.getWithFinancials(form.elements.beneficiaryId.value);
    if (!beneficiary) return;
    const months = Number(form.elements.months.value || 0);
    form.querySelector("[data-deferment-preview]").innerHTML = `<div class="panel-head"><h2>Projected Effect</h2></div><dl><div><dt>Adjusted due date</dt><dd>${formatDate(addMonthsSafe(beneficiary.financials.adjustedDueDate, months))}</dd></div><div><dt>Affected installments</dt><dd>${getSchedule(beneficiary.id).filter((item) => item.dueDate >= form.elements.startDate.value && item.dueDate <= form.elements.endDate.value).length}</dd></div><div><dt>Updated amount due preview</dt><dd>${formatCurrency(Math.max(0, beneficiary.financials.amountDue - months * beneficiary.financial.monthlyRefundAmount))}</dd></div></dl>`;
  };
  form.addEventListener("input", preview);
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const data = readForm(form);
    const errors = defermentService.validate(data);
    setFieldErrors(form, errors);
    if (Object.keys(errors).length) return focusFirstError(form);
    defermentService.create(data);
    window.__dirtyForm = false;
    createToast("Deferment saved.");
    navigate("/deferments");
  });
}

function addMonthsSafe(date, months) {
  return addMonths(date, months);
}

function renderAdjustments() {
  const records = adjustmentService.list();
  return `
    ${pageHeader({ title: "Account Adjustments", eyebrow: "Internal / Adjustments", description: "Represent changes as separate records instead of editable balance fields.", actions: buttonLink("/adjustments/new", "Create Adjustment", "edit", "primary") })}
    <section class="list-toolbar">${searchInput("Search cooperator, type, or reason")}</section>
    ${renderSimpleAdjustmentTable(records)}
  `;
}

function bindAdjustments() {
  bindSearch(document);
  bindDeleteActions();
}

function renderAdjustmentForm() {
  return `
    ${pageHeader({ title: "Create Adjustment", eyebrow: "Internal / Adjustments", description: "Preview the projected effect before saving the adjustment record.", actions: buttonLink("/adjustments", "Back", "chevron", "secondary") })}
    <form class="record-form" data-adjustment-form novalidate>
      <div class="error-summary" data-error-summary hidden></div>
      ${formSection(
        "Adjustment Details",
        "Never edit balance directly; use this adjustment record.",
        `<label class="field"><span>Cooperator*</span><select name="beneficiaryId" required><option value="">Select cooperator</option>${beneficiaryOptionList()}</select><em class="field-error" data-error-for="beneficiaryId"></em></label>` +
          selectField({ label: "Adjustment type", name: "type", options: lookups.adjustmentTypes, required: true }) +
          field({ label: "Effective date", name: "effectiveDate", type: "date", value: todayIso(), required: true }) +
          field({ label: "Amount", name: "amount", type: "number", min: "0", step: "0.01" }) +
          field({ label: "Previous value", name: "previousValue" }) +
          field({ label: "New value", name: "newValue" }) +
          textArea({ label: "Reason", name: "reason", required: true, className: "span-2" }) +
          field({ label: "Approved by", name: "approvedBy" }) +
          fileUpload({ label: "Supporting document" }) +
          textArea({ label: "Remarks", name: "remarks", className: "span-2" })
      )}
      <section class="panel effect-preview" data-adjustment-preview>${emptyState("No preview yet", "Select a cooperator and amount to preview the projected effect.")}</section>
      <div class="sticky-actions"><a class="btn btn-ghost" href="/adjustments" data-link>Cancel</a><button class="btn btn-primary" type="submit">Save Adjustment</button></div>
    </form>
  `;
}

function bindAdjustmentForm() {
  const form = document.querySelector("[data-adjustment-form]");
  bindDirtyForm(form);
  const preview = () => {
    const beneficiary = beneficiaryService.getWithFinancials(form.elements.beneficiaryId.value);
    if (!beneficiary) return;
    const amount = toNumber(form.elements.amount.value);
    const type = form.elements.type.value;
    const direction = ["Added Fee", "Penalty Adjustment"].includes(type) ? 1 : ["Waived Amount", "Write-off", "Equipment Pull-out", "Terminated Project", "Withdrawn Project"].includes(type) ? -1 : 0;
    form.querySelector("[data-adjustment-preview]").innerHTML = `<div class="panel-head"><h2>Projected Effect</h2></div><dl><div><dt>Current service-derived balance</dt><dd>${formatCurrency(beneficiary.financials.outstandingBalance)}</dd></div><div><dt>Projected balance</dt><dd>${formatCurrency(Math.max(0, beneficiary.financials.outstandingBalance + direction * amount))}</dd></div><div><dt>Representation</dt><dd>Separate adjustment record; no direct balance field.</dd></div></dl>`;
  };
  form.addEventListener("input", preview);
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const data = readForm(form);
    const errors = adjustmentService.validate(data);
    setFieldErrors(form, errors);
    if (Object.keys(errors).length) return focusFirstError(form);
    adjustmentService.create(data);
    window.__dirtyForm = false;
    createToast("Adjustment saved.");
    navigate("/adjustments");
  });
}

function renderDocuments() {
  const records = documentService.list();
  return `
    ${pageHeader({ title: "Documents", eyebrow: "Internal / Document Management", description: "Frontend-only upload organization ready for backend storage integration.", actions: "" })}
    <form class="panel upload-workspace" data-document-form>
      <div class="panel-head"><h2>Upload Supporting Document</h2><p>Validates type and size in the frontend.</p></div>
      <div class="form-grid">
        ${selectField({ label: "Document category", name: "category", options: lookups.documentCategories, required: true })}
        <label class="field"><span>Cooperator association</span><select name="beneficiaryId"><option value="">Select cooperator</option>${beneficiaryOptionList()}</select></label>
        ${field({ label: "Related transaction", name: "relatedTransaction" })}
        ${field({ label: "Document date", name: "documentDate", type: "date", value: todayIso() })}
        ${textArea({ label: "Description", name: "description", className: "span-2" })}
        ${fileUpload({ label: "Choose file", name: "documentFile" })}
      </div>
      <div class="action-row"><button class="btn btn-primary" type="submit">${icon("upload")} Add Document</button></div>
    </form>
    <section class="list-toolbar">${searchInput("Search file, category, cooperator, or transaction")}</section>
    ${dataTable({
      rows: records.map((item) => ({ ...item, searchText: `${item.category} ${item.fileName} ${item.beneficiary?.firmName} ${item.relatedTransaction}` })),
      columns: [
        { key: "category", label: "Category", render: (row) => escapeHtml(row.category) },
        { key: "beneficiary", label: "Cooperator", render: (row) => escapeHtml(row.beneficiary ? getCooperatorView(row.beneficiary).firmName : "Unassigned") },
        { key: "project", label: "Project", render: (row) => escapeHtml(row.projectTitle) },
        { key: "related", label: "Related Transaction", render: (row) => escapeHtml(row.relatedTransaction) },
        { key: "date", label: "Document Date", render: (row) => formatDate(row.documentDate) },
        { key: "file", label: "File", render: (row) => escapeHtml(row.fileName) },
        { key: "actions", label: "Actions", render: (row) => `<button type="button">Preview</button><button type="button">Download</button><button type="button">Replace</button><button type="button" data-action="archive-document" data-id="${row.id}">Archive</button><button type="button" data-action="delete-record" data-type="documents" data-id="${row.id}">Delete</button>` }
      ]
    })}
  `;
}

function bindDocuments() {
  bindSearch(document);
  const form = document.querySelector("[data-document-form]");
  form?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const file = form.elements.documentFile.files[0];
    const fileError = documentService.validateFile(file);
    if (fileError) {
      form.querySelector('[data-error-for="documentFile"]').textContent = fileError;
      return;
    }
    await documentService.create(readForm(form), file);
    createToast("Document added to the current frontend session.");
    renderApp();
  });
  document.querySelectorAll("[data-action='archive-document']").forEach((button) => {
    button.addEventListener("click", () => {
      documentService.archive(button.dataset.id);
      createToast("Document archived.");
      renderApp();
    });
  });
  bindDeleteActions();
}

function renderReports() {
  const query = getQuery();
  const selectedType = query.type || reportService.reportTypes[0];
  const rows = reportService.getPreview(selectedType, query);
  const officerOptions = [...new Set(beneficiaryService.list().map((item) => getCooperatorView(item).setup.assignedProjectOfficer).filter(Boolean))].sort();
  return `
    ${pageHeader({ title: "Reports", eyebrow: "Internal / Report Center", description: "Preview, print, and export collection reports.", actions: "" })}
    <section class="control-panel report-filters">
      <label>Report <select data-report-filter="type">${reportService.reportTypes.map((item) => `<option ${item === selectedType ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <label>As-of date <input type="date" data-report-filter="asOf" value="${escapeHtml(query.asOf || todayIso())}" /></label>
      <label>Date from <input type="date" data-report-filter="dateFrom" value="${escapeHtml(query.dateFrom || "")}" /></label>
      <label>Date to <input type="date" data-report-filter="dateTo" value="${escapeHtml(query.dateTo || "")}" /></label>
      <label>Project year <select data-report-filter="year"><option value="">All</option>${yearOptions(query.year)}</select></label>
      <label>Municipality <select data-report-filter="municipality"><option value="">All</option>${lookups.municipalities.map((item) => `<option ${item === query.municipality ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <label>District <select data-report-filter="district"><option value="">All</option>${lookups.districts.map((item) => `<option ${item === query.district ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <label>Business sector <select data-report-filter="businessSector"><option value="">All</option>${lookups.businessSectors.map((item) => `<option ${item === query.businessSector ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <label>Assigned Project Officer <select data-report-filter="officer"><option value="">All</option>${officerOptions.map((item) => `<option ${item === query.officer ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <label>Project status <select data-report-filter="projectStatus"><option value="">All</option>${lookups.setupProjectStatuses.map((item) => `<option ${item === query.projectStatus ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}</select></label>
      <button class="btn btn-ghost" type="button" data-action="reset-reports">Reset filters</button>
    </section>
    <section class="action-row">
      <button class="btn btn-secondary" type="button" data-action="print-page">${icon("print")} Print</button>
      <button class="btn btn-secondary" type="button" data-action="export-report-csv">${icon("download")} Export CSV</button>
      <button class="btn btn-secondary" type="button" data-action="export-report-xlsx">Export Excel</button>
      <button class="btn btn-secondary" type="button" data-action="export-report-pdf">Export PDF</button>
    </section>
    <p class="applied-filters">${Object.entries(query)
      .filter(([, value]) => value)
      .map(([key, value]) => `${key}: ${value}`)
      .join(" / ") || "No filters applied."}</p>
    ${reportPreview(selectedType, query, rows)}
  `;
}

function bindReports() {
  document.querySelectorAll("[data-report-filter]").forEach((control) => {
    control.addEventListener("change", () => {
      const filters = {};
      document.querySelectorAll("[data-report-filter]").forEach((item) => {
        filters[item.dataset.reportFilter] = item.value;
      });
      setQuery("/reports", filters);
    });
  });
  document.querySelector("[data-action='reset-reports']")?.addEventListener("click", () => navigate("/reports"));
  document.querySelector("[data-action='print-page']")?.addEventListener("click", () => window.print());
  document.querySelector("[data-action='export-report-csv']")?.addEventListener("click", () => {
    const query = getQuery();
    const rows = reportService.getPreview(query.type || reportService.reportTypes[0], query);
    const columns = Object.keys(rows[0] || {});
    downloadCsv("report-preview.csv", [columns, ...rows.map((row) => columns.map((key) => row[key]))]);
  });
  document.querySelector("[data-action='export-report-xlsx']")?.addEventListener("click", () => {
    const query = getQuery();
    const type = query.type || reportService.reportTypes[0];
    downloadXlsx(`${slug(type)}.xlsx`, type, reportService.getPreview(type, query));
  });
  document.querySelector("[data-action='export-report-pdf']")?.addEventListener("click", () => {
    const query = getQuery();
    const type = query.type || reportService.reportTypes[0];
    downloadPdf(`${slug(type)}.pdf`, type, reportService.getPreview(type, query));
  });
}

function renderImport() {
  const step = uiState.importStep;
  const payload = uiState.importPayload;
  const steps = ["Upload File", "Select Sheet", "Map Columns", "Preview Records", "Review Validation Errors", "Review Duplicates", "Confirm Import", "Import Result"];
  const nextLabel = step === steps.length ? "Restart" : step === 7 ? "Import to Database" : "Next";
  return `
    ${pageHeader({ title: "Data Import", eyebrow: "Internal / Historical Spreadsheet Import", description: "Import cooperator and SETUP project rows from XLSX, XLS, or CSV files into Supabase.", actions: "" })}
    <section class="wizard">
      <ol class="wizard-steps">${steps.map((item, index) => `<li class="${index + 1 === step ? "active" : index + 1 < step ? "done" : ""}"><span>${index + 1}</span>${escapeHtml(item)}</li>`).join("")}</ol>
      <div class="panel wizard-panel">${renderImportStep(step, payload)}</div>
      <div class="sticky-actions"><button class="btn btn-ghost" type="button" data-action="import-back" ${step === 1 ? "disabled" : ""}>Back</button><button class="btn btn-primary" type="button" data-action="import-next">${nextLabel}</button></div>
    </section>
  `;
}

function renderImportStep(step, payload) {
  if (step === 1) return `<h2>Upload File</h2><p>Use XLSX, XLS, or CSV. Valid cooperator rows will be saved to the database on confirmation.</p><label class="file-upload">${icon("upload")}<span>Choose spreadsheet</span><small>XLSX, XLS, or CSV up to 15 MB.</small><input type="file" data-import-file accept=".xlsx,.xls,.csv" /></label><em class="field-error" data-import-file-error></em>`;
  if (!payload) return emptyState("No import file", "Upload a file to continue.");
  if (step === 2) return `<h2>Select Sheet</h2><p>${escapeHtml(payload.fileName)} contains ${payload.sheets.length} sheet(s).</p><div class="choice-list">${payload.sheets.map((sheet) => `<label><input type="radio" name="sheet" value="${escapeHtml(sheet)}" ${sheet === payload.selectedSheet ? "checked" : ""} /><span>${escapeHtml(sheet)}</span></label>`).join("")}</div>`;
  if (step === 3) return `<h2>Map Columns</h2><p>Map spreadsheet columns to cooperator and SETUP fields. Required fields are marked with an asterisk.</p><div class="mapping-grid">${importService.fields.map((fieldInfo) => `<label>${escapeHtml(fieldInfo.label)}${fieldInfo.required ? " *" : ""}<select data-import-map="${escapeHtml(fieldInfo.key)}"><option value="">Not mapped</option>${payload.columns.map((column) => `<option value="${escapeHtml(column)}" ${payload.mapping[fieldInfo.key] === column ? "selected" : ""}>${escapeHtml(column)}</option>`).join("")}</select></label>`).join("")}</div>`;
  if (step === 4) return `<h2>Preview Records</h2><p>Showing up to 25 valid rows that will be imported.</p>${payload.preview.length ? dataTable({ rows: payload.preview.map((item) => ({ ...item, searchText: Object.values(item).join(" ") })), columns: Object.keys(payload.preview[0]).map((key) => ({ key, label: key, render: (row) => escapeHtml(row[key]) })) }) : emptyState("No valid rows", "Fix the mapping or spreadsheet rows before importing.")}`;
  if (step === 5) return `<h2>Review Validation Errors</h2><div class="import-stats"><strong>${payload.validCount}</strong><span>Valid</span><strong>${payload.invalidCount}</strong><span>Invalid</span></div>${payload.errors.length ? `<ul class="error-list">${payload.errors.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul><button class="btn btn-secondary" type="button" data-action="download-import-errors">${icon("download")} Download error report</button>` : emptyState("No validation errors", "All mapped rows passed validation.")}`;
  if (step === 6) return `<h2>Review Duplicates</h2>${payload.duplicates.length ? `<ul class="error-list">${payload.duplicates.map((item) => `<li>Duplicate identifier: <code>${escapeHtml(item)}</code></li>`).join("")}</ul>` : emptyState("No duplicates", "No duplicate identifiers were found.")}`;
  if (step === 7) return `<h2>Confirm Import</h2><p>${payload.validCount} valid cooperator record(s) will be saved to the database. ${payload.invalidCount} invalid row(s) will be skipped.</p><div class="progress-meter"><span style="width:${payload.validCount ? 100 : 0}%"></span></div>`;
  return `<h2>Import Result</h2><div class="success-state">${icon("check")}<strong>${payload.importedCount || 0} cooperator record(s) imported to the database</strong><p>${payload.invalidCount} invalid row(s) skipped.</p></div>`;
}

function bindImport() {
  const fileInput = document.querySelector("[data-import-file]");
  fileInput?.addEventListener("change", async () => {
    const file = fileInput.files[0];
    const error = importService.validateFile(file);
    document.querySelector("[data-import-file-error]").textContent = error;
    if (!error) {
      try {
        uiState.importPayload = await importService.parseFile(file);
        createToast("Spreadsheet parsed.");
        renderApp();
      } catch (parseError) {
        document.querySelector("[data-import-file-error]").textContent = "Could not parse this spreadsheet. Check the file and try again.";
        console.error(parseError);
      }
    }
  });
  document.querySelectorAll("[name='sheet']").forEach((input) => {
    input.addEventListener("change", () => {
      uiState.importPayload = importService.selectSheet(uiState.importPayload, input.value);
      renderApp();
    });
  });
  document.querySelectorAll("[data-import-map]").forEach((select) => {
    select.addEventListener("change", () => {
      const mapping = { ...uiState.importPayload.mapping };
      document.querySelectorAll("[data-import-map]").forEach((field) => {
        mapping[field.dataset.importMap] = field.value;
      });
      uiState.importPayload = importService.updateMapping(uiState.importPayload, mapping);
      renderApp();
    });
  });
  document.querySelector("[data-action='import-back']")?.addEventListener("click", () => {
    uiState.importStep = Math.max(1, uiState.importStep - 1);
    renderApp();
  });
  document.querySelector("[data-action='import-next']")?.addEventListener("click", async () => {
    if (uiState.importStep === 1 && !uiState.importPayload) {
      createToast("Upload a valid spreadsheet before continuing.", "danger");
      return;
    }
    if (uiState.importStep === 7) {
      if (!uiState.importPayload.validCount) {
        createToast("There are no valid rows to import.", "danger");
        return;
      }
      uiState.importPayload = await importService.importValidRecords(uiState.importPayload);
    }
    uiState.importStep = uiState.importStep >= 8 ? 1 : uiState.importStep + 1;
    if (uiState.importStep === 1) uiState.importPayload = null;
    renderApp();
  });
  document.querySelector("[data-action='download-import-errors']")?.addEventListener("click", () => {
    const payload = uiState.importPayload;
    downloadCsv("import-errors.csv", [["Error"], ...(payload?.errors || []).map((item) => [item])]);
  });
}

function renderArchived() {
  const sections = [
    ["Cooperators", beneficiaryService.list({ includeArchived: true }).filter((item) => item.archived), "beneficiaries", beneficiaryService.restore],
    ["Payments", collectionService.list({ includeArchived: true }).filter((item) => item.archived), "payments", collectionService.restore],
    ["Receipts", receiptService.list({ includeArchived: true }).filter((item) => item.archived), "receipts", receiptService.restore],
    ["Deferments", defermentService.list({ includeArchived: true }).filter((item) => item.archived), "deferments", defermentService.restore],
    ["Adjustments", adjustmentService.list({ includeArchived: true }).filter((item) => item.archived), "adjustments", adjustmentService.restore],
    ["Documents", documentService.list({ includeArchived: true }).filter((item) => item.archived), "documents", documentService.restore]
  ];
  return `
    ${pageHeader({ title: "Archived Records", eyebrow: "Internal / Archive", description: "Records can be viewed, restored, or permanently deleted.", actions: "" })}
    <section class="list-toolbar">${searchInput("Search archived records")}<label>Type <select data-archive-type><option value="">All</option>${sections.map(([name]) => `<option>${name}</option>`).join("")}</select></label></section>
    <section class="archive-grid">${sections
      .map(([title, records, type]) => `<section class="panel archive-section" data-archive-section="${title}"><div class="panel-head"><h2>${title}</h2><p>${records.length} archived</p></div>${records.length ? records
        .map((item) => `<article data-record-card data-search-text="${escapeHtml(Object.values(item).join(" "))}"><strong>${escapeHtml(item.firmName || item.referenceNumber || item.orNumber || item.type || item.fileName || item.id)}</strong><span>Date archived: ${formatDate(item.updatedAt?.slice(0, 10) || todayIso())}</span><div><button type="button">View record</button><button type="button" data-action="restore-record" data-type="${type}" data-id="${item.id}">Restore</button><button type="button" data-action="delete-record" data-type="${type}" data-id="${item.id}">Delete</button></div></article>`)
        .join("") : emptyState("No archived records", `No archived ${title.toLowerCase()} yet.`)}</section>`)
      .join("")}</section>
  `;
}

const archiveRestoreMap = {
  beneficiaries: beneficiaryService.restore,
  payments: collectionService.restore,
  receipts: receiptService.restore,
  deferments: defermentService.restore,
  adjustments: adjustmentService.restore,
  documents: documentService.restore
};

const deleteRecordMap = {
  beneficiaries: beneficiaryService.delete,
  payments: collectionService.delete,
  receipts: receiptService.delete,
  deferments: defermentService.delete,
  adjustments: adjustmentService.delete,
  documents: documentService.delete
};

function bindDeleteActions(redirectPath = "") {
  document.querySelectorAll("[data-action='delete-record']").forEach((button) => {
    button.addEventListener("click", () => {
      const deleteRecord = deleteRecordMap[button.dataset.type];
      if (!deleteRecord) return;
      if (!window.confirm("Permanently delete this record? This cannot be restored.")) return;
      deleteRecord(button.dataset.id);
      window.__dirtyForm = false;
      createToast("Record deleted.");
      if (redirectPath) navigate(redirectPath);
      else renderApp();
    });
  });
}

function bindArchived() {
  bindSearch(document);
  document.querySelector("[data-archive-type]")?.addEventListener("change", (event) => {
    document.querySelectorAll("[data-archive-section]").forEach((section) => {
      section.hidden = event.target.value && section.dataset.archiveSection !== event.target.value;
    });
  });
  document.querySelectorAll("[data-action='restore-record']").forEach((button) => {
    button.addEventListener("click", () => {
      if (window.confirm("Restore this archived record?")) {
        archiveRestoreMap[button.dataset.type](button.dataset.id);
        createToast("Record restored.");
        renderApp();
      }
    });
  });
  bindDeleteActions();
}

function renderSettings() {
  const settings = settingsService.get();
  return `
    ${pageHeader({ title: "Settings", eyebrow: "Internal / System Settings", description: "System and report settings only. No user accounts, roles, passwords, or permissions.", actions: "" })}
    <form class="record-form" data-settings-form>
      ${formSection(
        "Organization and Report Defaults",
        "Used by print headers and exports.",
        field({ label: "Organization name", name: "organizationName", value: settings.organizationName }) +
          textArea({ label: "Office address", name: "officeAddress", value: settings.officeAddress }) +
          field({ label: "Office contact information", name: "officeContact", value: settings.officeContact }) +
          fileUpload({ label: "Logo upload UI", name: "logo" }) +
          field({ label: "Default report heading", name: "defaultReportHeading", value: settings.defaultReportHeading }) +
          selectField({ label: "Currency format", name: "currencyFormat", options: ["Philippine Peso"], value: settings.currencyFormat }) +
          selectField({ label: "Date display format", name: "dateFormat", options: ["MMM DD, YYYY", "YYYY-MM-DD", "DD/MM/YYYY"], value: settings.dateFormat }) +
          field({ label: "Default repayment months", name: "defaultRepaymentMonths", type: "number", value: settings.defaultRepaymentMonths, min: "1" }) +
          field({ label: "Prepared by", name: "preparedBy", value: settings.preparedBy }) +
          field({ label: "Reviewed by", name: "reviewedBy", value: settings.reviewedBy }) +
          field({ label: "Approved by", name: "approvedBy", value: settings.approvedBy }) +
          field({ label: "Default rows per table", name: "defaultRowsPerTable", type: "number", value: settings.defaultRowsPerTable, min: "5" }) +
          selectField({ label: "Theme preference", name: "themePreference", options: ["Light", "High contrast"], value: settings.themePreference }) +
          `<div class="placeholder-box span-2"><strong>Data backup and restore</strong><p>Export a JSON backup from Supabase or restore one into the connected Supabase database.</p><button class="btn btn-secondary" type="button" data-action="backup-data">Backup Data</button><button class="btn btn-secondary" type="button" data-action="choose-restore-file">Restore Data</button><input type="file" data-restore-file accept=".json,application/json" hidden /></div>`
      )}
      <div class="sticky-actions"><button class="btn btn-primary" type="submit">Save Settings</button></div>
    </form>
  `;
}

function bindSettings() {
  const form = document.querySelector("[data-settings-form]");
  bindDirtyForm(form);
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    settingsService.save(readForm(form));
    window.__dirtyForm = false;
    createToast("Settings saved.");
  });
  document.querySelector("[data-action='backup-data']")?.addEventListener("click", () => {
    downloadJson(`dost-is-setup-backup-${todayIso()}.json`, repository.getState());
  });
  const restoreInput = document.querySelector("[data-restore-file]");
  document.querySelector("[data-action='choose-restore-file']")?.addEventListener("click", () => restoreInput?.click());
  restoreInput?.addEventListener("change", async () => {
    const file = restoreInput.files?.[0];
    if (!file) return;
    try {
      const nextState = JSON.parse(await file.text());
      repository.saveState(nextState);
      window.__dirtyForm = false;
      createToast("Database restored from backup.");
      renderApp();
    } catch (error) {
      console.error(error);
      createToast("Could not restore this backup file.", "danger");
    }
  });
}

function renderNotFound() {
  return `
    ${pageHeader({ title: "Page Not Found", eyebrow: "Internal / Navigation", description: "The requested internal route does not exist.", actions: buttonLink("/", "Return to Dashboard", "dashboard", "primary") })}
    ${emptyState("Invalid internal route", "Use the sidebar or dashboard quick actions to continue.")}
  `;
}

document.body.addEventListener("click", (event) => {
  const link = event.target.closest("a[data-link]");
  if (!link) return;
  const url = new URL(link.href, location.origin);
  if (url.origin !== location.origin) return;
  event.preventDefault();
  navigate(url.hash?.startsWith("#/") ? url.hash.slice(1) : `${url.pathname}${url.search}`);
});

window.addEventListener("hashchange", () => {
  window.__dirtyForm = false;
  renderApp();
});

window.addEventListener("popstate", () => {
  window.__dirtyForm = false;
  renderApp();
});

window.addEventListener("beforeunload", (event) => {
  if (!window.__dirtyForm) return;
  event.preventDefault();
  event.returnValue = "";
});

window.addEventListener("online", () => document.querySelector("[data-online-state]")?.replaceChildren(document.createTextNode("Online")));
window.addEventListener("offline", () => document.querySelector("[data-online-state]")?.replaceChildren(document.createTextNode("Offline")));

try {
  await repository.init();
  renderApp();
} catch (error) {
  console.error("Application startup failed:", error);
  app.innerHTML = errorState("Database connection failed. Confirm src/supabaseClient.js has the correct Supabase URL and anon key, and that Supabase allows this domain.");
}
