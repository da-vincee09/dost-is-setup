import * as XLSX from "./vendor/xlsx.mjs";

export const peso = new Intl.NumberFormat("en-PH", {
  style: "currency",
  currency: "PHP",
  minimumFractionDigits: 2
});

export const shortDate = new Intl.DateTimeFormat("en-PH", {
  year: "numeric",
  month: "short",
  day: "2-digit"
});

export function formatCurrency(value) {
  return peso.format(Number(value || 0));
}

export function formatDate(value) {
  if (!value) return "Not set";
  const date = parseIsoDate(value);
  return Number.isNaN(date.getTime()) ? value : shortDate.format(date);
}

export function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function parseIsoParts(isoDate) {
  const match = String(isoDate || "").match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (!match) return null;
  const parts = {
    year: Number(match[1]),
    month: Number(match[2]),
    day: Number(match[3])
  };
  if (parts.month < 1 || parts.month > 12 || parts.day < 1) return null;
  const lastDay = new Date(parts.year, parts.month, 0).getDate();
  if (parts.day > lastDay) return null;
  return parts;
}

function parseIsoDate(isoDate) {
  const parts = parseIsoParts(isoDate);
  if (!parts) return new Date(Number.NaN);
  return new Date(parts.year, parts.month - 1, parts.day);
}

function isoFromParts(year, monthIndex, day) {
  return `${String(year).padStart(4, "0")}-${String(monthIndex + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

export function addMonths(isoDate, count) {
  const parts = parseIsoParts(isoDate);
  if (!parts) return "";
  const target = new Date(parts.year, parts.month - 1 + count, 1);
  const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
  return isoFromParts(target.getFullYear(), target.getMonth(), Math.min(parts.day, lastDay));
}

export function daysBetween(fromIso, toIso) {
  const from = parseIsoDate(fromIso);
  const to = parseIsoDate(toIso);
  if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime())) return 0;
  return Math.floor((to.getTime() - from.getTime()) / 86400000);
}

export function clamp(number, min, max) {
  return Math.max(min, Math.min(max, number));
}

export function percent(value, total) {
  if (!total) return 0;
  return clamp((value / total) * 100, 0, 999);
}

export function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

export function slug(value) {
  return String(value || "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

export function uid(prefix) {
  const random = Math.random().toString(36).slice(2, 8);
  return `${prefix}-${Date.now().toString(36)}-${random}`;
}

export function toNumber(value) {
  const cleaned = String(value ?? "").replace(/[^0-9.-]/g, "");
  const parsed = Number(cleaned);
  return Number.isFinite(parsed) ? parsed : 0;
}

export function roundCurrency(value) {
  return Math.round((Number(value || 0) + Number.EPSILON) * 100) / 100;
}

export function debounce(fn, wait = 180) {
  let timer = 0;
  return (...args) => {
    window.clearTimeout(timer);
    timer = window.setTimeout(() => fn(...args), wait);
  };
}

export function csvEscape(value) {
  const text = String(value ?? "");
  if (/[",\n]/.test(text)) return `"${text.replaceAll('"', '""')}"`;
  return text;
}

export function downloadCsv(filename, rows) {
  const csv = rows.map((row) => row.map(csvEscape).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

export function downloadJson(filename, value) {
  const blob = new Blob([`${JSON.stringify(value, null, 2)}\n`], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

export function downloadXlsx(filename, sheetName, rows) {
  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName.slice(0, 31) || "Report");
  XLSX.writeFile(workbook, filename);
}

function pdfEscape(value) {
  return String(value ?? "").replaceAll("\\", "\\\\").replaceAll("(", "\\(").replaceAll(")", "\\)");
}

export function downloadPdf(filename, title, rows) {
  const columns = Object.keys(rows[0] || {});
  const lines = [
    title,
    `Generated ${new Date().toLocaleString("en-PH")}`,
    "",
    columns.join(" | "),
    ...rows.slice(0, 40).map((row) => columns.map((key) => String(row[key] ?? "")).join(" | "))
  ];
  if (rows.length > 40) lines.push(`... ${rows.length - 40} more row(s) exported in CSV/Excel.`);
  const content = lines
    .flatMap((line, index) => [`BT /F1 9 Tf 40 ${780 - index * 14} Td (${pdfEscape(line).slice(0, 130)}) Tj ET`])
    .join("\n");
  const objects = [
    "1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj",
    "2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj",
    "3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >> endobj",
    "4 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj",
    `5 0 obj << /Length ${content.length} >> stream\n${content}\nendstream endobj`
  ];
  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  for (const object of objects) {
    offsets.push(pdf.length);
    pdf += `${object}\n`;
  }
  const xrefOffset = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  pdf += offsets.slice(1).map((offset) => `${String(offset).padStart(10, "0")} 00000 n \n`).join("");
  pdf += `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
  const blob = new Blob([pdf], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

export function readForm(form) {
  return Object.fromEntries(new FormData(form).entries());
}

export function setFieldErrors(form, errors) {
  form.querySelectorAll(".field-error").forEach((node) => {
    node.textContent = "";
  });
  Object.entries(errors).forEach(([name, message]) => {
    const output = form.querySelector(`[data-error-for="${CSS.escape(name)}"]`);
    const field = form.querySelector(`[name="${CSS.escape(name)}"]`);
    if (output) output.textContent = message;
    if (field) field.setAttribute("aria-invalid", "true");
  });
  form.querySelectorAll("[aria-invalid='true']").forEach((field) => {
    if (!errors[field.name]) field.removeAttribute("aria-invalid");
  });
  const summary = form.querySelector("[data-error-summary]");
  if (summary) {
    const messages = Object.values(errors);
    summary.hidden = messages.length === 0;
    summary.innerHTML = messages.length
      ? `<strong>Please review the form.</strong><ul>${messages.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>`
      : "";
  }
}

export function focusFirstError(form) {
  const invalid = form.querySelector("[aria-invalid='true']");
  if (invalid) invalid.focus();
}

function getToastHost() {
  let host = document.querySelector("[data-global-toast-region]");
  if (host) return host;
  host = document.createElement("div");
  host.className = "toast-region";
  host.dataset.globalToastRegion = "true";
  host.setAttribute("aria-live", "polite");
  document.body.appendChild(host);
  return host;
}

function createToastLegacy(message, type = "success") {
  const host = getToastHost();
  const item = document.createElement("div");
  const config = {
    success: { title: "Success", icon: "✓" },
    warning: { title: "Needs attention", icon: "!" },
    danger: { title: "Could not save", icon: "!" }
  }[type] || { title: "Notice", icon: "i" };
  item.className = `toast toast-${type}`;
  item.setAttribute("role", type === "danger" ? "alert" : "status");
  item.innerHTML = `
    <span class="toast-icon" aria-hidden="true">${config.icon}</span>
    <span class="toast-copy">
      <strong>${escapeHtml(config.title)}</strong>
      <span>${escapeHtml(message)}</span>
    </span>
    <button class="toast-close" type="button" aria-label="Dismiss notification">×</button>
  `;
  item.querySelector(".toast-close")?.addEventListener("click", () => item.remove());
  host.appendChild(item);
  window.setTimeout(() => item.remove(), type === "danger" ? 7200 : 4600);
}

export function createToast(message, type = "success") {
  const host = getToastHost();
  const item = document.createElement("div");
  const config = {
    success: { title: "Success", path: "M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2Z" },
    warning: { title: "Needs attention", path: "M11 7h2v7h-2V7Zm0 9h2v2h-2v-2Zm1-14 10 19H2L12 2Z" },
    danger: { title: "Could not save", path: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm1 5v7h-2V7h2Zm0 9v2h-2v-2h2Z" }
  }[type] || { title: "Notice", path: "M11 10h2v7h-2v-7Zm0-3h2v2h-2V7Zm1-5a10 10 0 1 0 0 20 10 10 0 0 0 0-20Z" };
  const timeout = type === "danger" ? 7200 : 4600;
  item.className = `toast toast-${type}`;
  item.style.setProperty("--toast-duration", `${timeout}ms`);
  item.setAttribute("role", type === "danger" ? "alert" : "status");
  item.innerHTML = `
    <span class="toast-icon" aria-hidden="true">
      <svg viewBox="0 0 24 24" focusable="false"><path fill="currentColor" d="${config.path}"></path></svg>
    </span>
    <span class="toast-copy">
      <strong>${escapeHtml(config.title)}</strong>
      <span>${escapeHtml(message)}</span>
    </span>
    <button class="toast-close" type="button" aria-label="Dismiss notification">
      <svg viewBox="0 0 24 24" focusable="false"><path fill="currentColor" d="m6.4 5 12.6 12.6-1.4 1.4L5 6.4 6.4 5Zm12.6 1.4L6.4 19 5 17.6 17.6 5 19 6.4Z"></path></svg>
    </button>
    <span class="toast-progress" aria-hidden="true"></span>
  `;
  const dismiss = () => {
    item.classList.add("is-leaving");
    window.setTimeout(() => item.remove(), 180);
  };
  item.querySelector(".toast-close")?.addEventListener("click", dismiss);
  host.appendChild(item);
  window.setTimeout(dismiss, timeout);
}

export function validateEmail(value) {
  if (!value) return true;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

export function validatePhone(value) {
  if (!value) return true;
  return /^[0-9+() -]{7,24}$/.test(value);
}

export function isValidDate(value) {
  if (!value) return false;
  const date = parseIsoDate(value);
  return !Number.isNaN(date.getTime());
}

export function dateAfter(end, start) {
  if (!isValidDate(end) || !isValidDate(start)) return false;
  return parseIsoDate(end) >= parseIsoDate(start);
}
