import { defaultSettings } from "./referenceData.js";
import { supabaseRest, supabaseConfig } from "./supabaseClient.js";

const emptyDate = "1900-01-01";

function n(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function bool(value) {
  return value === true || value === "true" || value === "Yes";
}

function serviceFromDb(row) {
  return {
    id: row.id,
    category: row.category || "",
    subtype: row.subtype || "",
    dateAvailed: row.date_availed || "",
    remarks: row.remarks || "",
    archived: Boolean(row.archived)
  };
}

function serviceToDb(cooperatorId, service, index = 0) {
  return {
    id: service.id || `${cooperatorId}-svc-${index + 1}`,
    cooperator_id: cooperatorId,
    category: service.category || "",
    subtype: service.subtype || "",
    date_availed: emptyToNull(service.dateAvailed),
    remarks: service.remarks || "",
    archived: Boolean(service.archived)
  };
}

function beneficiaryFromDb(row, services = []) {
  const assets = {
    land: n(row.asset_land),
    building: n(row.asset_building),
    equipment: n(row.asset_equipment),
    revolvingCapital: n(row.asset_revolving_capital)
  };
  return {
    id: row.id,
    firmName: row.firm_name || "",
    proprietor: row.proprietor || "",
    address: row.address || "",
    municipality: row.municipality || "",
    contactNumber: row.contact_number || "",
    email: row.email || "",
    notes: row.notes || "",
    cooperator: {
      name: row.proprietor || "",
      sex: row.cooperator_sex || "",
      birthDate: row.cooperator_birth_date || "",
      isPwd: Boolean(row.cooperator_is_pwd),
      isIndigenousPeople: Boolean(row.cooperator_is_indigenous_people),
      contactNumber: row.contact_number || "",
      email: row.email || ""
    },
    business: {
      firmName: row.firm_name || "",
      completeAddress: row.address || "",
      municipality: row.municipality || "",
      district: "",
      businessType: row.business_type || "",
      businessSector: row.business_sector || "",
      assets
    },
    services: services
      .filter((item) => item.cooperator_id === row.id && !item.archived)
      .map(serviceFromDb),
    project: {
      title: row.project_title || "",
      spin: uiSpin(row.spin),
      projectYear: n(row.project_year),
      sourceOfFund: row.source_of_fund || "",
      officer: row.officer || "",
      status: row.project_status || ""
    },
    financial: {
      assistanceAmount: n(row.assistance_amount),
      releaseDate: uiDate(row.release_date),
      projectDurationMonths: n(row.project_duration_months),
      repaymentStartDate: uiDate(row.repayment_start_date),
      originalDueDate: uiDate(row.original_due_date),
      installments: uiInstallments(row),
      monthlyRefundAmount: n(row.monthly_refund_amount),
      technologyTransferFee: n(row.technology_transfer_fee),
      optionToBuyAmount: n(row.option_to_buy_amount),
      otherFees: n(row.other_fees),
      remarks: row.financial_remarks || ""
    },
    status: row.status || "Under Review",
    archived: Boolean(row.archived),
    createdAt: row.created_at || "",
    updatedAt: row.updated_at || ""
  };
}

function paymentFromDb(row, allocations) {
  return {
    id: row.id,
    beneficiaryId: row.cooperator_id,
    projectTitle: row.project_title || "",
    paymentDate: row.payment_date || "",
    amount: n(row.amount),
    method: row.method || "Cash",
    referenceNumber: row.reference_number || "",
    checkDate: row.check_date || "",
    bank: row.bank || "",
    dateReceived: row.date_received || "",
    dateDeposited: row.date_deposited || "",
    status: row.status || "Received",
    allocations: allocations
      .filter((item) => item.payment_id === row.id)
      .map((item) => ({
        beneficiaryId: item.cooperator_id,
        installmentNumber: n(item.installment_number),
        amount: n(item.amount)
      })),
    remarks: row.remarks || "",
    archived: Boolean(row.archived)
  };
}

function receiptFromDb(row) {
  return {
    id: row.id,
    beneficiaryId: row.cooperator_id,
    paymentId: row.payment_id,
    orNumber: row.or_number || "",
    orDate: row.or_date || "",
    amount: n(row.amount),
    penaltyAmount: n(row.penalty_amount),
    attachmentName: row.attachment_name || "",
    remarks: row.remarks || "",
    archived: Boolean(row.archived)
  };
}

function defermentFromDb(row) {
  return {
    id: row.id,
    beneficiaryId: row.cooperator_id,
    requestDate: row.request_date || "",
    startDate: row.start_date || "",
    endDate: row.end_date || "",
    months: n(row.months),
    reason: row.reason || "",
    approvalDate: row.approval_date || "",
    approvedBy: row.approved_by || "",
    status: row.status || "Pending Documentation",
    remarks: row.remarks || "",
    archived: Boolean(row.archived)
  };
}

function adjustmentFromDb(row) {
  return {
    id: row.id,
    beneficiaryId: row.cooperator_id,
    type: row.type || "",
    effectiveDate: row.effective_date || "",
    amount: n(row.amount),
    previousValue: row.previous_value || "",
    newValue: row.new_value || "",
    reason: row.reason || "",
    approvedBy: row.approved_by || "",
    remarks: row.remarks || "",
    archived: Boolean(row.archived)
  };
}

function documentFromDb(row) {
  const storagePath = row.storage_path || "";
  return {
    id: row.id,
    category: row.category || "",
    beneficiaryId: row.cooperator_id || "",
    projectTitle: row.project_title || "",
    relatedTransaction: row.related_transaction || "",
    documentDate: row.document_date || "",
    fileName: row.file_name || "",
    fileSize: n(row.file_size),
    fileType: row.file_type || "",
    storagePath,
    publicUrl: storagePath ? `${supabaseConfig.url}/storage/v1/object/public/${supabaseConfig.documentBucket}/${encodeURIComponent(storagePath).replaceAll("%2F", "/")}` : "",
    description: row.description || "",
    archived: Boolean(row.archived)
  };
}

function settingsFromDb(row) {
  if (!row) return defaultSettings;
  return {
    organizationName: row.organization_name || "",
    officeAddress: row.office_address || "",
    officeContact: row.office_contact || "",
    defaultReportHeading: row.default_report_heading || "",
    currencyFormat: row.currency_format || "Philippine Peso",
    dateFormat: row.date_format || "MMM DD, YYYY",
    defaultRepaymentMonths: n(row.default_repayment_months) || 36,
    preparedBy: row.prepared_by || "",
    reviewedBy: row.reviewed_by || "",
    approvedBy: row.approved_by || "",
    defaultRowsPerTable: n(row.default_rows_per_table) || 10,
    themePreference: row.theme_preference || "Light"
  };
}

function activityFromDb(row) {
  return {
    id: row.id,
    beneficiaryId: row.cooperator_id || "",
    action: row.action || "",
    timestamp: row.created_at || ""
  };
}

function emptyToNull(value) {
  return value || null;
}

function dbDate(value) {
  return value || emptyDate;
}

function uiDate(value = "") {
  return value === emptyDate ? "" : value || "";
}

function uiInstallments(row) {
  const noRefundTerms =
    n(row.assistance_amount) === 0 &&
    n(row.monthly_refund_amount) === 0 &&
    uiDate(row.repayment_start_date) === "" &&
    uiDate(row.original_due_date) === "";
  return noRefundTerms ? 0 : n(row.installments);
}

function dbSpin(record) {
  const value = record.project?.spin?.trim();
  return value || `NO-SPIN-${record.id}`;
}

function uiSpin(value = "") {
  return String(value).startsWith("NO-SPIN-") ? "" : value || "";
}

function stripUndefined(record) {
  return Object.fromEntries(Object.entries(record).filter(([, value]) => value !== undefined));
}

function beneficiaryToDb(record) {
  const cooperator = record.cooperator || {};
  const business = record.business || {};
  const assets = business.assets || record.assets || {};
  return {
    id: record.id,
    firm_name: record.firmName,
    proprietor: record.proprietor,
    address: record.address || "",
    municipality: record.municipality || "",
    contact_number: record.contactNumber || "",
    email: record.email || "",
    notes: record.notes || "",
    cooperator_sex: cooperator.sex || "",
    cooperator_birth_date: emptyToNull(cooperator.birthDate || record.birthDate),
    cooperator_is_pwd: bool(cooperator.isPwd ?? record.isPwd),
    cooperator_is_indigenous_people: bool(cooperator.isIndigenousPeople ?? record.isIndigenousPeople),
    business_type: business.businessType || "",
    business_sector: business.businessSector || "",
    asset_land: Number(assets.land || 0),
    asset_building: Number(assets.building || 0),
    asset_equipment: Number(assets.equipment || 0),
    asset_revolving_capital: Number(assets.revolvingCapital || 0),
    project_title: record.project?.title || "",
    spin: dbSpin(record),
    project_year: Number(record.project?.projectYear || new Date().getFullYear()),
    source_of_fund: record.project?.sourceOfFund || "",
    officer: record.project?.officer || "",
    project_status: record.project?.status || "",
    assistance_amount: Number(record.financial?.assistanceAmount || 0),
    release_date: dbDate(record.financial?.releaseDate),
    project_duration_months: Number(record.financial?.projectDurationMonths || 0),
    repayment_start_date: dbDate(record.financial?.repaymentStartDate),
    original_due_date: dbDate(record.financial?.originalDueDate),
    installments: Number(record.financial?.installments || 1),
    monthly_refund_amount: Number(record.financial?.monthlyRefundAmount || 0),
    technology_transfer_fee: Number(record.financial?.technologyTransferFee || 0),
    option_to_buy_amount: Number(record.financial?.optionToBuyAmount || 0),
    other_fees: Number(record.financial?.otherFees || 0),
    financial_remarks: record.financial?.remarks || "",
    status: record.status,
    archived: Boolean(record.archived)
  };
}

function allocationToDb(paymentId, allocation) {
  return {
    payment_id: paymentId,
    cooperator_id: allocation.beneficiaryId,
    installment_number: Number(allocation.installmentNumber || 0),
    amount: Number(allocation.amount || 0)
  };
}

function paymentToDb(record) {
  return {
    id: record.id,
    cooperator_id: record.beneficiaryId,
    project_title: record.projectTitle || "",
    payment_date: record.paymentDate,
    amount: Number(record.amount || 0),
    method: record.method,
    reference_number: record.referenceNumber || "",
    check_date: emptyToNull(record.checkDate),
    bank: record.bank || "",
    date_received: emptyToNull(record.dateReceived || record.paymentDate),
    date_deposited: emptyToNull(record.dateDeposited),
    status: record.status,
    remarks: record.remarks || "",
    archived: Boolean(record.archived)
  };
}

function receiptToDb(record) {
  return {
    id: record.id,
    cooperator_id: record.beneficiaryId,
    payment_id: record.paymentId,
    or_number: record.orNumber,
    or_date: record.orDate,
    amount: Number(record.amount || 0),
    penalty_amount: Number(record.penaltyAmount || 0),
    attachment_name: record.attachmentName || "",
    remarks: record.remarks || "",
    archived: Boolean(record.archived)
  };
}

function defermentToDb(record) {
  return {
    id: record.id,
    cooperator_id: record.beneficiaryId,
    request_date: record.requestDate,
    start_date: record.startDate,
    end_date: record.endDate,
    months: Number(record.months || 0),
    reason: record.reason,
    approval_date: emptyToNull(record.approvalDate),
    approved_by: record.approvedBy || "",
    status: record.status,
    remarks: record.remarks || "",
    archived: Boolean(record.archived)
  };
}

function adjustmentToDb(record) {
  return {
    id: record.id,
    cooperator_id: record.beneficiaryId,
    type: record.type,
    effective_date: record.effectiveDate,
    amount: Number(record.amount || 0),
    previous_value: record.previousValue || "",
    new_value: record.newValue || "",
    reason: record.reason,
    approved_by: record.approvedBy || "",
    remarks: record.remarks || "",
    archived: Boolean(record.archived)
  };
}

function documentToDb(record) {
  return {
    id: record.id,
    category: record.category,
    cooperator_id: emptyToNull(record.beneficiaryId),
    project_title: record.projectTitle || "",
    related_transaction: record.relatedTransaction || "",
    document_date: record.documentDate,
    file_name: record.fileName,
    file_size: Number(record.fileSize || 0),
    file_type: record.fileType || "application/pdf",
    storage_path: record.storagePath || null,
    description: record.description || "",
    archived: Boolean(record.archived)
  };
}

function settingsToDb(record) {
  return {
    id: 1,
    organization_name: record.organizationName || "",
    office_address: record.officeAddress || "",
    office_contact: record.officeContact || "",
    default_report_heading: record.defaultReportHeading || "",
    currency_format: record.currencyFormat || "Philippine Peso",
    date_format: record.dateFormat || "MMM DD, YYYY",
    default_repayment_months: Number(record.defaultRepaymentMonths || 36),
    prepared_by: record.preparedBy || "",
    reviewed_by: record.reviewedBy || "",
    approved_by: record.approvedBy || "",
    default_rows_per_table: Number(record.defaultRowsPerTable || 10),
    theme_preference: record.themePreference || "Light"
  };
}

function activityToDb(record) {
  return {
    id: record.id,
    cooperator_id: emptyToNull(record.beneficiaryId),
    action: record.action
  };
}

const adapters = {
  beneficiaries: { table: "cooperators", fromDb: beneficiaryFromDb, toDb: beneficiaryToDb },
  payments: { table: "payments", fromDb: paymentFromDb, toDb: paymentToDb },
  receipts: { table: "receipts", fromDb: receiptFromDb, toDb: receiptToDb },
  deferments: { table: "deferments", fromDb: defermentFromDb, toDb: defermentToDb },
  adjustments: { table: "account_adjustments", fromDb: adjustmentFromDb, toDb: adjustmentToDb },
  documents: { table: "documents", fromDb: documentFromDb, toDb: documentToDb },
  activity: { table: "activity_log", fromDb: activityFromDb, toDb: activityToDb }
};

export async function readSupabaseStateDirect() {
  const [beneficiaries, services, payments, allocations, receipts, deferments, adjustments, documents, settings, activity] = await Promise.all([
    supabaseRest.selectAll("cooperators", "select=*&order=created_at.desc"),
    supabaseRest.selectAll("cooperator_services", "select=*"),
    supabaseRest.selectAll("payments", "select=*&order=created_at.desc"),
    supabaseRest.selectAll("payment_allocations", "select=*"),
    supabaseRest.selectAll("receipts", "select=*&order=created_at.desc"),
    supabaseRest.selectAll("deferments", "select=*&order=created_at.desc"),
    supabaseRest.selectAll("account_adjustments", "select=*&order=created_at.desc"),
    supabaseRest.selectAll("documents", "select=*&order=created_at.desc"),
    supabaseRest.select("system_settings", "select=*&id=eq.1&limit=1"),
    supabaseRest.select("activity_log", "select=*&order=created_at.desc&limit=100")
  ]);

  return {
    beneficiaries: beneficiaries.map((beneficiary) => beneficiaryFromDb(beneficiary, services)),
    payments: payments.map((payment) => paymentFromDb(payment, allocations)),
    receipts: receipts.map(receiptFromDb),
    deferments: deferments.map(defermentFromDb),
    adjustments: adjustments.map(adjustmentFromDb),
    documents: documents.map(documentFromDb),
    settings: settingsFromDb(settings[0]),
    activity: activity.map(activityFromDb)
  };
}

export async function upsertSupabaseDirect(collection, records) {
  const adapter = adapters[collection];
  if (!adapter) return [];
  const source = Array.isArray(records) ? records : [records];
  const existingIds = new Set();
  if (collection === "beneficiaries") {
    for (const record of source) {
      const existing = await supabaseRest.select("cooperators", `select=id&id=eq.${encodeURIComponent(record.id)}&limit=1`);
      if (existing.length) existingIds.add(record.id);
    }
  }
  const rows = source.map((record) => stripUndefined(adapter.toDb(record)));
  const savedRows = await supabaseRest.upsert(adapter.table, rows);
  if (collection === "payments") {
    for (const record of source) {
      await supabaseRest.deleteWhere("payment_allocations", "payment_id", record.id);
      const allocations = (record.allocations || []).map((allocation) => allocationToDb(record.id, allocation));
      if (allocations.length) await supabaseRest.insert("payment_allocations", allocations);
    }
    return savedRows.map((row) => {
      const original = source.find((record) => record.id === row.id);
      return paymentFromDb(row, (original?.allocations || []).map((allocation) => ({ payment_id: row.id, ...allocationToDb(row.id, allocation) })));
    });
  }
  if (collection === "beneficiaries") {
    try {
      for (const record of source) {
        await supabaseRest.deleteWhere("cooperator_services", "cooperator_id", record.id);
        const services = (record.services || [])
          .filter((service) => service.category)
          .map((service, index) => serviceToDb(record.id, service, index));
        if (services.length) await supabaseRest.insert("cooperator_services", services);
      }
    } catch (error) {
      for (const record of source) {
        if (!existingIds.has(record.id)) await supabaseRest.deleteWhere("cooperators", "id", record.id).catch(() => {});
      }
      throw error;
    }
    return savedRows.map((row) => {
      const original = source.find((record) => record.id === row.id);
      const services = (original?.services || []).map((service, index) => serviceToDb(row.id, service, index));
      return beneficiaryFromDb(row, services);
    });
  }
  return savedRows.map(adapter.fromDb);
}

export async function patchSupabaseDirect(collection, id, patch) {
  const current = await readSupabaseStateDirect();
  const existing = current[collection]?.find((item) => item.id === id);
  if (!existing) return null;
  const [saved] = await upsertSupabaseDirect(collection, { ...existing, ...patch });
  return saved || null;
}

export async function removeSupabaseDirect(collection, id) {
  const adapter = adapters[collection];
  if (!adapter) return;
  if (collection === "beneficiaries") {
    await supabaseRest.deleteWhere("receipts", "cooperator_id", id);
    await supabaseRest.deleteWhere("payment_allocations", "cooperator_id", id);
    await supabaseRest.deleteWhere("payments", "cooperator_id", id);
    await supabaseRest.deleteWhere("deferments", "cooperator_id", id);
    await supabaseRest.deleteWhere("account_adjustments", "cooperator_id", id);
    await supabaseRest.deleteWhere("documents", "cooperator_id", id);
    await supabaseRest.deleteWhere("cooperator_services", "cooperator_id", id);
  }
  if (collection === "payments") {
    await supabaseRest.deleteWhere("receipts", "payment_id", id);
    await supabaseRest.deleteWhere("payment_allocations", "payment_id", id);
  }
  await supabaseRest.deleteWhere(adapter.table, "id", id);
}

export async function saveSupabaseStateDirect(state) {
  for (const collection of ["beneficiaries", "payments", "receipts", "deferments", "adjustments", "documents", "activity"]) {
    if (Array.isArray(state[collection]) && state[collection].length) await upsertSupabaseDirect(collection, state[collection]);
  }
  if (state.settings) await supabaseRest.upsert("system_settings", settingsToDb(state.settings));
  return readSupabaseStateDirect();
}

export async function uploadSupabaseDocumentDirect(record, file) {
  if (!file) return "";
  const safeName = `${record.id}-${(file.name || "document").toLowerCase().replace(/[^a-z0-9.]+/g, "-").replace(/^-|-$/g, "") || "document"}`;
  const storagePath = `${record.beneficiaryId || "unassigned"}/${safeName}`;
  await supabaseRest.uploadDocument(storagePath, file);
  return storagePath;
}
