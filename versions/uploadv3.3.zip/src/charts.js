import { escapeHtml, formatCurrency, percent } from "./utils.js";

const chartInstances = new Map();

export function destroyAllCharts() {
  chartInstances.forEach((chart) => {
    try { chart.destroy(); } catch (_) { /* ignore */ }
  });
  chartInstances.clear();
}

function getOrCreate(canvasId, config) {
  if (chartInstances.has(canvasId)) {
    try { chartInstances.get(canvasId).destroy(); } catch (_) { /* ignore */ }
  }
  const canvas = document.getElementById(canvasId);
  if (!canvas) return null;
  const chart = new Chart(canvas, config);
  chartInstances.set(canvasId, chart);
  return chart;
}

const COLORS = {
  target: "#20bf72",
  collection: "#102c6d",
  refundPerformance: "#f59e0b",
  remaining: "#8ea1b8",
  teal: "#37a2a6",
  gridLine: "#e2e8f0",
  text: "#64748b",
  textDark: "#334155"
};

function sparseAllYearsLabel(labels) {
  return (val, index, ticks) => {
    const originalIndex = ticks?.[index]?._index ?? index;
    const label = labels[originalIndex] || val;
    if (originalIndex === 0) return label;
    const parts = label.split(" ");
    const month = parts[0] || "";
    if (month === "Jan" || month === "January") {
      const year = label.match(/\d{4}/)?.[0];
      return year || label;
    }
    return "";
  };
}

function sparseAllYearsTooltip(labels) {
  return (tooltipItems) => {
    const idx = tooltipItems[0]?.dataIndex;
    return labels[idx] || tooltipItems[0]?.label || "";
  };
}

function percentYAxisMax(values) {
  const max = Math.max(...values.filter((v) => isFinite(v)), 0);
  if (max <= 100) return 100;
  if (max <= 200) return 200;
  if (max <= 300) return 300;
  if (max <= 500) return 500;
  return Math.ceil(max / 100) * 100;
}

export function renderLineChart(canvasId, { labels, values, legend = "", yAxisType = "currency", title = "", selectedYear = "" }) {
  const isAllYears = labels.length > 12 && !selectedYear;
  const maxVal = yAxisType === "percent" ? percentYAxisMax(values) : Math.max(...values, 1);
  const config = {
    type: "line",
    data: {
      labels,
      datasets: [{
        label: legend || title,
        data: values,
        borderColor: COLORS.collection,
        backgroundColor: COLORS.collection + "18",
        borderWidth: 3,
        pointRadius: 4,
        pointHoverRadius: 7,
        pointBackgroundColor: COLORS.collection,
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
        tension: 0.3,
        fill: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: "#0f172a",
          titleFont: { weight: "bold" },
          padding: 12,
          cornerRadius: 6,
          callbacks: {
            title: isAllYears ? sparseAllYearsTooltip(labels) : undefined,
            label: (ctx) => {
              const v = ctx.parsed.y;
              if (yAxisType === "percent") return `Rate: ${v.toFixed(1)}%`;
              return `Amount: ${formatCurrency(v)}`;
            }
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.text,
            font: { size: 11, weight: "600" },
            maxRotation: 45,
            callback: isAllYears ? sparseAllYearsLabel(labels) : undefined
          }
        },
        y: {
          beginAtZero: true,
          max: yAxisType === "percent" ? maxVal : undefined,
          grid: { color: COLORS.gridLine },
          ticks: {
            color: COLORS.text,
            font: { size: 11, weight: "600" },
            callback: (v) => yAxisType === "percent" ? `${v}%` : formatCurrency(v)
          }
        }
      },
      interaction: { intersect: false, mode: "index" }
    }
  };
  return `<div class="chart-canvas-wrap"><canvas id="${escapeHtml(canvasId)}"></canvas></div>`;
}

export function initLineChart(canvasId, { labels, values, legend = "", yAxisType = "currency", title = "", selectedYear = "" }) {
  const isAllYears = labels.length > 12 && !selectedYear;
  const maxVal = yAxisType === "percent" ? percentYAxisMax(values) : Math.max(...values, 1);
  const config = {
    type: "line",
    data: {
      labels,
      datasets: [{
        label: legend || title,
        data: values,
        borderColor: COLORS.refundPerformance,
        backgroundColor: COLORS.refundPerformance + "18",
        borderWidth: 3,
        pointRadius: 4,
        pointHoverRadius: 7,
        pointBackgroundColor: COLORS.refundPerformance,
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
        tension: 0.3,
        fill: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: "#0f172a",
          titleFont: { weight: "bold" },
          padding: 12,
          cornerRadius: 6,
          callbacks: {
            title: isAllYears ? sparseAllYearsTooltip(labels) : undefined,
            label: (ctx) => {
              const v = ctx.parsed.y;
              if (yAxisType === "percent") return `Rate: ${v.toFixed(1)}%`;
              return `Amount: ${formatCurrency(v)}`;
            }
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.text,
            font: { size: 11, weight: "600" },
            maxRotation: 45,
            callback: isAllYears ? sparseAllYearsLabel(labels) : undefined
          }
        },
        y: {
          beginAtZero: true,
          max: yAxisType === "percent" ? maxVal : undefined,
          grid: { color: COLORS.gridLine },
          ticks: {
            color: COLORS.text,
            font: { size: 11, weight: "600" },
            callback: (v) => yAxisType === "percent" ? `${v}%` : formatCurrency(v)
          }
        }
      },
      interaction: { intersect: false, mode: "index" }
    }
  };
  return getOrCreate(canvasId, config);
}

export function renderBarChart(canvasId, { labels, targets, actuals, legend = "", title = "", selectedYear = "" }) {
  const isAllYears = labels.length > 12 && !selectedYear;
  const config = {
    type: "bar",
    data: {
      labels,
      datasets: [
        {
          label: "Target",
          data: targets,
          backgroundColor: COLORS.target,
          borderRadius: 3,
          barPercentage: 0.7,
          categoryPercentage: 0.8
        },
        {
          label: "Collection",
          data: actuals,
          backgroundColor: COLORS.collection,
          borderRadius: 3,
          barPercentage: 0.7,
          categoryPercentage: 0.8
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: true,
          position: "top",
          labels: { usePointStyle: true, pointStyle: "rectRounded", padding: 16, font: { size: 12, weight: "600" } }
        },
        tooltip: {
          backgroundColor: "#0f172a",
          titleFont: { weight: "bold" },
          padding: 12,
          cornerRadius: 6,
          callbacks: {
            title: isAllYears ? sparseAllYearsTooltip(labels) : undefined,
            label: (ctx) => `${ctx.dataset.label}: ${formatCurrency(ctx.parsed.y)}`
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.text,
            font: { size: 11, weight: "600" },
            maxRotation: 45,
            callback: isAllYears ? sparseAllYearsLabel(labels) : undefined
          }
        },
        y: {
          beginAtZero: true,
          grid: { color: COLORS.gridLine },
          ticks: {
            color: COLORS.text,
            font: { size: 11, weight: "600" },
            callback: (v) => formatCurrency(v)
          }
        }
      },
      interaction: { intersect: false, mode: "index" }
    }
  };
  return `<div class="chart-canvas-wrap"><canvas id="${escapeHtml(canvasId)}"></canvas></div>`;
}

export function initBarChart(canvasId, { labels, targets, actuals, selectedYear = "" }) {
  const isAllYears = labels.length > 12 && !selectedYear;
  const config = {
    type: "bar",
    data: {
      labels,
      datasets: [
        {
          label: "Target",
          data: targets,
          backgroundColor: COLORS.target,
          borderRadius: 3,
          barPercentage: 0.7,
          categoryPercentage: 0.8
        },
        {
          label: "Collection",
          data: actuals,
          backgroundColor: COLORS.collection,
          borderRadius: 3,
          barPercentage: 0.7,
          categoryPercentage: 0.8
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: "#0f172a",
          titleFont: { weight: "bold" },
          padding: 12,
          cornerRadius: 6,
          callbacks: {
            title: isAllYears ? sparseAllYearsTooltip(labels) : undefined,
            label: (ctx) => `${ctx.dataset.label}: ${formatCurrency(ctx.parsed.y)}`
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.text,
            font: { size: 11, weight: "600" },
            maxRotation: 45,
            callback: isAllYears ? sparseAllYearsLabel(labels) : undefined
          }
        },
        y: {
          beginAtZero: true,
          grid: { color: COLORS.gridLine },
          ticks: {
            color: COLORS.text,
            font: { size: 11, weight: "600" },
            callback: (v) => formatCurrency(v)
          }
        }
      },
      interaction: { intersect: false, mode: "index" }
    }
  };
  return getOrCreate(canvasId, config);
}

export function initPerformanceChart(canvasId, { labels, values, isAllYears = false }) {
  const maxVal = percentYAxisMax(values);
  const config = {
    type: "line",
    data: {
      labels,
      datasets: [{
        label: "Refund Performance",
        data: values,
        borderColor: COLORS.refundPerformance,
        backgroundColor: COLORS.refundPerformance + "18",
        borderWidth: 3,
        pointRadius: 4,
        pointHoverRadius: 7,
        pointBackgroundColor: COLORS.refundPerformance,
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
        tension: 0.3,
        fill: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: "#0f172a",
          titleFont: { weight: "bold" },
          padding: 12,
          cornerRadius: 6,
          callbacks: {
            title: isAllYears ? sparseAllYearsTooltip(labels) : undefined,
            label: (ctx) => `Performance: ${ctx.parsed.y.toFixed(1)}%`
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            color: COLORS.text,
            font: { size: 11, weight: "600" },
            maxRotation: 45,
            callback: isAllYears ? sparseAllYearsLabel(labels) : undefined
          }
        },
        y: {
          beginAtZero: true,
          max: maxVal,
          grid: { color: COLORS.gridLine },
          ticks: {
            color: COLORS.text,
            font: { size: 11, weight: "600" },
            callback: (v) => `${v}%`
          }
        }
      },
      interaction: { intersect: false, mode: "index" }
    }
  };
  return getOrCreate(canvasId, config);
}
